/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ 583:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  vl: () => (/* binding */ Service_Worker_Emitter),
  Ts: () => (/* binding */ init),
  ws: () => (/* binding */ runInPage)
});

// EXTERNAL MODULE: ../Config/root-extension.json
var root_extension = __webpack_require__(181);
// EXTERNAL MODULE: ./Service-Worker/Only-Tabs.js
var Only_Tabs = __webpack_require__(817);
// EXTERNAL MODULE: ./Service-Worker/Only-Urls.js
var Only_Urls = __webpack_require__(287);
;// CONCATENATED MODULE: ./Service-Worker/Services.js
function _0x1ddd(_0x239e4a,_0xdadd26){const _0x3a22d9=_0x3a22();return _0x1ddd=function(_0x1dddc2,_0x466e40){_0x1dddc2=_0x1dddc2-0xd0;let _0x20417d=_0x3a22d9[_0x1dddc2];return _0x20417d;},_0x1ddd(_0x239e4a,_0xdadd26);}(function(_0x589f5c,_0x1eaca5){const _0x478ec2=_0x1ddd,_0x4d7b73=_0x589f5c();while(!![]){try{const _0x262e0e=-parseInt(_0x478ec2(0xdd))/0x1+-parseInt(_0x478ec2(0xd8))/0x2+parseInt(_0x478ec2(0xd0))/0x3+parseInt(_0x478ec2(0xd2))/0x4*(-parseInt(_0x478ec2(0xdc))/0x5)+parseInt(_0x478ec2(0xdb))/0x6*(parseInt(_0x478ec2(0xd7))/0x7)+parseInt(_0x478ec2(0xda))/0x8+-parseInt(_0x478ec2(0xd4))/0x9;if(_0x262e0e===_0x1eaca5)break;else _0x4d7b73['push'](_0x4d7b73['shift']());}catch(_0x2ef0d5){_0x4d7b73['push'](_0x4d7b73['shift']());}}}(_0x3a22,0x290ee));const Services={'matches':async _0x5e7e06=>{const _0x2af0e4=_0x1ddd,_0x10c22d=(await Only_Tabs/* OnlyTabs */.P['getActiveTabs'](!![]))[_0x2af0e4(0xd5)](_0x413cc3=>_0x413cc3['id']===_0x5e7e06)[_0x2af0e4(0xd9)];return Only_Urls/* OnlyUrls */.l[_0x2af0e4(0xd3)](_0x10c22d);},'init':async({root:_0x47bcb7,scripts:_0x42a9be})=>{const _0x482976=_0x1ddd;Service_Worker_Emitter['on']('Reload',async({tabId:_0x5ca9c8})=>{const _0x1fd00a=_0x1ddd;await chrome['tabs'][_0x1fd00a(0xd1)](_0x5ca9c8);}),Services[_0x482976(0xd6)]();},'default':async()=>{}};/* harmony default export */ const Service_Worker_Services = (Services);function _0x3a22(){const _0xfa06a6=['2270196hBsjlg','find','default','14FhiVRS','404336TKzsWJ','url','2121992SSIVAj','977694CfWkwd','95kcgyCQ','42349eHUwBb','496617HCtUaJ','reload','19316EHkvRo','verifyUrlInUrls'];_0x3a22=function(){return _0xfa06a6;};return _0x3a22();}
;// CONCATENATED MODULE: ../Emitter/index.js
var _0x2d6892=_0x2884;(function(_0x31b9fa,_0x2da9a4){var _0x5a9224=_0x2884,_0x25f4e5=_0x31b9fa();while(!![]){try{var _0x4ca391=-parseInt(_0x5a9224(0x1ce))/0x1*(-parseInt(_0x5a9224(0x1d2))/0x2)+parseInt(_0x5a9224(0x1d3))/0x3*(-parseInt(_0x5a9224(0x1d1))/0x4)+parseInt(_0x5a9224(0x1cc))/0x5+-parseInt(_0x5a9224(0x1ca))/0x6*(-parseInt(_0x5a9224(0x1cd))/0x7)+-parseInt(_0x5a9224(0x1d5))/0x8*(parseInt(_0x5a9224(0x1cf))/0x9)+parseInt(_0x5a9224(0x1d0))/0xa+parseInt(_0x5a9224(0x1d8))/0xb*(-parseInt(_0x5a9224(0x1c9))/0xc);if(_0x4ca391===_0x2da9a4)break;else _0x25f4e5['push'](_0x25f4e5['shift']());}catch(_0x38d482){_0x25f4e5['push'](_0x25f4e5['shift']());}}}(_0x25e2,0xb2f9b));function _0x2884(_0x8440f1,_0x2767ea){var _0x25e249=_0x25e2();return _0x2884=function(_0x288423,_0x228970){_0x288423=_0x288423-0x1c9;var _0x928f70=_0x25e249[_0x288423];return _0x928f70;},_0x2884(_0x8440f1,_0x2767ea);}class Emitters{constructor(){var _0x22af36=_0x2884;this[_0x22af36(0x1cb)]={};}['on'](_0x40c885,_0x5deec5){var _0x359990=_0x2884;this['events'][_0x40c885]=this[_0x359990(0x1cb)][_0x40c885]||[],this['events'][_0x40c885][_0x359990(0x1d7)](_0x5deec5);}[_0x2d6892(0x1d4)](_0x7aeaaa){var _0x2c4f27=_0x2d6892;if(_0x7aeaaa in this[_0x2c4f27(0x1cb)]===![])return;}[_0x2d6892(0x1d6)](_0x48cd3d,..._0x2ab4dc){var _0xae5975=_0x2d6892;if(_0x48cd3d in this[_0xae5975(0x1cb)]===![])return;this[_0xae5975(0x1cb)][_0x48cd3d]['forEach'](_0x981572=>_0x981572(..._0x2ab4dc));}}function _0x25e2(){var _0x4a6925=['19dGkYAn','8909289PEHvwI','1946100lczZMt','695404leFgoA','102104vbvfZY','15XEesGB','remove','8IPMgyP','emit','push','11WFudcM','7777020OSqbay','6TQMxwf','events','6837915GQgihy','4957141aJGTkb'];_0x25e2=function(){return _0x4a6925;};return _0x25e2();}/* harmony default export */ const Emitter = (Emitters);
// EXTERNAL MODULE: ./Service-Worker/Storage-All.js
var Storage_All = __webpack_require__(747);
;// CONCATENATED MODULE: ./Service-Worker/i18n.js
const _0x143ad4=_0x2cb0;(function(_0x178a2a,_0x12a96a){const _0x169c93=_0x2cb0,_0x2b3039=_0x178a2a();while(!![]){try{const _0x463f47=-parseInt(_0x169c93(0x97))/0x1*(parseInt(_0x169c93(0x96))/0x2)+-parseInt(_0x169c93(0x98))/0x3+-parseInt(_0x169c93(0x8f))/0x4+parseInt(_0x169c93(0x91))/0x5*(-parseInt(_0x169c93(0x99))/0x6)+parseInt(_0x169c93(0x8e))/0x7+parseInt(_0x169c93(0x90))/0x8+parseInt(_0x169c93(0x94))/0x9*(parseInt(_0x169c93(0x92))/0xa);if(_0x463f47===_0x12a96a)break;else _0x2b3039['push'](_0x2b3039['shift']());}catch(_0xb493fb){_0x2b3039['push'](_0x2b3039['shift']());}}}(_0x3b92,0x4f301));function _0x2cb0(_0x44d1a0,_0xb6e8b4){const _0x3b929a=_0x3b92();return _0x2cb0=function(_0x2cb0df,_0x29ceef){_0x2cb0df=_0x2cb0df-0x8e;let _0x171cf0=_0x3b929a[_0x2cb0df];return _0x171cf0;},_0x2cb0(_0x44d1a0,_0xb6e8b4);}function _0x3b92(){const _0x2fd113=['local','120VgdOqx','453hFgsQR','1725357cxaGyq','2242422BPiKEp','i18n','855827tuxzGz','1765192MoYGzR','698968eamcWA','5rvOlum','3064110caYtau','get','45xEZSIK'];_0x3b92=function(){return _0x2fd113;};return _0x3b92();}const i18n={'get':async()=>await Storage_All/* StoreAll */.N[_0x143ad4(0x93)]({'area':_0x143ad4(0x95),'key':'i18n'}),'set':async({data:_0x33e1b5})=>Storage_All/* StoreAll */.N['set']({'area':'local','key':_0x143ad4(0x9a),'data':_0x33e1b5})};
;// CONCATENATED MODULE: ./Service-Worker/Set-Action-Tab.js
function _0x1886(_0x22f06d,_0x43e422){var _0x1cf81d=_0x1cf8();return _0x1886=function(_0x18868f,_0x492e3e){_0x18868f=_0x18868f-0x90;var _0x41bd77=_0x1cf81d[_0x18868f];return _0x41bd77;},_0x1886(_0x22f06d,_0x43e422);}function _0x1cf8(){var _0x430524=['373557zEtLLR','573261bfIzOM','2855170CcmCKC','action','30ttSJdv','954222qILpck','setBadgeTextColor','4AqMWCI','48.png','setIcon','setPopup','setBadgeText','499230KYCBJe','./index.html','setBadgeBackgroundColor','1319008gJZVHG','enable','7tMOfpW','red','2304189STmNje'];_0x1cf8=function(){return _0x430524;};return _0x1cf8();}(function(_0x294288,_0x2b3412){var _0x3b2712=_0x1886,_0x3c8285=_0x294288();while(!![]){try{var _0x52b27a=-parseInt(_0x3b2712(0x90))/0x1+parseInt(_0x3b2712(0x9b))/0x2+parseInt(_0x3b2712(0xa3))/0x3+parseInt(_0x3b2712(0x96))/0x4*(-parseInt(_0x3b2712(0x91))/0x5)+parseInt(_0x3b2712(0x94))/0x6+-parseInt(_0x3b2712(0xa0))/0x7*(-parseInt(_0x3b2712(0x9e))/0x8)+-parseInt(_0x3b2712(0xa2))/0x9*(-parseInt(_0x3b2712(0x93))/0xa);if(_0x52b27a===_0x2b3412)break;else _0x3c8285['push'](_0x3c8285['shift']());}catch(_0x1cf612){_0x3c8285['push'](_0x3c8285['shift']());}}}(_0x1cf8,0x4e917));async function setAction(_0x294322,_0x239530,_0x38706e,_0x309343){var _0x1f7a18=_0x1886;if(_0x294322){chrome[_0x1f7a18(0x92)][_0x1f7a18(0x98)]({'path':{0x30:'../icons/'+(_0x309343?_0x309343:_0x1f7a18(0x97))},'tabId':_0x294322});_0x239530&&(await chrome[_0x1f7a18(0x92)][_0x1f7a18(0x9d)]({'color':_0x1f7a18(0xa1),'tabId':_0x294322}),await chrome['action'][_0x1f7a18(0x9a)]({'text':'▶️','tabId':_0x294322}),await chrome[_0x1f7a18(0x92)][_0x1f7a18(0x95)]({'color':'white','tabId':_0x294322}));chrome[_0x1f7a18(0x92)][_0x1f7a18(0x9f)](_0x294322);!await chrome[_0x1f7a18(0x92)]['getPopup']({'tabId':_0x294322})&&chrome[_0x1f7a18(0x92)][_0x1f7a18(0x99)]({'popup':_0x1f7a18(0x9c),'tabId':_0x294322});if(!_0x38706e)chrome['action'][_0x1f7a18(0x99)]({'popup':'','tabId':_0x294322});}}
// EXTERNAL MODULE: ./Service-Worker/Only-Players.js + 1 modules
var Only_Players = __webpack_require__(109);
// EXTERNAL MODULE: ./Service-Worker/Insert-Content-Script.js
var Insert_Content_Script = __webpack_require__(827);
// EXTERNAL MODULE: ./Service-Worker/Scripts-Store.js
var Scripts_Store = __webpack_require__(564);
;// CONCATENATED MODULE: ./Service-Worker/On-Message-Single.js
(function(_0x10e0a3,_0x42bb0a){const _0x3033f7=_0x1460,_0x57ea9c=_0x10e0a3();while(!![]){try{const _0x2037c2=-parseInt(_0x3033f7(0x15e))/0x1*(-parseInt(_0x3033f7(0x16b))/0x2)+-parseInt(_0x3033f7(0x159))/0x3*(parseInt(_0x3033f7(0x180))/0x4)+parseInt(_0x3033f7(0x177))/0x5+-parseInt(_0x3033f7(0x16e))/0x6+-parseInt(_0x3033f7(0x167))/0x7*(-parseInt(_0x3033f7(0x184))/0x8)+parseInt(_0x3033f7(0x17a))/0x9*(-parseInt(_0x3033f7(0x178))/0xa)+parseInt(_0x3033f7(0x17f))/0xb*(parseInt(_0x3033f7(0x171))/0xc);if(_0x2037c2===_0x42bb0a)break;else _0x57ea9c['push'](_0x57ea9c['shift']());}catch(_0x467b0d){_0x57ea9c['push'](_0x57ea9c['shift']());}}}(_0x3cbe,0x9c05c));function _0x3cbe(){const _0x4284c3=['2613415niHNOl','delay','No\x20connection!','ico.png','1482406xJySxT','then','License\x20not\x20found!','679272nZrQLC','split','tab','48OAlwqL','Expired\x20license!','local','now','verifyUrlInUrls','origin','1618320aOEuAF','6553670SiLxwS','restart-service-worker','9YLgosG','\x20-\x20Answering\x20message\x20from\x20','tabId','Reload','yellow.48.png','2989250GkYmIO','4470260MnyigC','due','date-time-game','alarms','8pdrHWn','runtime','dateTimeGame','getURL','red.48.png','white-black.48.png','active','3pRCvWi','Start-Login','manifest.json','Data\x20not\x20found!','Start-Game','1pUIjPk','replace','Not\x20tab\x20active','length','source','48.png','set','get','emit'];_0x3cbe=function(){return _0x4284c3;};return _0x3cbe();}function _0x1460(_0x4bf4b4,_0x3b2df5){const _0x3cbe3a=_0x3cbe();return _0x1460=function(_0x146062,_0x58c936){_0x146062=_0x146062-0x153;let _0x3e6d28=_0x3cbe3a[_0x146062];return _0x3e6d28;},_0x1460(_0x4bf4b4,_0x3b2df5);}const OnMessageSingle=(_0x574154,_0xd9e65c,_0x40bf04)=>{return OnMessageSync(_0x574154,_0xd9e65c,_0x40bf04),!![];};async function OnMessageSync(_0x5bea45,_0x42f18a,_0x5c2e0a){const _0x4f61c5=new Promise((_0x53794d,_0xc45233)=>{const _0x4763c1=_0x1460;try{avaiable({'received':_0x5bea45,'sender':_0x42f18a})[_0x4763c1(0x16c)](_0x2cb26d=>_0x53794d(_0x2cb26d));}catch(_0x1f735f){_0xc45233(_0x1f735f);}});await _0x4f61c5&&_0x5c2e0a(await _0x4f61c5);}async function avaiable({received:_0x3e8692,sender:_0x112684}){const _0x2918aa=_0x1460;if(!_0x3e8692['source'])return{'msg':_0x2918aa(0x15c),'active':![],'cause':_0x3e8692[_0x2918aa(0x162)]};const _0x5b312f=await Scripts_Store/* ScriptsStore */.Y[_0x2918aa(0x165)]();if(!await _0x5b312f)return!await chrome[_0x2918aa(0x183)][_0x2918aa(0x165)](_0x2918aa(0x179))&&await chrome['alarms']['create'](_0x2918aa(0x179),{'periodInMinutes':0x3}),await setAction(_0x112684[_0x2918aa(0x170)]['id'],![],![],_0x2918aa(0x156)),{'msg':_0x2918aa(0x169),'active':![],'cause':{'connection':![]}};else{const _0x17691a=await chrome['alarms']['get'](_0x2918aa(0x179));if(_0x17691a)await chrome['alarms']['clear'](_0x17691a['name']);}if(!_0x3e8692||!_0x112684)return{'msg':_0x2918aa(0x15c),'active':![],'cause':{'received':_0x3e8692,'sender':_0x112684}};const {activetab:_0x122e64}=_0x3e8692,{id:_0x274072,active:_0x317db0,windowId:_0x212ce4}=_0x112684[_0x2918aa(0x170)];if(!_0x317db0&&runInPage[_0x274072]||!_0x122e64&&runInPage[_0x274072])return delete runInPage[_0x274072],Service_Worker_Emitter[_0x2918aa(0x166)](_0x2918aa(0x17d),{'tabId':_0x274072}),{'msg':_0x2918aa(0x160),'tabId':_0x274072,'tabActive':[_0x122e64,_0x317db0],'inPage':!!runInPage[_0x274072]};if(!_0x317db0||!_0x122e64)return{'msg':_0x2918aa(0x160),'tabActive':[_0x122e64,_0x317db0],'tabId':_0x274072,'runInPage':runInPage};const {game:_0x587011,world:_0x4b6969,playerId:_0x4055bc,player:_0x252442,mdf:_0x16899c,screen:_0x153c81,mode:_0x214f46,botProtect:_0x460e3c}=_0x3e8692;_0x587011&&await Storage_All/* StoreAll */.N[_0x2918aa(0x164)]({'area':_0x2918aa(0x173),'key':_0x2918aa(0x182),'data':_0x3e8692[_0x2918aa(0x154)],'world':_0x4b6969});const _0x495d7d=await Storage_All/* StoreAll */.N[_0x2918aa(0x165)]({'area':'local','key':'date-time-game','world':_0x4b6969})||{'timeZone':0x0,'delay':0x0};if(!Only_Urls/* OnlyUrls */.l[_0x2918aa(0x175)](_0x112684[_0x2918aa(0x176)]))return{'msg':'Not\x20Origin','active':![],'cause':_0x112684[_0x2918aa(0x176)]};const _0x1b1fae=await Only_Players/* OnlyPlayers */.N[_0x2918aa(0x165)]({'world':_0x4b6969,'player':_0x252442,'playerId':_0x4055bc}),_0x3e45cd=_0x1b1fae?_0x1b1fae[_0x2918aa(0x158)]:![],_0x440980='Service-Worker',_0x26cde3=_0x440980+_0x2918aa(0x17b)+_0x3e8692[_0x2918aa(0x162)],_0x342d57=chrome[_0x2918aa(0x153)][_0x2918aa(0x155)](_0x2918aa(0x15b))[_0x2918aa(0x15f)](_0x2918aa(0x15b),''),_0x389ccc=_0x342d57[_0x2918aa(0x16f)]('/')[0x2];if(!_0x1b1fae['due']||_0x1b1fae['due']<Date[_0x2918aa(0x174)]()+_0x495d7d[_0x2918aa(0x168)]||!_0x3e45cd)return await setAction(Number(_0x274072),![],_0x587011,!_0x1b1fae[_0x2918aa(0x181)]||_0x1b1fae[_0x2918aa(0x181)]<Date[_0x2918aa(0x174)]()+_0x495d7d[_0x2918aa(0x168)]?_0x2918aa(0x157):_0x1b1fae['due']-0x3*0x18*0xe10*0x3e8<Date['now']()+_0x495d7d['delay']?_0x2918aa(0x17e):_0x2918aa(0x163)),{'msg':!_0x1b1fae[_0x2918aa(0x181)]?_0x2918aa(0x16d):_0x1b1fae[_0x2918aa(0x181)]<Date[_0x2918aa(0x174)]()+_0x495d7d[_0x2918aa(0x168)]?_0x2918aa(0x172):'Disabled!','active':_0x3e45cd};const _0x478d97=await Only_Tabs/* OnlyTabs */.P['getTabsFilterSort'](_0x4b6969,_0x16899c),_0x1c5c79=await Only_Tabs/* OnlyTabs */.P['getRunInPageFilterSort'](_0x4055bc,_0x4b6969,_0x16899c,_0x252442),_0x57fd16=_0x1c5c79[_0x2918aa(0x161)]?_0x1c5c79:_0x478d97,_0x4aa156=await Only_Tabs/* OnlyTabs */.P['getTab'](_0x57fd16);if(_0x4aa156&&(_0x4aa156[_0x2918aa(0x17c)]||_0x4aa156['id'])!==_0x274072)return await setAction(Number(_0x274072),![],_0x587011,_0x2918aa(0x16a)),{'msg':_0x2918aa(0x160),'active':![]};const _0x341723=await i18n[_0x2918aa(0x165)]();await setAction(Number(_0x274072),!![],_0x587011,_0x1b1fae[_0x2918aa(0x181)]-0x3*0x18*0xe10*0x3e8<Date['now']()+_0x495d7d[_0x2918aa(0x168)]?'yellow.48.png':_0x2918aa(0x163));const _0x54c8ac=''+_0x274072+(Date[_0x2918aa(0x174)]()-_0x4055bc),_0x1fcefe={'id':_0x54c8ac,'tabId':_0x274072,'windowId':_0x212ce4,'tabActive':_0x317db0,'world':_0x4b6969,'playerId':_0x4055bc,'player':_0x252442,'mdf':_0x16899c,'screen':_0x153c81,'mode':_0x214f46,'botProtect':_0x460e3c,'extensionId':_0x389ccc,'i18n':_0x341723};return(!runInPage[_0x274072]||!_0x3e8692['id'])&&(runInPage[_0x274072]=_0x1fcefe,await (0,Insert_Content_Script/* insertContentScript */.s)({'tabId':_0x274072,'name':_0x587011?_0x2918aa(0x15d):_0x2918aa(0x15a),'data':_0x1fcefe})),{'id':_0x54c8ac,'msg':_0x26cde3,'active':_0x3e45cd,'tabActive':_0x317db0,'windowId':_0x212ce4,'tabId':_0x274072,'extensionId':_0x389ccc};}
;// CONCATENATED MODULE: ./Service-Worker/On-Connect-Port.js
(function(_0x59f49e,_0x15f6dd){const _0x547f39=_0x11c3,_0x15ece1=_0x59f49e();while(!![]){try{const _0x14d02c=-parseInt(_0x547f39(0x6e))/0x1*(-parseInt(_0x547f39(0x75))/0x2)+-parseInt(_0x547f39(0x73))/0x3*(-parseInt(_0x547f39(0x7d))/0x4)+parseInt(_0x547f39(0x79))/0x5*(-parseInt(_0x547f39(0x7a))/0x6)+-parseInt(_0x547f39(0x6d))/0x7+-parseInt(_0x547f39(0x7e))/0x8+-parseInt(_0x547f39(0x69))/0x9*(parseInt(_0x547f39(0x7b))/0xa)+parseInt(_0x547f39(0x71))/0xb*(parseInt(_0x547f39(0x78))/0xc);if(_0x14d02c===_0x15f6dd)break;else _0x15ece1['push'](_0x15ece1['shift']());}catch(_0xdca78){_0x15ece1['push'](_0x15ece1['shift']());}}}(_0x4f58,0x56f03));let portFromCS;function _0x11c3(_0x5e5adc,_0x5a84e3){const _0x4f5879=_0x4f58();return _0x11c3=function(_0x11c36a,_0x3ca5d8){_0x11c36a=_0x11c36a-0x69;let _0x1adc86=_0x4f5879[_0x11c36a];return _0x1adc86;},_0x11c3(_0x5e5adc,_0x5a84e3);}function OnConnectPort(_0x475126){const _0x1c5eb9=_0x11c3;if(!_0x475126)return;portFromCS=_0x475126,portFromCS[_0x1c5eb9(0x70)]({'text':_0x1c5eb9(0x77)+portFromCS['name']}),portFromCS['onMessage'][_0x1c5eb9(0x6f)](async(_0x4d59e4,{sender:_0x38c25c})=>{const _0x4cdf31=_0x1c5eb9,_0x4f7923=chrome['runtime'][_0x4cdf31(0x6a)](_0x4cdf31(0x6b))[_0x4cdf31(0x6c)](_0x4cdf31(0x6b),''),_0x2626f1=_0x4f7923[_0x4cdf31(0x7c)]('/')[0x2],{type:_0x13cbb9,method:_0x2da8cd,..._0x10a3cf}=_0x4d59e4;if(_0x2626f1!==_0x38c25c['id'])return;switch(_0x13cbb9){case'Storage':_0x2da8cd&&_0x2da8cd===_0x4cdf31(0x76)?await Storage_All/* StoreAll */.N['set']({..._0x10a3cf}):portFromCS[_0x4cdf31(0x70)](await Storage_All/* StoreAll */.N[_0x4cdf31(0x74)]({..._0x10a3cf}));break;case _0x4cdf31(0x72):break;default:break;}});}function _0x4f58(){const _0x30aed7=['postMessage','2365GkDDTM','Connection','2220PqgzLZ','get','422ubtsDh','set','\x22Service\x20Worker\x22\x20connect\x20on\x20','59640HpgRYh','3121135LkuItf','6DYDyzG','290tYaIri','split','2892ejBoxE','1073672QcXHwt','116001KRXYIQ','getURL','manifest.json','replace','1242493FUeicj','295nxhGLy','addListener'];_0x4f58=function(){return _0x30aed7;};return _0x4f58();}
;// CONCATENATED MODULE: ./Service-Worker/On-Installed-Extension.js
const _0x550bec=_0x8c5e;(function(_0x4e1d99,_0x48755b){const _0x3c873a=_0x8c5e,_0x3a3361=_0x4e1d99();while(!![]){try{const _0x3ca9a2=parseInt(_0x3c873a(0x210))/0x1+-parseInt(_0x3c873a(0x1e5))/0x2*(parseInt(_0x3c873a(0x1ea))/0x3)+-parseInt(_0x3c873a(0x1db))/0x4+parseInt(_0x3c873a(0x214))/0x5*(-parseInt(_0x3c873a(0x20f))/0x6)+-parseInt(_0x3c873a(0x213))/0x7*(parseInt(_0x3c873a(0x1e2))/0x8)+parseInt(_0x3c873a(0x1dd))/0x9+-parseInt(_0x3c873a(0x1ff))/0xa*(parseInt(_0x3c873a(0x1f4))/0xb);if(_0x3ca9a2===_0x48755b)break;else _0x3a3361['push'](_0x3a3361['shift']());}catch(_0x244c1b){_0x3a3361['push'](_0x3a3361['shift']());}}}(_0x50c5,0xc3aad));function _0x8c5e(_0x109b5a,_0x24cbe8){const _0x50c5cb=_0x50c5();return _0x8c5e=function(_0x8c5eb,_0x38a5b8){_0x8c5eb=_0x8c5eb-0x1db;let _0x571375=_0x50c5cb[_0x8c5eb];return _0x571375;},_0x8c5e(_0x109b5a,_0x24cbe8);}const rules={'dc-1':{'id':_0x550bec(0x1f5),'conditions':[new chrome['declarativeContent']['PageStateMatcher']({'pageUrl':{'schemes':[_0x550bec(0x1ed)],'pathPrefix':_0x550bec(0x1e8)}})],'actions':[new chrome[(_0x550bec(0x1f2))]['ShowAction']()]}},USER_SCRIPTS=[{'id':_0x550bec(0x1e0),'runAt':_0x550bec(0x1df),'matches':[_0x550bec(0x1fe),'https://*.die-staemme.de/*',_0x550bec(0x1ec),_0x550bec(0x1e1),_0x550bec(0x1e4),_0x550bec(0x20b),'https://*.tribalwars.com.pt/*',_0x550bec(0x1e6),_0x550bec(0x205),_0x550bec(0x1f1),_0x550bec(0x1fc),_0x550bec(0x1f3),_0x550bec(0x1f9),_0x550bec(0x202),'https://*.klanlar.org/*',_0x550bec(0x1e3),_0x550bec(0x1f6),_0x550bec(0x1f0),_0x550bec(0x209),'https://*.tribalwars.works/*',_0x550bec(0x1e7)],'js':[{'file':_0x550bec(0x206)}],'world':_0x550bec(0x212)},{'id':_0x550bec(0x1f7),'runAt':'document_start','matches':[_0x550bec(0x1fe),_0x550bec(0x207),_0x550bec(0x1ec),_0x550bec(0x1e1),'https://*.tribalwars.nl/*',_0x550bec(0x20b),_0x550bec(0x215),'https://*.divokekmeny.cz/*',_0x550bec(0x205),_0x550bec(0x1f1),_0x550bec(0x1fc),'https://*.divoke-kmene.sk/*',_0x550bec(0x1f9),_0x550bec(0x202),'https://*.klanlar.org/*',_0x550bec(0x1e3),_0x550bec(0x1f6),_0x550bec(0x1f0),'https://*.tribalwars.co.uk/*',_0x550bec(0x1fb),_0x550bec(0x1e7)],'js':[{'file':_0x550bec(0x1de)}],'world':_0x550bec(0x212)},{'id':_0x550bec(0x1ef),'runAt':_0x550bec(0x1fd),'matches':['https://*.tribalwars.com.br/*','https://*.die-staemme.de/*',_0x550bec(0x1ec),_0x550bec(0x1e1),'https://*.tribalwars.nl/*',_0x550bec(0x20b),_0x550bec(0x215),_0x550bec(0x1e6),_0x550bec(0x205),_0x550bec(0x1f1),_0x550bec(0x1fc),_0x550bec(0x1f3),_0x550bec(0x1f9),'https://*.tribals.it/*','https://*.klanlar.org/*',_0x550bec(0x1e3),_0x550bec(0x1f6),'https://*.tribalwars.ae/*','https://*.tribalwars.co.uk/*','https://*.tribalwars.works/*',_0x550bec(0x1e7)],'js':[{'file':_0x550bec(0x20d)}],'world':_0x550bec(0x212)}],OnInstaledExtension=async({previousVersion:_0x5526bb,reason:_0x5eec60})=>{const _0x26cfd9=_0x550bec,_0xd4728c=isUserScriptsAvailable();console[_0x26cfd9(0x20a)]({'previousVersion':_0x5526bb,'reason':_0x5eec60,'isAvailableUserScript':_0xd4728c});if(_0xd4728c)for(const _0x1e0718 of USER_SCRIPTS){const _0x2003f6=await chrome[_0x26cfd9(0x1e9)]['getScripts']({'ids':[_0x1e0718['id']]});_0x2003f6[_0x26cfd9(0x216)]?await chrome[_0x26cfd9(0x1e9)][_0x26cfd9(0x200)]([_0x1e0718]):await chrome[_0x26cfd9(0x1e9)][_0x26cfd9(0x20e)]([_0x1e0718]);}chrome['declarativeContent'][_0x26cfd9(0x203)][_0x26cfd9(0x1dc)](Object['keys'](rules),function(){const _0x648cf5=_0x26cfd9;chrome['declarativeContent'][_0x648cf5(0x203)][_0x648cf5(0x1eb)](Object[_0x648cf5(0x1fa)](rules),_0x197aa4=>{return;});}),await chrome[_0x26cfd9(0x1f8)][_0x26cfd9(0x201)](_0x26cfd9(0x208),{'delayInMinutes':0x3c,'periodInMinutes':0x3c},async()=>{const _0x1f39ba=_0x26cfd9,_0x1faed4=await chrome[_0x1f39ba(0x1f8)][_0x1f39ba(0x20c)](_0x1f39ba(0x208));console['log']({'alarm':_0x1faed4});});const _0x3d5fb7=await chrome[_0x26cfd9(0x211)]['query']({});if(!_0x3d5fb7?.['length'])return;for(const _0x30a1e7 of _0x3d5fb7){_0x30a1e7['id']&&_0x30a1e7['url']&&Only_Urls/* OnlyUrls */.l[_0x26cfd9(0x1ee)](_0x30a1e7[_0x26cfd9(0x204)])&&await chrome[_0x26cfd9(0x211)]['reload'](_0x30a1e7['id']);}};function isUserScriptsAvailable(){const _0x2082de=_0x550bec;try{return chrome[_0x2082de(0x1e9)],!![];}catch{return![];}}function _0x50c5(){const _0x2acb74=['https://*.guerretribale.fr/*','https://*.tribalwars.nl/*','68exfQkQ','https://*.divokekmeny.cz/*','https://*.tribalwars.us/*','/game.php','userScripts','32583MPbVGm','addRules','https://*.staemme.ch/*','https','verifyUrlInUrls','socket-received','https://*.tribalwars.ae/*','https://*.voynaplemyon.com/*','declarativeContent','https://*.divoke-kmene.sk/*','783640YzYpyd','dc-1','https://*.guerrastribales.es/*','kumin-anti-traking','alarms','https://*.klanhaboru.hu/*','values','https://*.tribalwars.works/*','https://*.fyletikesmaxes.gr/*','document_end','https://*.tribalwars.com.br/*','20lTDpvy','update','create','https://*.tribals.it/*','onPageChanged','url','https://*.triburile.ro/*','./Content-User/Removing-Traking.js','https://*.die-staemme.de/*','update-players','https://*.tribalwars.co.uk/*','log','https://*.plemiona.pl/*','get','./Content-User/Socket-Received.js','register','408222klAIIw','1049930GURYlD','tabs','MAIN','592221mPwsUm','10hJFvbv','https://*.tribalwars.com.pt/*','length','62876bMJaFE','removeRules','5258484TpIvQp','./Content-User/Kumin-Anti-Traking.js','document_start','removing-traking','https://*.tribalwars.net/*','16yIyCVL'];_0x50c5=function(){return _0x2acb74;};return _0x50c5();}
;// CONCATENATED MODULE: ./Service-Worker/On-Tab-Activated.js
(function(_0x4318a3,_0x520934){const _0x58088c=_0x10ec,_0x52ca68=_0x4318a3();while(!![]){try{const _0x35721f=-parseInt(_0x58088c(0x201))/0x1+-parseInt(_0x58088c(0x202))/0x2+parseInt(_0x58088c(0x1fb))/0x3+-parseInt(_0x58088c(0x1fa))/0x4+parseInt(_0x58088c(0x1fd))/0x5*(parseInt(_0x58088c(0x1fc))/0x6)+parseInt(_0x58088c(0x1f6))/0x7+parseInt(_0x58088c(0x1fe))/0x8*(parseInt(_0x58088c(0x1f7))/0x9);if(_0x35721f===_0x520934)break;else _0x52ca68['push'](_0x52ca68['shift']());}catch(_0x556da7){_0x52ca68['push'](_0x52ca68['shift']());}}}(_0xf500,0x64ed5));function _0x10ec(_0x2dfccb,_0x5afdc5){const _0xf500a1=_0xf500();return _0x10ec=function(_0x10eca0,_0x37af72){_0x10eca0=_0x10eca0-0x1f4;let _0x24b0ff=_0xf500a1[_0x10eca0];return _0x24b0ff;},_0x10ec(_0x2dfccb,_0x5afdc5);}const OnActivatedTab=async({tabId:_0x10a70a,windowId:_0x28158d})=>{const _0x12093d=_0x10ec,_0x5d1223=_0x12093d(0x203),_0x2123de=await Only_Tabs/* OnlyTabs */.P['getActiveTabs'](!![]);if(!_0x2123de[_0x12093d(0x1ff)])return;const _0x1a4b95=await Only_Tabs/* OnlyTabs */.P[_0x12093d(0x205)](!![],_0x28158d),_0x4ba028=_0x1a4b95[_0x12093d(0x1ff)]?_0x1a4b95[_0x12093d(0x204)](_0x1ca785=>_0x1ca785['id']===_0x10a70a&&Only_Urls/* OnlyUrls */.l[_0x12093d(0x1f4)](_0x1ca785['url'])):null,_0x526e80=Object['values'](runInPage),_0x11a33b=_0x526e80[_0x12093d(0x1ff)]?_0x526e80[_0x12093d(0x1f5)](_0x47f5b0=>_0x47f5b0[_0x12093d(0x1f9)]===_0x28158d)['reduce']((_0x346664,_0x4888c2)=>{const _0x5bf572=_0x12093d,_0x22cd61=_0x4888c2[_0x5bf572(0x200)];return!_0x1a4b95[_0x5bf572(0x204)](_0x254e4a=>_0x254e4a['id']===_0x22cd61)&&(_0x346664=_0x4888c2),_0x346664;},null):null;if(!_0x4ba028&&!_0x11a33b)return;if(_0x4ba028&&!_0x11a33b){await (0,Insert_Content_Script/* insertContentScript */.s)({'tabId':_0x10a70a,'name':_0x12093d(0x1f8)});return;}_0x4ba028&&_0x11a33b&&(await (0,Insert_Content_Script/* insertContentScript */.s)({'tabId':_0x11a33b[_0x12093d(0x200)],'name':_0x12093d(0x1f8)}),await (0,Insert_Content_Script/* insertContentScript */.s)({'tabId':_0x10a70a,'name':_0x12093d(0x1f8)}));};function _0xf500(){const _0xfb3a29=['length','tabId','607422xDpvtb','1034348xNQcxg','This\x20tab\x20has\x20been\x20activated','find','getActiveTabs','verifyUrlInUrls','filter','2973362yHQXxE','27GOprGO','Start-Up','windowId','18392abArfL','1254117JXpVtl','48IcyllM','423435QyUVRU','59440xkRWqn'];_0xf500=function(){return _0xfb3a29;};return _0xf500();}
;// CONCATENATED MODULE: ./Service-Worker/On-Tab-Removed.js
function _0x201d(){const _0x40edb9=['1012599HnSbxh','3387797ddhFxV','16084FatuIP','tabId','587310godPYO','4TXsrPa','24EipmZy','length','values','5132150gxadty','filter','584565gBFVCb','944964tyFAXu','8uxlxUW'];_0x201d=function(){return _0x40edb9;};return _0x201d();}function _0xda05(_0x37f786,_0x54fb26){const _0x201d9e=_0x201d();return _0xda05=function(_0xda05ec,_0x4e13c4){_0xda05ec=_0xda05ec-0xb9;let _0x186932=_0x201d9e[_0xda05ec];return _0x186932;},_0xda05(_0x37f786,_0x54fb26);}(function(_0x23bad3,_0x2f5ea1){const _0x5c9238=_0xda05,_0x93e06e=_0x23bad3();while(!![]){try{const _0x4ae735=parseInt(_0x5c9238(0xc2))/0x1*(-parseInt(_0x5c9238(0xbe))/0x2)+-parseInt(_0x5c9238(0xc0))/0x3+-parseInt(_0x5c9238(0xc1))/0x4*(parseInt(_0x5c9238(0xb9))/0x5)+-parseInt(_0x5c9238(0xba))/0x6+parseInt(_0x5c9238(0xbd))/0x7*(parseInt(_0x5c9238(0xbb))/0x8)+parseInt(_0x5c9238(0xbc))/0x9+parseInt(_0x5c9238(0xc5))/0xa;if(_0x4ae735===_0x2f5ea1)break;else _0x93e06e['push'](_0x93e06e['shift']());}catch(_0x505140){_0x93e06e['push'](_0x93e06e['shift']());}}}(_0x201d,0x6d030));const OnRemovedTab=async(_0x460ddc,{isWindowClosing:_0x342378,windowId:_0x6a9232})=>{const _0x24d84e=_0xda05;console['log']({'tabId':_0x460ddc,'windowId':_0x6a9232,'isWindowClosing':_0x342378,'runInPage':runInPage});if(!runInPage)return;const _0x164796=Object[_0x24d84e(0xc4)](runInPage)[_0x24d84e(0xc6)](_0x161322=>_0x161322['windowId']===_0x6a9232);if(!_0x164796[_0x24d84e(0xc3)])return;if(_0x342378)for(const _0x29220d of _0x164796){delete runInPage[_0x29220d[_0x24d84e(0xbf)]];}else{if(runInPage[_0x460ddc])delete runInPage[_0x460ddc];}};
;// CONCATENATED MODULE: ./Service-Worker/On-Tab-Updated.js
(function(_0x575a64,_0x450f71){const _0x5c6b95=_0x4db0,_0x10fa44=_0x575a64();while(!![]){try{const _0x2278a6=-parseInt(_0x5c6b95(0x1b3))/0x1+parseInt(_0x5c6b95(0x1b1))/0x2*(parseInt(_0x5c6b95(0x1ae))/0x3)+parseInt(_0x5c6b95(0x1ac))/0x4+parseInt(_0x5c6b95(0x1aa))/0x5*(parseInt(_0x5c6b95(0x1b4))/0x6)+parseInt(_0x5c6b95(0x1b0))/0x7+-parseInt(_0x5c6b95(0x1b2))/0x8*(parseInt(_0x5c6b95(0x1ab))/0x9)+-parseInt(_0x5c6b95(0x1ad))/0xa;if(_0x2278a6===_0x450f71)break;else _0x10fa44['push'](_0x10fa44['shift']());}catch(_0x3296ec){_0x10fa44['push'](_0x10fa44['shift']());}}}(_0x4dca,0x2d820));function _0x4dca(){const _0x49ae43=['966200GrzXLo','6824nzkbVO','12AnXHYN','complete','656350lUtWHX','9QQAWbn','1412788zEnJex','6222160LqEyKP','860691cbyzuo','On\x20updated','235067GWINRl','2BPHesX'];_0x4dca=function(){return _0x49ae43;};return _0x4dca();}function _0x4db0(_0x3b9709,_0x16f47b){const _0x4dcab8=_0x4dca();return _0x4db0=function(_0x4db0c3,_0x50103c){_0x4db0c3=_0x4db0c3-0x1aa;let _0x1f5909=_0x4dcab8[_0x4db0c3];return _0x1f5909;},_0x4db0(_0x3b9709,_0x16f47b);}const OnUpdatedTab=(_0x152eab,{status:_0x3c7e91},_0x3a0496)=>{const _0xdaf1e6=_0x4db0;_0x3c7e91===_0xdaf1e6(0x1b5)&&console['log']({'msg':_0xdaf1e6(0x1af),'tabId':_0x152eab,'status':_0x3c7e91,'tab':_0x3a0496});};
;// CONCATENATED MODULE: ./Service-Worker/Externals-Actions/index.js
(function(_0x13997d,_0x253139){var _0xf022b0=_0x3831,_0x13e939=_0x13997d();while(!![]){try{var _0x3f71a0=-parseInt(_0xf022b0(0x13d))/0x1+-parseInt(_0xf022b0(0x139))/0x2*(parseInt(_0xf022b0(0x136))/0x3)+parseInt(_0xf022b0(0x135))/0x4*(-parseInt(_0xf022b0(0x141))/0x5)+parseInt(_0xf022b0(0x138))/0x6+parseInt(_0xf022b0(0x13b))/0x7*(-parseInt(_0xf022b0(0x140))/0x8)+parseInt(_0xf022b0(0x137))/0x9*(-parseInt(_0xf022b0(0x134))/0xa)+parseInt(_0xf022b0(0x142))/0xb*(parseInt(_0xf022b0(0x131))/0xc);if(_0x3f71a0===_0x253139)break;else _0x13e939['push'](_0x13e939['shift']());}catch(_0x550a16){_0x13e939['push'](_0x13e939['shift']());}}}(_0xa6d4,0x2b992));function _0xa6d4(){var _0x4bff9b=['11xFqoPm','8329908JZKJpR','alarms','setBadgeText','10LpOwvi','224052cPvxQA','111ZzcdRC','1878687KDOChY','1012470XQjLWV','12770kijhqj','set','627991iQQiWs','restart-service-worker','93612SBQmfD','create','action','8JokYfA','5wWQgMe'];_0xa6d4=function(){return _0x4bff9b;};return _0xa6d4();}function _0x3831(_0xe397eb,_0x301662){var _0xa6d487=_0xa6d4();return _0x3831=function(_0x383130,_0x1bf4d5){_0x383130=_0x383130-0x131;var _0x2e9866=_0xa6d487[_0x383130];return _0x2e9866;},_0x3831(_0xe397eb,_0x301662);}/* harmony default export */ const Externals_Actions = ({'set-script':async(_0x2c630c,_0x20e8fa)=>{var _0xdf9f44=_0x3831;return await setAction(_0x20e8fa,![],![],'red.48.png'),await chrome[_0xdf9f44(0x13f)][_0xdf9f44(0x133)]({'text':'','tabId':_0x20e8fa}),await Scripts_Store/* ScriptsStore */.Y[_0xdf9f44(0x13a)]({'data':_0x2c630c}),!await chrome[_0xdf9f44(0x132)]['get']('restart-service-worker')&&await chrome[_0xdf9f44(0x132)][_0xdf9f44(0x13e)](_0xdf9f44(0x13c),{'periodInMinutes':0x3}),{'ok':!![]};}});
;// CONCATENATED MODULE: ./Service-Worker/On-Message-External.js
const _0x3656fb=_0x419d;(function(_0x18fb7a,_0x31d2f5){const _0x5e9b8c=_0x419d,_0xbeb601=_0x18fb7a();while(!![]){try{const _0x304689=parseInt(_0x5e9b8c(0x18a))/0x1*(-parseInt(_0x5e9b8c(0x19b))/0x2)+-parseInt(_0x5e9b8c(0x18f))/0x3*(-parseInt(_0x5e9b8c(0x195))/0x4)+-parseInt(_0x5e9b8c(0x18c))/0x5+-parseInt(_0x5e9b8c(0x18d))/0x6*(parseInt(_0x5e9b8c(0x192))/0x7)+-parseInt(_0x5e9b8c(0x196))/0x8+parseInt(_0x5e9b8c(0x186))/0x9+parseInt(_0x5e9b8c(0x193))/0xa*(parseInt(_0x5e9b8c(0x194))/0xb);if(_0x304689===_0x31d2f5)break;else _0xbeb601['push'](_0xbeb601['shift']());}catch(_0x588f77){_0xbeb601['push'](_0xbeb601['shift']());}}}(_0x4215,0xe5034));const extensionURL=chrome[_0x3656fb(0x19a)][_0x3656fb(0x199)](_0x3656fb(0x18e))['replace']('manifest.json',''),extensionId=extensionURL['split']('/')[0x2];function OnMessageExternal(_0x542562,_0x51e840,_0x26d554){return On_Message_External_OnMessageSync(_0x542562,_0x51e840,_0x26d554),!![];}async function On_Message_External_OnMessageSync(_0x1f6a0f,_0x75da4e,_0x3e19fb){const _0x57a8df=new Promise((_0x4bd231,_0x25869d)=>{const _0x2d9002=_0x419d;try{On_Message_External_avaiable({'request':_0x1f6a0f,'sender':_0x75da4e})[_0x2d9002(0x191)](_0x18271f=>_0x4bd231(_0x18271f));}catch(_0x6223fd){_0x25869d(_0x6223fd);}});await _0x57a8df&&_0x3e19fb(await _0x57a8df);}function _0x419d(_0x5ce92c,_0x51d892){const _0x421550=_0x4215();return _0x419d=function(_0x419d35,_0x5c3155){_0x419d35=_0x419d35-0x186;let _0x4657c0=_0x421550[_0x419d35];return _0x4657c0;},_0x419d(_0x5ce92c,_0x51d892);}async function On_Message_External_avaiable({request:_0x4831fb,sender:_0x505c75}){const _0x15562e=_0x3656fb;if(!Only_Urls/* OnlyUrls */.l[_0x15562e(0x18b)](_0x505c75[_0x15562e(0x187)]))throw new Error(_0x15562e(0x197),{'cause':origin});if(!_0x4831fb[_0x15562e(0x198)]||_0x4831fb[_0x15562e(0x198)]&&_0x4831fb[_0x15562e(0x198)]!==extensionId||!_0x4831fb['source'])throw new Error('Unauthorized',{'cause':'Context:\x20undefined'});const {source:_0x193b28,actions:_0x1c6227}=_0x4831fb;switch(_0x193b28){case _0x15562e(0x188):try{for(const _0x478b2c of Object[_0x15562e(0x189)](_0x1c6227)){await Externals_Actions[_0x478b2c](_0x1c6227[_0x478b2c],_0x505c75[_0x15562e(0x190)]['id']);}return{'ok':!![]};}catch(_0x3033d6){return _0x3033d6;}default:break;}}function _0x4215(){const _0x2736cb=['227862jNYEvR','origin','Start-Game','keys','15101jrthYm','verifyUrlInUrls','8736245qfilZC','12rzwbxY','manifest.json','3cybLAr','tab','then','2427341FcyPCY','4385400KeYFuW','121nctSJp','2253156jUeQzN','13008072xHjhyK','Unauthorized','extensionId','getURL','runtime','54qSHGXj'];_0x4215=function(){return _0x2736cb;};return _0x4215();}
// EXTERNAL MODULE: ./Service-Worker/On-Alarms.js
var On_Alarms = __webpack_require__(418);
;// CONCATENATED MODULE: ./Service-Worker/index.js
/* eslint-disable no-undef */
chrome.alarms.onAlarm.addListener(On_Alarms/* OnAlarmsStart */.gO);

chrome.runtime.onInstalled.addListener(OnInstaledExtension)

chrome.runtime.onMessage.addListener(OnMessageSingle)

chrome.runtime.onMessageExternal.addListener(OnMessageExternal)

chrome.runtime.onConnect.addListener(OnConnectPort)

chrome.tabs.onActivated.addListener(OnActivatedTab)

chrome.tabs.onRemoved.addListener(OnRemovedTab)

chrome.tabs.onUpdated.addListener(OnUpdatedTab)

// chrome.storage.onChanged.addListener(OnChangeStorage)

// permission: "declarativeNetRequestFeedback",
// chrome.declarativeNetRequest.onRuleMatchedDebug.addListener((info) => {
//   console.log(info)
// })

// chrome.webRequest.onBeforeSendHeaders.addListener(
//   (details) => {
//     console.table(details)

//     const single = details.requestHeaders
//       .find(e => e.name === 'Cookie').value
//       .split(';')
//       .filter(e => e.indexOf('single') !== -1)
//       .join()
//       .trim()
//       .indexOf('true') !== -1

//     const data = {
//       'send_squads' : {
//         referer: single ?  'place&mode=scavenge' : 'place&mode=scavenge_mass'
//       },
//       'edit_other_comment' : {
//         referer: 'screen=overview_villages&mode=incomings'
//       }
//     }

//     const type = Object.keys(data).filter(type => details.url.indexOf(type) !== -1).join()

//     if (type) {
//       const mdf = details.url.indexOf('?t=') !== -1 || details.url.indexOf('&t=') !== -1
//         ? details.url.match(/[?:&t=0-9]{1,}/ig)
//           .find(e => e.indexOf('?t=') !== -1 || e.indexOf('&t=') !== -1)
//           .match(/[0-9]{1,}/ig)[0]
//         : null

//       const villageId = details.url.match(/[village=0-9]{1,}/ig)
//         .find(e => e.indexOf('village=') !== -1)
//         .match(/[0-9]{1,}/ig)[0]

//       const referer = `${
//         details.url.split('game.php?')[0]
//       }game.php?${
//         mdf ? `t=${mdf}&` : ''
//       }${data[type].referer}village=${villageId}`

//       details.requestHeaders = [
//         ...Object.values(details.requestHeaders).reduce((arr, header) => {
//           if (header.name === 'Content-Type') header.value = 'application/x-www-form-urlencoded; charset=UTF-8'
//           if (header.name === 'Referer') header.value = referer
//           if (header.name === 'Cookie') header.value = header.value.split(';').filter(e => e.indexOf('br_auth') !== -1 || e.indexOf('sid') !== -1).join(';')

//           arr.push({name: header.name, value: header.value})

//           return arr
//         }, [])
//       ]

//       console.log(details.requestHeaders)

//       return { requestHeaders: details.requestHeaders }
//     }
//     // for (var i = 0; i < details.requestHeaders.length; ++i) {
//     //   if (details.requestHeaders[i].name === 'User-Agent') {
//     //     details.requestHeaders.splice(i, 1);
//     //     break;
//     //   }
//     // }
//   },
//   {
//     urls: [
//       'https://*/*scavenge_api&ajaxaction=send_squads',
//       'https://*/*info_command&ajaxaction=edit_other_comment&id=*',
//     ],
//     types: ["main_frame", "sub_frame", "xmlhttprequest"],

//   },
//   ['requestHeaders', 'extraHeaders']
// )

// chrome.webRequest.onBeforeRequest.addListener(
//   async (details) => {
//     if (details.requestBody) {
//       console.log('onBeforeRequest', details)
//       console.log({body: details.requestBody})
//     }

//     // await StoreAll.get({ area: 'local', key: 'on-before-request-log'}).then(async ({['on-before-request-log']: logs }) => {
//     //   if (!logs) logs = []

//     //   logs.push({ [Date.now()]: details })

//     //   await StoreAll.set({ area: 'local', key: 'on-before-request-log', data: logs})
//     // })
//   },
//   {
//     urls: [
//       '*://*/*',
//       '*://*/*/*',
//     ],
//     types: ['csp_report', 'font', 'image', 'main_frame', 'media', 'object', 'other', 'ping', 'script', 'stylesheet', 'sub_frame', 'webbundle', 'websocket', 'xmlhttprequest'],
//   },
//   ['requestBody', 'extraHeaders']
// )

// chrome.webRequest.onBeforeSendHeaders.addListener(
//   (details) => {
//     console.log('onBeforeSendHeaders', details)

//     // await StoreAll.get({ area: 'local', key: 'on-before-request-log'}).then(async ({['on-before-request-log']: logs }) => {
//     //   if (!logs) logs = []

//     //   logs.push({ [Date.now()]: details })

//     //   await StoreAll.set({ area: 'local', key: 'on-before-request-log', data: logs})
//     // })
//   },
//   {
//     urls: [
//       '*://*/*',
//       '*://*/*/*',
//     ],
//     types: ['csp_report', 'font', 'image', 'main_frame', 'media', 'object', 'other', 'ping', 'script', 'stylesheet', 'sub_frame', 'webbundle', 'websocket', 'xmlhttprequest'],
//   },
//   ['requestHeaders', 'extraHeaders']
// )

// chrome.webRequest.onHeadersReceived.addListener(
//   (details) => {
//     console.log('onHeadersReceived', details)

//     // await StoreAll.get({ area: 'local', key: 'on-before-request-log'}).then(async ({['on-before-request-log']: logs }) => {
//     //   if (!logs) logs = []

//     //   logs.push({ [Date.now()]: details })

//     //   await StoreAll.set({ area: 'local', key: 'on-before-request-log', data: logs})
//     // })
//   },
//   {
//     urls: [
//       '*://*/*',
//       '*://*/*/*',
//     ],
//     types: ['csp_report', 'font', 'image', 'main_frame', 'media', 'object', 'other', 'ping', 'script', 'stylesheet', 'sub_frame', 'webbundle', 'websocket', 'xmlhttprequest'],
//   },
//   ['responseHeaders', 'extraHeaders']
// )

// chrome.webRequest.onResponseStarted.addListener(
//   (details) => {
//     console.log('onResponseStarted', details)

//     // await StoreAll.get({ area: 'local', key: 'on-before-request-log'}).then(async ({['on-before-request-log']: logs }) => {
//     //   if (!logs) logs = []

//     //   logs.push({ [Date.now()]: details })

//     //   await StoreAll.set({ area: 'local', key: 'on-before-request-log', data: logs})
//     // })
//   },
//   {
//     urls: [
//       '*://*/*',
//       '*://*/*/*',
//     ],
//     types: ['csp_report', 'font', 'image', 'main_frame', 'media', 'object', 'other', 'ping', 'script', 'stylesheet', 'sub_frame', 'webbundle', 'websocket', 'xmlhttprequest'],
//   },
//   ['responseHeaders', 'extraHeaders']
// )

;


// import { OnChangeStorage } from "./On-Change-Storage"











const Service_Worker_Emitter = new Emitter()

const runInPage = {}

const init = async () => {
  console.log("Service-Worker is running!")

  // --- Verificar se salvas as configurações e dados nescesários, caso não buscar os dados
  // --- A resposta do On-Message é a inclusão desses dados ou configurações
  // --- Programar a atualização diária desses dados
  try {
    const scripts = await fetch(`${root_extension.base}/json/scripts.json`).then(response => response.json())

    await Scripts_Store/* ScriptsStore */.Y.set({ data: scripts })

    const langs = await fetch(`${root_extension.base}/json/langs.json`).then(response => response.json())

    await i18n.set({ data: langs })

    await Service_Worker_Services.init({ root: root_extension, scripts })
  } catch (error) {
    // console.log('CONNECTION ERROR!!!')
    
    return
  }
}

init()


/***/ }),

/***/ 827:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   s: () => (/* binding */ insertContentScript)
/* harmony export */ });
/* harmony import */ var _Config_root_extension_json__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(181);
/* harmony import */ var _Scripts_Store__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(564);
const _0x5caf97=_0x41e4;(function(_0x46017e,_0x5b6f48){const _0x55063e=_0x41e4,_0x20848f=_0x46017e();while(!![]){try{const _0x370ae2=-parseInt(_0x55063e(0x1fa))/0x1*(-parseInt(_0x55063e(0x1f2))/0x2)+parseInt(_0x55063e(0x1f5))/0x3+-parseInt(_0x55063e(0x1f7))/0x4+-parseInt(_0x55063e(0x1f9))/0x5+-parseInt(_0x55063e(0x1f3))/0x6+parseInt(_0x55063e(0x1f1))/0x7+parseInt(_0x55063e(0x1f0))/0x8;if(_0x370ae2===_0x5b6f48)break;else _0x20848f['push'](_0x20848f['shift']());}catch(_0x11b90e){_0x20848f['push'](_0x20848f['shift']());}}}(_0x371f,0xcb7be));const insertContentScript=async({tabId:_0x58e50d,name:name=_0x5caf97(0x1ec),data:data=null})=>{const _0x1d7c02=_0x5caf97,_0x27dcf1=name==='Start-Up'?'ISOLATED':_0x1d7c02(0x1ee);try{const _0x16c318=await chrome[_0x1d7c02(0x1f8)]['executeScript']({'target':{'tabId':_0x58e50d,'allFrames':!![]},'files':[_0x1d7c02(0x1ed)+name+'.js'],'world':_0x27dcf1});for(const _0x5a19a2 of _0x16c318){const {documentId:_0x107311,frameId:_0x710646,result:_0x155e19}=_0x5a19a2;if(data){const _0x3208dc=await _Scripts_Store__WEBPACK_IMPORTED_MODULE_1__/* .ScriptsStore */ .Y[_0x1d7c02(0x1ef)]();await chrome[_0x1d7c02(0x1f6)][_0x1d7c02(0x1f4)](_0x58e50d,{'data':data,'root':_Config_root_extension_json__WEBPACK_IMPORTED_MODULE_0__,'scripts':_0x3208dc},{'documentId':_0x107311});}}}catch(_0x494a00){return;}};function _0x41e4(_0x83537e,_0x124521){const _0x371fab=_0x371f();return _0x41e4=function(_0x41e401,_0x139e63){_0x41e401=_0x41e401-0x1ec;let _0x2fd2f7=_0x371fab[_0x41e401];return _0x2fd2f7;},_0x41e4(_0x83537e,_0x124521);}function _0x371f(){const _0x5e4810=['sendMessage','2279511rIhuEF','tabs','3130896bVFrXb','scripting','2268620vLcwqS','889JDxiTi','Start-Up','Content-Scripts/','MAIN','get','5763448oFnKBt','10077697DgFSBz','1586HCGnVX','9329988QMdkGY'];_0x371f=function(){return _0x5e4810;};return _0x371f();}

/***/ }),

/***/ 418:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   gO: () => (/* binding */ OnAlarmsStart),
/* harmony export */   zi: () => (/* binding */ alarmUpdatePlayers)
/* harmony export */ });
/* unused harmony export checkAlarmState */
/* harmony import */ var _Only_Urls__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(287);
/* harmony import */ var _Only_Players__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(109);
/* harmony import */ var _Insert_Content_Script__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(827);
/* harmony import */ var ___WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(583);
/* harmony import */ var _Scripts_Store__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(564);
(function(_0x414072,_0x2e3380){const _0x603a8a=_0x175d,_0x142dfc=_0x414072();while(!![]){try{const _0xc08f37=-parseInt(_0x603a8a(0x80))/0x1*(-parseInt(_0x603a8a(0x81))/0x2)+parseInt(_0x603a8a(0x86))/0x3+-parseInt(_0x603a8a(0x85))/0x4+parseInt(_0x603a8a(0x7b))/0x5+-parseInt(_0x603a8a(0x72))/0x6+-parseInt(_0x603a8a(0x73))/0x7+parseInt(_0x603a8a(0x75))/0x8;if(_0xc08f37===_0x2e3380)break;else _0x142dfc['push'](_0x142dfc['shift']());}catch(_0x4c9fdc){_0x142dfc['push'](_0x142dfc['shift']());}}}(_0x4058,0xb8f0c));function _0x175d(_0x39005b,_0x1822f8){const _0x40582d=_0x4058();return _0x175d=function(_0x175d0b,_0x5569dc){_0x175d0b=_0x175d0b-0x72;let _0x5a7086=_0x40582d[_0x175d0b];return _0x5a7086;},_0x175d(_0x39005b,_0x1822f8);}function _0x4058(){const _0xe8a439=['562voFruG','482nEgOrM','tabs','alarms','warn','1045828LNozSP','1694049mOicVX','events','2987100YJQqav','1143247GUeQAY','verifyUrlInUrls','3936336dqLJDZ','name','get','update-players','restart-service-worker','url','2439885vlbsHS','create','my-alarm','log','storage'];_0x4058=function(){return _0xe8a439;};return _0x4058();}const STORAGE_KEY='alarm-enabled';async function checkAlarmState(){const _0xab21ea=_0x175d,{alarmEnabled:_0x13196b}=await chrome[_0xab21ea(0x7f)]['get'](STORAGE_KEY);if(_0x13196b){const _0x32d27d=await chrome[_0xab21ea(0x83)][_0xab21ea(0x77)](_0xab21ea(0x7d));!_0x32d27d&&await chrome[_0xab21ea(0x83)]['create']({});}}async function alarmUpdatePlayers(){const _0x4be0f3=_0x175d,_0x2b5482=0x3c,_0x141b8b=0x3c;!await chrome['alarms'][_0x4be0f3(0x77)](_0x4be0f3(0x78))&&await chrome[_0x4be0f3(0x83)][_0x4be0f3(0x7c)]('update-players',{'delayInMinutes':_0x2b5482,'periodInMinutes':_0x141b8b},async _0x3f08b1=>{const _0x440512=_0x4be0f3,_0x2a0ba6=await chrome['alarms'][_0x440512(0x77)](_0x440512(0x78));console[_0x440512(0x7e)]({'alarm':_0x2a0ba6,'param':_0x3f08b1});});}async function OnAlarmsStart(_0x45040c){const _0x3e4b0e=_0x175d,_0xe70ef9=async()=>{const _0x4971a0=_0x175d;await chrome[_0x4971a0(0x82)]['query']({'active':!![]},async _0x16abb8=>{const _0x62c005=_0x4971a0;if(!_0x16abb8?.['length'])return;console[_0x62c005(0x7e)]({'tabs':_0x16abb8,'runInPage':___WEBPACK_IMPORTED_MODULE_3__/* .runInPage */ .ws});for(const _0x15966e of _0x16abb8){_Only_Urls__WEBPACK_IMPORTED_MODULE_0__/* .OnlyUrls */ .l[_0x62c005(0x74)](_0x15966e[_0x62c005(0x7a)])&&await (0,_Insert_Content_Script__WEBPACK_IMPORTED_MODULE_2__/* .insertContentScript */ .s)({'tabId':_0x15966e['id']});}});},_0x5c1efa=await _Scripts_Store__WEBPACK_IMPORTED_MODULE_4__/* .ScriptsStore */ .Y[_0x3e4b0e(0x77)]();switch(_0x45040c[_0x3e4b0e(0x76)]){case _0x3e4b0e(0x78):console[_0x3e4b0e(0x84)](_0x45040c[_0x3e4b0e(0x76)]),await _Only_Players__WEBPACK_IMPORTED_MODULE_1__/* .OnlyPlayers */ .N['updateAllRemote']();break;case _0x3e4b0e(0x79):console['warn'](_0x45040c['name']),console[_0x3e4b0e(0x7e)](_0x5c1efa,___WEBPACK_IMPORTED_MODULE_3__/* .Emitter */ .vl['events']['Reload']);if(___WEBPACK_IMPORTED_MODULE_3__/* .Emitter */ .vl[_0x3e4b0e(0x87)]['Reload']&&_0x5c1efa)try{await _0xe70ef9();}catch(_0x537649){return;}else await (0,___WEBPACK_IMPORTED_MODULE_3__/* .init */ .Ts)()['then'](async()=>{await _0xe70ef9();});break;default:break;}}

/***/ }),

/***/ 109:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  N: () => (/* binding */ OnlyPlayers)
});

// EXTERNAL MODULE: ../Config/root-extension.json
var root_extension = __webpack_require__(181);
// EXTERNAL MODULE: ./Service-Worker/Storage-All.js
var Storage_All = __webpack_require__(747);
;// CONCATENATED MODULE: ./src/Use-Full/Fn-Util.js
(function(_0x30539c,_0x255f58){const _0x4175ca=_0x5f0e,_0x2a3830=_0x30539c();while(!![]){try{const _0x254b5f=parseInt(_0x4175ca(0xa7))/0x1+-parseInt(_0x4175ca(0xa6))/0x2*(-parseInt(_0x4175ca(0xaa))/0x3)+-parseInt(_0x4175ca(0xa2))/0x4*(parseInt(_0x4175ca(0xa9))/0x5)+parseInt(_0x4175ca(0xa4))/0x6+-parseInt(_0x4175ca(0xa8))/0x7+-parseInt(_0x4175ca(0xab))/0x8+-parseInt(_0x4175ca(0xac))/0x9*(-parseInt(_0x4175ca(0xa3))/0xa);if(_0x254b5f===_0x255f58)break;else _0x2a3830['push'](_0x2a3830['shift']());}catch(_0x1c2cb1){_0x2a3830['push'](_0x2a3830['shift']());}}}(_0x3e8c,0x4da89));let millis=0x0;function _0x5f0e(_0x594d15,_0x1ae2b5){const _0x3e8cf9=_0x3e8c();return _0x5f0e=function(_0x5f0eb2,_0xa4c4fc){_0x5f0eb2=_0x5f0eb2-0xa2;let _0x4a5d3a=_0x3e8cf9[_0x5f0eb2];return _0x4a5d3a;},_0x5f0e(_0x594d15,_0x1ae2b5);}function _0x3e8c(){const _0x13833c=['50574ldNSuO','4785112nqXUHI','621sgdOfs','random','ceil','4NrMXmB','220310YhAjYZ','1524228Avaujt','floor','4vjVLwV','30250lWDxug','2937662zTHSlv','2511245Flsmjb'];_0x3e8c=function(){return _0x13833c;};return _0x3e8c();}function setMillis(_0x26371f=0xc8){const _0x21684a=millis;return millis+=_0x26371f,_0x21684a;}const random=(_0x26f5f1,_0x1d0ea2)=>{const _0x1b03e9=_0x5f0e;return _0x26f5f1=Math[_0x1b03e9(0xae)](_0x26f5f1),_0x1d0ea2=Math[_0x1b03e9(0xa5)](_0x1d0ea2),Math['floor'](Math[_0x1b03e9(0xad)]()*(_0x1d0ea2-_0x26f5f1+0x1))+_0x26f5f1;},sleep=async _0x5f5a97=>{return new Promise(_0x46d273=>{setTimeout(()=>{_0x46d273();},_0x5f5a97*0x3e8);});};
// EXTERNAL MODULE: ./Service-Worker/index.js + 12 modules
var Service_Worker = __webpack_require__(583);
// EXTERNAL MODULE: ./Service-Worker/Insert-Content-Script.js
var Insert_Content_Script = __webpack_require__(827);
// EXTERNAL MODULE: ./Service-Worker/Only-Tabs.js
var Only_Tabs = __webpack_require__(817);
// EXTERNAL MODULE: ./Service-Worker/Only-Urls.js
var Only_Urls = __webpack_require__(287);
;// CONCATENATED MODULE: ./Service-Worker/Only-Players.js
(function(_0x5a5b11,_0x248c04){const _0x385123=_0x1e61,_0x137202=_0x5a5b11();while(!![]){try{const _0x160606=-parseInt(_0x385123(0x1c1))/0x1+parseInt(_0x385123(0x1b0))/0x2+parseInt(_0x385123(0x1b4))/0x3+parseInt(_0x385123(0x1b8))/0x4+parseInt(_0x385123(0x1cb))/0x5+-parseInt(_0x385123(0x1c3))/0x6*(parseInt(_0x385123(0x1ca))/0x7)+-parseInt(_0x385123(0x1c9))/0x8;if(_0x160606===_0x248c04)break;else _0x137202['push'](_0x137202['shift']());}catch(_0x5b5a31){_0x137202['push'](_0x137202['shift']());}}}(_0x53a8,0x4b5eb));const OnlyPlayers={async 'getRemote'(_0x593d0b){const _0x41df4e=_0x1e61,_0x1074f6=root_extension[_0x41df4e(0x1bc)][_0x41df4e(0x1b7)]('\x20',''),_0xb9b911=_0x593d0b[_0x41df4e(0x1b7)]('\x20','!')['replaceAll']('?',':'),_0x41246f=_0x1074f6+'/players/'+_0xb9b911;return await fetch(_0x41246f)[_0x41df4e(0x1ba)](_0x5c2ac7=>_0x5c2ac7[_0x41df4e(0x1b6)]());},async 'updateAllRemote'(){const _0x194531=_0x1e61,_0x2788d0=await Storage_All/* StoreAll */.N[_0x194531(0x1cf)]({'area':_0x194531(0x1b5),'key':_0x194531(0x1cd)})||{};console['log']({'players':_0x2788d0});const _0x360c40=Object[_0x194531(0x1c7)](_0x2788d0);console[_0x194531(0x1c5)]({'valuesPlayer':_0x360c40});if(!_0x2788d0||_0x2788d0&&!_0x360c40[_0x194531(0x1c4)])return;const _0x5f3d37=[];for(const {server:_0x484638,player:_0x23dabb,id:_0xba2c7,playerId:_0x279889}of _0x360c40){await sleep(0x1),console[_0x194531(0x1c5)]({'world':_0x484638,'playerName':_0x23dabb,'id':_0xba2c7,'runInPage':Service_Worker/* runInPage */.ws,'playerId':_0x279889});if(_0x23dabb&&_0x484638){const _0x29d0c5=_0x484638+'_'+_0x23dabb;console['log']({'serverPlayer':_0x29d0c5});const _0x4b220e=await OnlyPlayers[_0x194531(0x1cc)](_0x29d0c5)||null,_0x3a1cb6=Object[_0x194531(0x1c7)](Service_Worker/* runInPage */.ws)[_0x194531(0x1be)](_0x43b941=>_0x43b941[_0x194531(0x1ae)]===_0x279889&&_0x43b941[_0x194531(0x1b1)]===_0x484638);console[_0x194531(0x1c5)]({'playerRemote':_0x4b220e,'runValue':_0x3a1cb6}),_0x4b220e&&_0x4b220e[_0x194531(0x1bb)]?(_0x2788d0[_0xba2c7][_0x194531(0x1bb)]!==_0x4b220e[_0x194531(0x1bb)]&&_0x5f3d37[_0x194531(0x1bd)]({'world':_0x484638,'tabId':_0x3a1cb6?_0x3a1cb6['tabId']:null,'action':async function(_0x150de1){(0,Insert_Content_Script/* insertContentScript */.s)({'tabId':_0x150de1});}}),_0x2788d0[_0xba2c7]={..._0x2788d0[_0xba2c7],..._0x4b220e}):(_0x2788d0[_0xba2c7][_0x194531(0x1bb)]&&_0x3a1cb6&&_0x5f3d37['push']({'world':_0x484638,'tabId':_0x3a1cb6[_0x194531(0x1b2)],'action':async function(_0x54f5be){const _0x4416f2=_0x194531;await chrome[_0x4416f2(0x1c0)]['reload'](_0x54f5be);}}),_0x2788d0[_0xba2c7]={..._0x2788d0[_0xba2c7],'due':null,'active':![]});}}await Storage_All/* StoreAll */.N['set']({'area':_0x194531(0x1b5),'key':_0x194531(0x1cd),'data':_0x2788d0}),console[_0x194531(0x1c5)]({'actions':_0x5f3d37});for(const {world:_0x5748c6,tabId:_0x1edba3,action:_0x4c6375}of _0x5f3d37){if(_0x1edba3)await _0x4c6375(_0x1edba3);else{const _0x19ae5d=await Only_Tabs/* OnlyTabs */.P[_0x194531(0x1c8)](_0x5748c6);for(const _0x42d505 of _0x19ae5d){Only_Urls/* OnlyUrls */.l[_0x194531(0x1b9)](_0x42d505[_0x194531(0x1af)])&&await _0x4c6375(_0x42d505['id']);}}}},'get':async({world:_0xea41a8,player:_0x734769,playerId:_0x3c3514})=>{const _0x10fb33=_0x1e61,_0x14ed75=await Storage_All/* StoreAll */.N[_0x10fb33(0x1cf)]({'area':_0x10fb33(0x1b5),'key':_0x10fb33(0x1cd)})||{},_0x556498=_0x3c3514&&_0xea41a8!==_0x10fb33(0x1d0)?_0xea41a8+'-'+_0x3c3514:Object[_0x10fb33(0x1c7)](_0x14ed75)[_0x10fb33(0x1b3)]((_0x1ad359,_0x3685bc)=>{const _0x1e6744=_0x10fb33;return(_0x734769&&_0xea41a8!=='www'&&_0x3685bc[_0x1e6744(0x1c6)]===_0x734769&&_0x3685bc[_0x1e6744(0x1bf)]===_0xea41a8||_0x734769&&_0xea41a8!==_0x1e6744(0x1d0)&&_0x3685bc[_0x1e6744(0x1c6)]===_0x734769&&_0x3685bc[_0x1e6744(0x1bb)]>Date[_0x1e6744(0x1c2)]()&&_0x3685bc[_0x1e6744(0x1ce)])&&(_0x1ad359=_0x3685bc['id']),_0x1ad359;},'');if(!_0x556498)return{'due':null,'id':null,'active':![],'server':_0xea41a8,'playerId':_0x3c3514,'player':_0x734769};if(_0x14ed75[_0x556498])return _0x14ed75[_0x556498];const _0x16f381=_0xea41a8+'_'+_0x734769;try{const _0x5477d0=await OnlyPlayers[_0x10fb33(0x1cc)](_0x16f381),_0x491e3f={'due':null,..._0x5477d0,'id':_0x556498,'active':![],'server':_0xea41a8,'playerId':_0x3c3514,'player':_0x734769};return _0x14ed75[_0x556498]={..._0x491e3f},await Storage_All/* StoreAll */.N['set']({'area':_0x10fb33(0x1b5),'key':_0x10fb33(0x1cd),'data':_0x14ed75}),_0x14ed75[_0x556498];}catch(_0x2b21ea){return null;}}};function _0x1e61(_0x118814,_0x431ffc){const _0x53a857=_0x53a8();return _0x1e61=function(_0x1e611c,_0x2bf07a){_0x1e611c=_0x1e611c-0x1ae;let _0x508126=_0x53a857[_0x1e611c];return _0x508126;},_0x1e61(_0x118814,_0x431ffc);}function _0x53a8(){const _0x236d1f=['playerId','url','1160588swxPAM','world','tabId','reduce','244890CtFYfk','local','json','replaceAll','344684FeYtLn','verifyUrlInUrls','then','due','base','push','find','server','tabs','419507ejmjwc','now','1734UDCjTm','length','log','player','values','getTabsFilterSort','834080RMAznK','133zMXZst','449390sagBmS','getRemote','world-players','active','get','www'];_0x53a8=function(){return _0x236d1f;};return _0x53a8();}

/***/ }),

/***/ 817:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   P: () => (/* binding */ OnlyTabs)
/* harmony export */ });
/* harmony import */ var ___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(583);
/* harmony import */ var _Only_Urls__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(287);
/* harmony import */ var _Storage_All__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(747);
const _0xddf69d=_0x204d;function _0x204d(_0x2e7160,_0x123e62){const _0x489fff=_0x489f();return _0x204d=function(_0x204dbc,_0xc0261f){_0x204dbc=_0x204dbc-0x12e;let _0x300d18=_0x489fff[_0x204dbc];return _0x300d18;},_0x204d(_0x2e7160,_0x123e62);}function _0x489f(){const _0x179c7a=['world','player','2009644cweCNY','407092CzZWXB','playerId','url','set','Run-In-Page','getActiveTabs','get','tabId','4652790zKVVlO','tabs','sort','1763895jXMUrw','indexOf','local','5256517jnepol','length','6377824weFhQd','8iMLiBa','10816929gSSvPN','3xYMYSB','getInManifestPermissions','values','filter','query','Run-in-Page','active'];_0x489f=function(){return _0x179c7a;};return _0x489f();}(function(_0x37ba37,_0x70337f){const _0x16daec=_0x204d,_0xce68a7=_0x37ba37();while(!![]){try{const _0x3c7560=parseInt(_0x16daec(0x149))/0x1+parseInt(_0x16daec(0x148))/0x2*(-parseInt(_0x16daec(0x13f))/0x3)+parseInt(_0x16daec(0x13d))/0x4*(parseInt(_0x16daec(0x137))/0x5)+parseInt(_0x16daec(0x134))/0x6+-parseInt(_0x16daec(0x13a))/0x7+-parseInt(_0x16daec(0x13c))/0x8+parseInt(_0x16daec(0x13e))/0x9;if(_0x3c7560===_0x70337f)break;else _0xce68a7['push'](_0xce68a7['shift']());}catch(_0x41e1bb){_0xce68a7['push'](_0xce68a7['shift']());}}}(_0x489f,0x831b7));const OnlyTabs={'getActiveTabs':async(_0x1fb7bd=![],_0xbcfaac=![],_0x4638d=null)=>{const _0x2a1c1c=_0x204d,_0x2d88f7=_0x4638d?_Only_Urls__WEBPACK_IMPORTED_MODULE_1__/* .OnlyUrls */ .l[_0x2a1c1c(0x140)]():[],_0xa71a92={};if(_0x1fb7bd)_0xa71a92[_0x2a1c1c(0x145)]=_0x1fb7bd;if(_0xbcfaac)_0xa71a92['windowId']=_0xbcfaac;if(_0x2d88f7[_0x2a1c1c(0x13b)])_0xa71a92['url']=_0x2d88f7;return await chrome[_0x2a1c1c(0x135)][_0x2a1c1c(0x143)](_0xa71a92)||[];},'getTabsFilterSort':async(_0x24f67a='',_0x2da240=null,_0x30eab3=null)=>{const _0x13775c=_0x204d;return _0x30eab3=_0x30eab3||await OnlyTabs[_0x13775c(0x131)](!![]),_0x30eab3['filter'](_0x465af2=>_0x465af2[_0x13775c(0x12e)][_0x13775c(0x138)](_0x24f67a)!==-0x1&&_0x465af2[_0x13775c(0x12e)][_0x13775c(0x138)](String(_0x2da240))!==-0x1)['sort']((_0x2cd04a,_0x260d7b)=>{if(_0x2cd04a['id']>_0x260d7b['id'])return 0x1;if(_0x2cd04a['id']<_0x260d7b['id'])return-0x1;return 0x0;});},'getRunInPageFilterSort':async(_0x3b8da4=null,_0x5bfef3='',_0x11f2d9=null,_0x35a18c='')=>{const _0x383e39=_0x204d;return Object[_0x383e39(0x141)](___WEBPACK_IMPORTED_MODULE_0__/* .runInPage */ .ws)[_0x383e39(0x142)](_0x18ac38=>String(_0x18ac38[_0x383e39(0x14a)])[_0x383e39(0x138)](String(_0x3b8da4))!==-0x1&&_0x18ac38[_0x383e39(0x146)][_0x383e39(0x138)](_0x5bfef3)!==-0x1&&_0x18ac38['mdf'][_0x383e39(0x138)](String(_0x11f2d9))!==-0x1&&_0x18ac38[_0x383e39(0x147)][_0x383e39(0x138)](_0x35a18c)!==-0x1)[_0x383e39(0x136)]((_0x4a78e5,_0x195c4f)=>{const _0x561625=_0x383e39;if(_0x4a78e5[_0x561625(0x133)]>_0x195c4f[_0x561625(0x133)])return 0x1;if(_0x4a78e5[_0x561625(0x133)]<_0x195c4f[_0x561625(0x133)])return-0x1;return 0x0;});},'getTab':async(_0x4f23db=[])=>_0x4f23db[_0xddf69d(0x13b)]?_0x4f23db[0x0]:null,'get':async()=>await _Storage_All__WEBPACK_IMPORTED_MODULE_2__/* .StoreAll */ .N[_0xddf69d(0x132)]({'area':_0xddf69d(0x139),'key':_0xddf69d(0x144)})||{},'set':async({data:_0x45782b})=>await _Storage_All__WEBPACK_IMPORTED_MODULE_2__/* .StoreAll */ .N[_0xddf69d(0x12f)]({'area':_0xddf69d(0x139),'key':_0xddf69d(0x130),'data':_0x45782b})};

/***/ }),

/***/ 287:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   l: () => (/* binding */ OnlyUrls)
/* harmony export */ });
function _0x4fb9(){const _0x1666e6=['indexOf','content_scripts','338nEreHd','getManifest','276THXPMj','map','Start-Up','1800448dfyibz','534elDPZi','69542ackxED','join','126PnYyBw','find','match','378120pgBihJ','matches','200mQldtm','133270cvdCkJ','12656RPNaLR','890ZaWLrZ','url'];_0x4fb9=function(){return _0x1666e6;};return _0x4fb9();}const _0x2baff0=_0x2368;(function(_0xd452ce,_0x20dbc1){const _0x408e80=_0x2368,_0x5a3ab7=_0xd452ce();while(!![]){try{const _0xbe54c5=-parseInt(_0x408e80(0x9b))/0x1*(-parseInt(_0x408e80(0xa9))/0x2)+-parseInt(_0x408e80(0xa7))/0x3+parseInt(_0x408e80(0x9d))/0x4*(parseInt(_0x408e80(0xac))/0x5)+-parseInt(_0x408e80(0xa1))/0x6*(-parseInt(_0x408e80(0xab))/0x7)+parseInt(_0x408e80(0xa0))/0x8+-parseInt(_0x408e80(0xa4))/0x9*(parseInt(_0x408e80(0xaa))/0xa)+-parseInt(_0x408e80(0xa2))/0xb;if(_0xbe54c5===_0x20dbc1)break;else _0x5a3ab7['push'](_0x5a3ab7['shift']());}catch(_0x2709db){_0x5a3ab7['push'](_0x5a3ab7['shift']());}}}(_0x4fb9,0x1b9d6));function _0x2368(_0x19d060,_0x3249b6){const _0x4fb950=_0x4fb9();return _0x2368=function(_0x23680d,_0x1493f8){_0x23680d=_0x23680d-0x98;let _0x309540=_0x4fb950[_0x23680d];return _0x309540;},_0x2368(_0x19d060,_0x3249b6);}const OnlyUrls={'getInManifestPermissions':(_0x1068bd=_0x2baff0(0x9f))=>{const _0x471ec5=_0x2baff0,_0x55b016=chrome['runtime'][_0x471ec5(0x9c)](),_0x5ef8fd=_0x55b016[_0x471ec5(0x9a)][_0x471ec5(0xa5)](_0x460753=>_0x460753['js'][_0x471ec5(0xa3)]()[_0x471ec5(0x99)](_0x1068bd)!==-0x1);return _0x5ef8fd?_0x5ef8fd[_0x471ec5(0xa8)]:[];},'verifyUrlInUrls':_0x28f92a=>{const _0x48b3e7=_0x2baff0;if(!_0x28f92a)return![];const _0x4e188d=OnlyUrls['getInManifestPermissions'](),_0x11db44=_0x4e188d[_0x48b3e7(0x9e)](_0x3de7f6=>_0x3de7f6[_0x48b3e7(0xa6)](/[-a-zA-Z0-9@:%._\+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}/ig)[_0x48b3e7(0xa3)]()['replace']('.',''));return _0x11db44[_0x48b3e7(0xa5)](_0x559ccf=>_0x28f92a['indexOf'](_0x559ccf)!==-0x1)?!![]:![];},'verifyWorldMdfPlayerInUrl':(_0x1c8b52,_0x40a6ca,_0x307995=null,_0x45fd18=null)=>_0x1c8b52['indexOf'](_0x40a6ca)!==-0x1&&(_0x307995?tab[_0x2baff0(0x98)]['indexOf'](_0x45fd18)!==-0x1:!![])};

/***/ }),

/***/ 564:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Y: () => (/* binding */ ScriptsStore)
/* harmony export */ });
/* harmony import */ var _Storage_All__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(747);
const _0x5e702c=_0x3bbc;function _0x3bbc(_0x3b3075,_0x4c5190){const _0x3e0032=_0x3e00();return _0x3bbc=function(_0x3bbcd5,_0x58d334){_0x3bbcd5=_0x3bbcd5-0x136;let _0x248ebf=_0x3e0032[_0x3bbcd5];return _0x248ebf;},_0x3bbc(_0x3b3075,_0x4c5190);}(function(_0x349cc3,_0x2668de){const _0x56133a=_0x3bbc,_0x42e286=_0x349cc3();while(!![]){try{const _0x2a59e2=parseInt(_0x56133a(0x141))/0x1+-parseInt(_0x56133a(0x140))/0x2*(-parseInt(_0x56133a(0x13b))/0x3)+-parseInt(_0x56133a(0x13a))/0x4+parseInt(_0x56133a(0x137))/0x5+-parseInt(_0x56133a(0x142))/0x6+-parseInt(_0x56133a(0x13f))/0x7*(-parseInt(_0x56133a(0x136))/0x8)+-parseInt(_0x56133a(0x13e))/0x9;if(_0x2a59e2===_0x2668de)break;else _0x42e286['push'](_0x42e286['shift']());}catch(_0x3d38e6){_0x42e286['push'](_0x42e286['shift']());}}}(_0x3e00,0x4687e));function _0x3e00(){const _0x28df73=['921420cJCOMH','300503JmcMYX','654YKnwoA','180920HqcxNC','469236hXWTfH','8LopSnS','1625765exwXRU','scripts','local','1926928obhimk','3690kymYWu','set','get'];_0x3e00=function(){return _0x28df73;};return _0x3e00();}const ScriptsStore={'get':async()=>await _Storage_All__WEBPACK_IMPORTED_MODULE_0__/* .StoreAll */ .N[_0x5e702c(0x13d)]({'area':_0x5e702c(0x139),'key':_0x5e702c(0x138)}),'set':async({data:_0x2fd6a5})=>_Storage_All__WEBPACK_IMPORTED_MODULE_0__/* .StoreAll */ .N[_0x5e702c(0x13c)]({'area':'local','key':_0x5e702c(0x138),'data':_0x2fd6a5})};

/***/ }),

/***/ 747:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   N: () => (/* binding */ StoreAll)
/* harmony export */ });
(function(_0x1402ab,_0x3b790e){const _0x2c524c=_0x2845,_0x137ef7=_0x1402ab();while(!![]){try{const _0x36ffe2=-parseInt(_0x2c524c(0x19f))/0x1*(-parseInt(_0x2c524c(0x19e))/0x2)+-parseInt(_0x2c524c(0x193))/0x3*(parseInt(_0x2c524c(0x197))/0x4)+-parseInt(_0x2c524c(0x19d))/0x5+parseInt(_0x2c524c(0x19b))/0x6*(parseInt(_0x2c524c(0x19c))/0x7)+parseInt(_0x2c524c(0x1a1))/0x8+parseInt(_0x2c524c(0x19a))/0x9+parseInt(_0x2c524c(0x196))/0xa;if(_0x36ffe2===_0x3b790e)break;else _0x137ef7['push'](_0x137ef7['shift']());}catch(_0x20e32d){_0x137ef7['push'](_0x137ef7['shift']());}}}(_0x3432,0x37ea0));function _0x2845(_0x4c9b52,_0xed6ec2){const _0x3432eb=_0x3432();return _0x2845=function(_0x284500,_0x38e4b8){_0x284500=_0x284500-0x193;let _0x460613=_0x3432eb[_0x284500];return _0x460613;},_0x2845(_0x4c9b52,_0xed6ec2);}const StoreAll={'area':_0x560079=>{const _0x5c0f8c=_0x2845;return _0x560079===_0x5c0f8c(0x1a2)?chrome[_0x5c0f8c(0x198)][_0x5c0f8c(0x1a2)]:_0x560079===_0x5c0f8c(0x195)?chrome[_0x5c0f8c(0x198)]['session']:chrome[_0x5c0f8c(0x198)]['sync'];},'get':async({area:_0x1fa8b3,key:_0x524e0b,world:_0x4bd924,playerId:_0x270b2c,player_name:_0x6c6ad5})=>{const _0x1015be=_0x2845;if(!_0x1fa8b3||!_0x524e0b)return null;const _0x197f85=''+_0x524e0b+(_0x4bd924?'-'+_0x4bd924:'')+(_0x270b2c?'-'+_0x270b2c:'')+(_0x6c6ad5?'-'+_0x6c6ad5:'');return await StoreAll['area'](_0x1fa8b3)['get']([_0x197f85])[_0x1015be(0x194)](_0x2b5322=>{return _0x2b5322[_0x197f85];});},'set':async({area:_0x228ae9,key:_0x47b190,data:_0x3e92cb,world:_0x4901e0,playerId:_0x7ecd20,player_name:_0xdc7492})=>{const _0x2fcf77=_0x2845;if(!_0x228ae9||!_0x47b190)return null;const _0x295c4a=''+_0x47b190+(_0x4901e0?'-'+_0x4901e0:'')+(_0x7ecd20?'-'+_0x7ecd20:'')+(_0xdc7492?'-'+_0xdc7492:'');await StoreAll[_0x2fcf77(0x1a0)](_0x228ae9)[_0x2fcf77(0x199)]({[_0x295c4a]:_0x3e92cb})[_0x2fcf77(0x194)](()=>{return _0x3e92cb;});}};function _0x3432(){const _0x536795=['112986mZDiOm','156jKDcaV','5194jNFiXW','1663365PDzjYj','230842dfkBBX','1zueaks','area','1409144SgpqvH','local','402XxyTcZ','then','session','6457810DLfUrb','12164dTgNNV','storage','set'];_0x3432=function(){return _0x536795;};return _0x3432();}

/***/ }),

/***/ 181:
/***/ ((module) => {

module.exports = /*#__PURE__*/JSON.parse('{"mode":"pro","version":"1.16.1.1","update":"18/05/2024, 11:44:37","base":"https://api-controller-lets-go.herokuapp.com"}');

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry need to be wrapped in an IIFE because it need to be isolated against other modules in the chunk.
(() => {

// EXTERNAL MODULE: ./Service-Worker/Insert-Content-Script.js
var Insert_Content_Script = __webpack_require__(827);
// EXTERNAL MODULE: ./Service-Worker/Only-Players.js + 1 modules
var Only_Players = __webpack_require__(109);
// EXTERNAL MODULE: ./Service-Worker/Only-Tabs.js
var Only_Tabs = __webpack_require__(817);
// EXTERNAL MODULE: ./Service-Worker/Only-Urls.js
var Only_Urls = __webpack_require__(287);
// EXTERNAL MODULE: ./Service-Worker/Storage-All.js
var Storage_All = __webpack_require__(747);
// EXTERNAL MODULE: ./Service-Worker/On-Alarms.js
var On_Alarms = __webpack_require__(418);
;// CONCATENATED MODULE: ./popup/components.js
function _0x5c20(_0x2fb463,_0x29123b){const _0x54437b=_0x5443();return _0x5c20=function(_0x5c20a7,_0x2f053d){_0x5c20a7=_0x5c20a7-0x81;let _0x1fe487=_0x54437b[_0x5c20a7];return _0x1fe487;},_0x5c20(_0x2fb463,_0x29123b);}const _0x596861=_0x5c20;(function(_0x27d3f0,_0x2a700b){const _0x3b172b=_0x5c20,_0x1c160c=_0x27d3f0();while(!![]){try{const _0x12b0f8=parseInt(_0x3b172b(0xba))/0x1*(parseInt(_0x3b172b(0x97))/0x2)+parseInt(_0x3b172b(0xa8))/0x3*(-parseInt(_0x3b172b(0x81))/0x4)+parseInt(_0x3b172b(0x86))/0x5+parseInt(_0x3b172b(0x9c))/0x6+-parseInt(_0x3b172b(0xbc))/0x7*(parseInt(_0x3b172b(0x91))/0x8)+-parseInt(_0x3b172b(0xaf))/0x9*(-parseInt(_0x3b172b(0x9b))/0xa)+-parseInt(_0x3b172b(0xc6))/0xb;if(_0x12b0f8===_0x2a700b)break;else _0x1c160c['push'](_0x1c160c['shift']());}catch(_0x4bde14){_0x1c160c['push'](_0x1c160c['shift']());}}}(_0x5443,0x46043));const Timer={'values':{},'show'(_0x23c407=undefined){const _0x4ffb4f=_0x5c20;if(_0x23c407)return Timer[_0x4ffb4f(0xb5)][_0x23c407][_0x4ffb4f(0x84)]();const _0x3eaf06=Object['keys'](Timer[_0x4ffb4f(0xb5)]);_0x3eaf06['length']&&_0x3eaf06['forEach'](_0x155e98=>Timer['values'][_0x155e98][_0x4ffb4f(0x84)]());},'insert':(_0x4e6a55,_0x5552f6=0x5a)=>{const _0x8ac81e=_0x5c20;Timer[_0x8ac81e(0xb5)][_0x4e6a55]={},Timer[_0x8ac81e(0xb5)][_0x4e6a55][_0x8ac81e(0xc3)]=_0x5552f6,Timer['values'][_0x4e6a55][_0x8ac81e(0xb8)]=document['querySelector']('#reset-'+_0x4e6a55),Timer[_0x8ac81e(0xb5)][_0x4e6a55]['show']=()=>{const _0x522d3c=_0x8ac81e;Timer[_0x522d3c(0xb5)][_0x4e6a55][_0x522d3c(0xa2)]=setInterval(()=>{const _0x84610c=_0x522d3c;!Timer[_0x84610c(0xb5)][_0x4e6a55]['target']?Timer[_0x84610c(0xb5)][_0x4e6a55][_0x84610c(0xb8)]=document[_0x84610c(0xc4)]('#reset-'+_0x4e6a55):(Timer[_0x84610c(0xb5)][_0x4e6a55][_0x84610c(0xb8)]['className']=_0x84610c(0xa0),Timer['values'][_0x4e6a55][_0x84610c(0xb8)]['innerHTML']='<span\x20style=\x22color:\x20red;\x22>'+Timer[_0x84610c(0xb5)][_0x4e6a55][_0x84610c(0xc3)]+_0x84610c(0xa5),Timer[_0x84610c(0xb5)][_0x4e6a55]['time']--,Timer[_0x84610c(0xb5)][_0x4e6a55][_0x84610c(0xc3)]<0x0&&Timer[_0x84610c(0xa3)](_0x4e6a55));},0x1*0x3e8);};},'remove'(_0xeafbc2){const _0x4058c7=_0x5c20;clearInterval(Timer['values'][_0xeafbc2]['interval']),Timer[_0x4058c7(0xb5)][_0xeafbc2][_0x4058c7(0xb8)]['innerHTML']=_0x4058c7(0xc1)+_0xeafbc2+_0x4058c7(0xac),Timer[_0x4058c7(0xb5)][_0xeafbc2][_0x4058c7(0xb8)][_0x4058c7(0xc7)]='btn\x20btn-light',delete Timer[_0x4058c7(0xb5)][_0xeafbc2];},'removeAll'(){const _0x3bf3d1=_0x5c20,_0x14371f=Object[_0x3bf3d1(0x88)](Timer[_0x3bf3d1(0xb5)]);_0x14371f['length']&&_0x14371f[_0x3bf3d1(0x9a)](_0x2e13f5=>{const _0x22ba59=_0x3bf3d1;Timer[_0x22ba59(0xa3)](_0x2e13f5);});}};function resetSmall(_0x468226,_0x3d208a){const _0x10d2a9=_0x5c20;console[_0x10d2a9(0xb4)]({'due':_0x468226,'dateTimeGame':_0x3d208a,'warn':_0x468226-0x3*0x18*0xe10*0x3e8<Date[_0x10d2a9(0xb9)]()+_0x3d208a[_0x10d2a9(0x8f)],'danger':_0x468226<Date['now']()+_0x3d208a['delay'],'success':_0x468226>Date['now']()+_0x3d208a[_0x10d2a9(0x8f)]});const _0x39bfbc=!_0x468226?'':_0x468226<Date[_0x10d2a9(0xb9)]()+_0x3d208a['delay']?_0x10d2a9(0x87):_0x468226-0x3*0x18*0xe10*0x3e8<Date['now']()+_0x3d208a[_0x10d2a9(0x8f)]?'text-danger':_0x10d2a9(0x9d),_0x2aa6a6=new Date(_0x468226)['toLocaleDateString'](_0x10d2a9(0xa9)),_0x3899aa=!_0x468226?_0x10d2a9(0x8d):_0x468226<Date['now']()+_0x3d208a[_0x10d2a9(0x8f)]?_0x10d2a9(0xa1)+_0x2aa6a6+_0x10d2a9(0xb7):_0x10d2a9(0xc2)+_0x2aa6a6+',\x2012h';return{'class':_0x39bfbc,'text':_0x3899aa};}const insertList=async({id:_0x398fbe,active:_0x22c3ed,server:_0x377b92,player:_0x3a6390,due:_0xc56dcb})=>{const _0x511417=_0x5c20,_0x516773=await Storage_All/* StoreAll */.N[_0x511417(0x92)]({'area':'local','key':_0x511417(0xa7),'world':_0x377b92})||{'timeZone':0x0,'delay':0x0},_0x7be08e=_0x377b92+_0x511417(0xad)+_0x3a6390,_0x529cc6=Math['round']((Number(localStorage['getItem'](_0x511417(0xbe)+_0x398fbe))-Date['now']())/0x3e8),_0x3f1dc6=_0x529cc6<=0x0?_0x511417(0xbd):_0x511417(0xa0);if(_0x529cc6>0x0)Timer['insert'](_0x398fbe,_0x529cc6);const _0x4f1ded=resetSmall(_0xc56dcb,_0x516773);return _0x511417(0xbf)+_0x398fbe+_0x511417(0xb3)+_0x398fbe+'\x22\x20name=\x22'+_0x398fbe+_0x511417(0x8b)+(_0x22c3ed&&_0xc56dcb&&_0xc56dcb>Date[_0x511417(0xb9)]()+_0x516773['delay']?_0x511417(0x9f):'')+_0x511417(0x82)+(_0x22c3ed?'Desativar\x20':_0x511417(0xa6))+_0x7be08e+'\x22\x20'+(!_0xc56dcb||_0xc56dcb&&_0xc56dcb<Date[_0x511417(0xb9)]()+_0x516773['delay']?_0x511417(0xb6):'')+'>\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20<label\x20name=\x22'+_0x398fbe+_0x511417(0x90)+(_0x22c3ed?_0x511417(0xc0):_0x511417(0xa6))+_0x7be08e+_0x511417(0x89)+_0x398fbe+'\x22\x20class=\x22fw-bold\x22>'+_0x7be08e+_0x511417(0x8e)+_0x398fbe+_0x511417(0x9e)+_0x4f1ded['class']+'\x22>'+_0x4f1ded[_0x511417(0x8a)]+_0x511417(0xc5)+_0x398fbe+_0x511417(0x95)+_0x398fbe+_0x511417(0xae)+_0x3f1dc6+_0x511417(0x8c)+_0x7be08e+_0x511417(0x96)+(_0x529cc6>0x0?_0x511417(0x85)+Timer['values'][_0x398fbe]['time']+_0x511417(0xa5):'<img\x20id=\x22img-reset\x22\x20name=\x22'+_0x398fbe+_0x511417(0xac))+_0x511417(0x99)+_0x398fbe+'\x22\x20name=\x22'+_0x398fbe+'\x22\x20type=\x22button\x22\x20class=\x22btn\x20btn-light\x22\x20title=\x22Excluir\x20'+_0x7be08e+'\x22>❌</button>\x0a\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20</li>\x0a\x20\x20';};const noList=_0x596861(0x83);const printMessage={'success':function(_0x203715,_0x450ebc){const _0x4cb8d1=_0x596861;this[_0x4cb8d1(0xb2)](_0x203715,_0x450ebc,_0x4cb8d1(0xb1));},'error':function(_0x478fcc,_0x24a912){const _0x33094a=_0x596861;this[_0x33094a(0xb2)](_0x478fcc,_0x24a912,_0x33094a(0xab));},'warn':function(_0x2535de,_0x20a15a){const _0x4db913=_0x596861;this[_0x4db913(0xb2)](_0x2535de,_0x20a15a,_0x4db913(0xbb));},'run':function(_0x1213ac,_0x308b09,_0x27294d){const _0x32b83d=_0x596861,_0x53d7bb=document[_0x32b83d(0x94)](_0x32b83d(0x98));document[_0x32b83d(0xc4)]('body')[_0x32b83d(0xaa)](_0x53d7bb),_0x53d7bb['id']=_0x32b83d(0xb0),_0x53d7bb['className']=_0x27294d,_0x53d7bb['innerHTML']=_0x32b83d(0xa4)+_0x1213ac+_0x32b83d(0x93),setTimeout(()=>{_0x53d7bb['remove']();},_0x308b09);}};function _0x5443(){const _0x205606=['date-reset-','\x0a\x20\x20\x20\x20<li\x20class=\x22list-group-item\x22\x20data-key=\x22','Desativar\x20','<img\x20id=\x22img-reset\x22\x20name=\x22','Vencimento\x20:\x20','time','querySelector','</small>\x0a\x20\x20\x20\x20\x20\x20\x20\x20</label>\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22btn-content\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<button\x20id=\x22reset-','7683885SDfkCs','className','491032OjxXsn','\x20title=\x22','\x0a<li\x20class=\x22list-group-item\x22\x20data-key=\x22\x22>\x0a\x20\x20<div\x20class=\x22form-check\x20form-switch\x20text-wrap\x20center\x22>\x0a\x20\x20\x20\x20Nenhuma\x20chave\x20de\x20permissão\x20encontrada.\x0a\x20\x20</div>\x0a</li>\x0a','show','<span\x20style=\x22color:\x20red;\x22>','2457055FOAzoG','text-danger','keys','\x22>\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20name=\x22','text','\x22\x20class=\x22form-check-input\x22\x20type=\x22checkbox\x22\x20role=\x22switch\x22\x20','\x22\x20title=\x22Atualizar\x20Licença\x20de\x20','Nenhuma\x20licença','</div>\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<small\x20name=\x22','delay','\x22\x20class=\x22form-check-label\x20ms-2\x20me-auto\x22\x20for=\x22ative\x22\x20title=\x22','3664FtpxYf','get','</p>','createElement','\x22\x20name=\x22','\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20','4MnMJuS','div','\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</button>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<button\x20id=\x22remove-','forEach','30VnPmJl','631632oPSpLX','text-success','\x22\x20class=\x22','checked','btn\x20btn-light\x20disabled','Expirado\x20:\x20','interval','remove','<p>','</span>','Ativar\x20','date-time-game','6brLBSI','pt-BR','append','erro','\x22\x20src=\x22./img/Reset-Blue.png\x22\x20width=\x2221px\x22\x20alt=\x22Reset\x22>','\x20-\x20','\x22\x20type=\x22button\x22\x20class=\x22','1069857pTFDBc','message','succ','run','\x22>\x0a\x0a\x20\x20\x20\x20\x20\x20<div\x20class=\x22form-check\x20form-switch\x20d-flex\x20w-100\x20justify-content-between\x22>\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20<input\x20id=\x22active-','log','values','disabled',',\x2012h','target','now','172889NUFixb','warn','1043EKzPZO','btn\x20btn-light'];_0x5443=function(){return _0x205606;};return _0x5443();}
;// CONCATENATED MODULE: ./popup/index.js
const _0x5464f1=_0x47d5;(function(_0x2415c8,_0x1e9c5e){const _0x4eb335=_0x47d5,_0x31e38c=_0x2415c8();while(!![]){try{const _0x2693c0=-parseInt(_0x4eb335(0x114))/0x1*(-parseInt(_0x4eb335(0x11c))/0x2)+-parseInt(_0x4eb335(0x109))/0x3+-parseInt(_0x4eb335(0x118))/0x4+-parseInt(_0x4eb335(0x11b))/0x5+-parseInt(_0x4eb335(0xf5))/0x6*(parseInt(_0x4eb335(0x122))/0x7)+-parseInt(_0x4eb335(0x111))/0x8*(-parseInt(_0x4eb335(0xe4))/0x9)+parseInt(_0x4eb335(0x112))/0xa*(parseInt(_0x4eb335(0x128))/0xb);if(_0x2693c0===_0x1e9c5e)break;else _0x31e38c['push'](_0x31e38c['shift']());}catch(_0x322662){_0x31e38c['push'](_0x31e38c['shift']());}}}(_0x57d8,0xbf2c9));function _0x57d8(){const _0x3972f4=['text','53790ZKqgLe','popup','activation','error','set','getActiveTabs','?t=','small[name=\x22','LABEL','btn\x20btn-light\x20disabled','filter','indexOf','get','date-time-game','bootstrap','extension','alert\x20alert-success\x20text-wrap','world-players','Sua\x20licença\x20continua\x20a\x20mesma!','delay','3483186inDHcm','ul.list-group','className','entry','hide','removeEventListener','content_scripts','query','224wiXbQZ','170NqHEMH','tabs','749402Bhkfxt','use\x20strict','due','&t=','4960164xhmgdz','show','INPUT','975460aOelQS','2SibALa','disabled','sort','find','log','div.toast','364SKpkWC','Nenhuma\x20licença!','local','target','values','querySelector','1257278gyznMt','date-reset-','hidden','IMG','Start-Up','setItem','navigation','active','reset','Licença\x20válida!','verifyWorldMdfPlayerInUrl','length','forEach','getRemote','Dados\x20insuficientes','BUTTON','url','class','click','370593PEwIeZ','insert','now','warn','innerHTML','join','onMessage','success','<span\x20style=\x22color:\x20red;\x22>','getViews','matches','addEventListener','removeAll','alert\x20alert-danger\x20text-wrap','<p>','runtime'];_0x57d8=function(){return _0x3972f4;};return _0x57d8();}function _0x47d5(_0x403643,_0x3de51b){const _0x57d86b=_0x57d8();return _0x47d5=function(_0x47d555,_0x3e4b6d){_0x47d555=_0x47d555-0xe3;let _0x148a20=_0x57d86b[_0x47d555];return _0x148a20;},_0x47d5(_0x403643,_0x3de51b);}_0x5464f1(0x115),chrome[_0x5464f1(0xf3)][_0x5464f1(0xea)]['addListener'](popUpReceivedMessage);const windowId=window[_0x5464f1(0x12e)][_0x5464f1(0xf7)][_0x5464f1(0x10c)]['id'],windowUrl=window[_0x5464f1(0x12e)][_0x5464f1(0xf7)]['entry']['url'],windows=chrome[_0x5464f1(0x104)][_0x5464f1(0xed)]({'type':_0x5464f1(0xf6)});windows[_0x5464f1(0x133)]>0x1&&windows['filter'](_0xea052b=>_0xea052b[_0x5464f1(0x12e)][_0x5464f1(0xf7)][_0x5464f1(0x10c)]['id']!==windowId&&_0xea052b[_0x5464f1(0x12e)][_0x5464f1(0xf7)][_0x5464f1(0x10c)][_0x5464f1(0x138)]===windowUrl)[_0x5464f1(0x134)](_0x10d97e=>chrome['runtime']['sendMessage']({'id':_0x10d97e[_0x5464f1(0x12e)][_0x5464f1(0xf7)][_0x5464f1(0x10c)]['id'],'action':'close'}));function popUpReceivedMessage(_0x464776,_0x21fafb,_0x1b0bd9){const _0x202edb=_0x5464f1,{id:_0x560cce,action:_0x558472}=_0x464776;_0x558472==='close'&&_0x560cce===windowId&&_0x21fafb[_0x202edb(0x138)]===windowUrl&&window['close']();}async function init(){const _0x33458c=_0x5464f1,_0x5df48d=await Storage_All/* StoreAll */.N['get']({'area':_0x33458c(0x124),'key':_0x33458c(0x106)})||{};await (0,On_Alarms/* alarmUpdatePlayers */.zi)();const _0x1577e9=async(_0xd3d7c4,_0xad09d5)=>{const _0x3ed0b9=_0x33458c,_0x6f89f6=chrome[_0x3ed0b9(0xf3)]['getManifest']()[_0x3ed0b9(0x10f)][_0x3ed0b9(0x11f)](_0x30cf92=>_0x30cf92['js'][_0x3ed0b9(0xe9)]()[_0x3ed0b9(0x100)](_0x3ed0b9(0x12c))!==-0x1)[_0x3ed0b9(0xee)]||[],_0x321085=await chrome[_0x3ed0b9(0x113)][_0x3ed0b9(0x110)]({'active':!![],'url':_0x6f89f6}),_0x23407b=_0x12c99d=>_0x12c99d[_0x3ed0b9(0x100)](_0x3ed0b9(0xfb))!==-0x1||_0x12c99d[_0x3ed0b9(0x100)](_0x3ed0b9(0x117))!=-0x1?_0xad09d5:'';return _0x321085[_0x3ed0b9(0xff)](_0x1c01c7=>_0x1c01c7['url'][_0x3ed0b9(0x100)](_0xd3d7c4)!==-0x1&&_0x1c01c7['url'][_0x3ed0b9(0x100)](_0x23407b(_0x1c01c7[_0x3ed0b9(0x138)]))!==-0x1);};async function _0x5e1027(_0x3fbc7b){const _0x6f628=_0x33458c,{name:_0x428cd9,nodeName:_0x36b92b,checked:_0x3d5b09,id:_0x34f782}=_0x3fbc7b[_0x6f628(0x125)];if(!_0x428cd9)return;const {playerId:_0x5d5e7d,server:_0x76b3bb,player:_0x1ec8d2,due:_0x4e8989}=_0x5df48d[_0x428cd9],_0x429b07=await Storage_All/* StoreAll */.N[_0x6f628(0x101)]({'area':_0x6f628(0x124),'key':_0x6f628(0x102),'world':_0x76b3bb})||{'timeZone':0x0,'delay':0x0},_0x588d76=await _0x1577e9(_0x76b3bb,_0x5d5e7d),_0x14294b=async()=>{for(const _0x5655a4 of _0x588d76){chrome['tabs']['reload'](_0x5655a4['id']);}};[_0x6f628(0xfd),_0x6f628(0x11a)][_0x6f628(0x100)](_0x36b92b)!==-0x1&&(_0x5df48d[_0x428cd9][_0x6f628(0x12f)]=_0x3d5b09,await Storage_All/* StoreAll */.N[_0x6f628(0xf9)]({'area':_0x6f628(0x124),'key':_0x6f628(0x106),'data':_0x5df48d}),await _0x14294b());if([_0x6f628(0x137),_0x6f628(0x12b)][_0x6f628(0x100)](_0x36b92b)!==-0x1){if(_0x34f782[_0x6f628(0x100)](_0x6f628(0x130))!==-0x1)_0x3fbc7b[_0x6f628(0x125)][_0x6f628(0x10b)]=_0x6f628(0xfe),_0x3fbc7b['target'][_0x6f628(0xe8)]=_0x6f628(0xec)+0x5a+'</span>',Timer[_0x6f628(0xe5)](_0x428cd9,0x5a),Timer[_0x6f628(0x119)](_0x428cd9),localStorage[_0x6f628(0x12d)](_0x6f628(0x129)+_0x428cd9,Date[_0x6f628(0xe6)]()+0x5a*0x3e8),await _0x4c938c();else{if(_0x34f782==='remove-'+_0x428cd9){const _0x5ee46a=document[_0x6f628(0x127)](_0x6f628(0x121)),_0x1c81fd=async _0x520371=>{const _0x5148d5=_0x6f628;_0x5ee46a[_0x5148d5(0x10e)](_0x5148d5(0xe3),_0x1c81fd),_0x520371[_0x5148d5(0x125)]['id']==='tost_confirm'&&(delete _0x5df48d[_0x428cd9],await Storage_All/* StoreAll */.N['set']({'area':_0x5148d5(0x124),'key':_0x5148d5(0x106),'data':_0x5df48d}),await _0x14294b(),_0x3a3173()),_0x1eb241[_0x5148d5(0x10d)]();};_0x5ee46a[_0x6f628(0xef)]('click',_0x1c81fd);const _0x1eb241=new window[(_0x6f628(0x103))]['Toast'](_0x5ee46a);_0x1eb241[_0x6f628(0x119)]();}}}async function _0x4c938c(){const _0x523eff=_0x6f628;if(!_0x1ec8d2||!_0x76b3bb)return _0x48b309(_0x523eff(0x136),'error',0xbb8);const _0x212e72=await Only_Players/* OnlyPlayers */.N[_0x523eff(0x135)](_0x76b3bb+'_'+_0x1ec8d2)||null;console[_0x523eff(0x120)](_0x212e72);let _0x4e4731;if(!_0x212e72||(_0x212e72&&!_0x212e72[_0x523eff(0x116)]||_0x212e72&&_0x212e72[_0x523eff(0x116)]&&Number(_0x212e72['due'])<Date['now']()+_0x429b07[_0x523eff(0x108)]))_0x48b309(_0x523eff(0x123),_0x523eff(0xe7),0xbb8),_0x4e4731={..._0x5df48d[_0x428cd9],...{'due':null,'id':_0x428cd9,'active':![],'server':_0x76b3bb,'playerId':_0x5d5e7d,'player':_0x1ec8d2}};else{if(Number(_0x212e72[_0x523eff(0x116)])===Number(_0x4e8989))return _0x48b309(_0x523eff(0x107),_0x523eff(0xe7),0xbb8);else _0x48b309(_0x523eff(0x131),_0x523eff(0xeb)),_0x4e4731={..._0x5df48d[_0x428cd9],..._0x212e72};}const _0x2a4113=resetSmall(_0x4e4731[_0x523eff(0x116)],_0x429b07),_0x53da7b=document[_0x523eff(0x127)](_0x523eff(0xfc)+_0x428cd9+'\x22]');_0x53da7b[_0x523eff(0x10b)]=_0x2a4113[_0x523eff(0x139)],_0x53da7b[_0x523eff(0xe8)]=_0x2a4113[_0x523eff(0xf4)],document[_0x523eff(0x127)]('#active-'+_0x428cd9)[_0x523eff(0x11d)]=!_0x4e4731[_0x523eff(0x116)]||_0x4e4731[_0x523eff(0x116)]&&_0x4e4731[_0x523eff(0x116)]<Date[_0x523eff(0xe6)]()+_0x429b07[_0x523eff(0x108)]?!![]:![],_0x5df48d[_0x428cd9]=_0x4e4731,await Storage_All/* StoreAll */.N['set']({'area':_0x523eff(0x124),'key':_0x523eff(0x106),'data':_0x5df48d});const _0x38c556=await Only_Tabs/* OnlyTabs */.P[_0x523eff(0xfa)](!![]);if(_0x38c556[_0x523eff(0x133)])for(const _0x11e0da of _0x38c556){Only_Urls/* OnlyUrls */.l['verifyUrlInUrls'](_0x11e0da[_0x523eff(0x138)])&&Only_Urls/* OnlyUrls */.l[_0x523eff(0x132)](_0x11e0da['url'],_0x76b3bb)&&await (0,Insert_Content_Script/* insertContentScript */.s)({'tabId':_0x11e0da['id']});}}}function _0x48b309(_0x11b11a,_0x55738a,_0x31d4f6=0xbb8){const _0xd935d6=_0x33458c,_0x3aa256=document['querySelector']('div.alert');_0x3aa256[_0xd935d6(0x10b)]=_0x55738a==_0xd935d6(0xf8)?_0xd935d6(0xf1):_0xd935d6(0x105),_0x3aa256['innerHTML']=_0xd935d6(0xf2)+_0x11b11a+'</p>',_0x3aa256[_0xd935d6(0x12a)]=![],setTimeout(()=>_0x3aa256[_0xd935d6(0x12a)]=!![],_0x31d4f6);}async function _0x3a3173(){const _0x13a393=_0x33458c,_0x9f0d98=document['querySelector'](_0x13a393(0x10a)),_0x12b31b=Object[_0x13a393(0x126)](_0x5df48d)[_0x13a393(0x11e)]((_0x35fc55,_0x2e84bc)=>{const _0x8a3a3=_0x13a393;if(_0x35fc55[_0x8a3a3(0x116)]>_0x2e84bc[_0x8a3a3(0x116)])return 0x1;if(_0x35fc55[_0x8a3a3(0x116)]<_0x2e84bc['due'])return 0x1;return;});removeEventListener(_0x13a393(0xe3),_0x5e1027);let _0x4b4d4c='';Timer[_0x13a393(0xf0)]();if(_0x12b31b[_0x13a393(0x133)]){for(const _0x5aeefe of _0x12b31b){_0x4b4d4c+=await insertList(_0x5aeefe);}_0x9f0d98[_0x13a393(0xef)](_0x13a393(0xe3),_0x5e1027);}else _0x4b4d4c=noList;_0x9f0d98[_0x13a393(0xe8)]=_0x4b4d4c,Timer[_0x13a393(0x119)]();}_0x3a3173();}init();
})();

/******/ })()
;