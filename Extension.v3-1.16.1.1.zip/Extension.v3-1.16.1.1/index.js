/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ 583:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  vl: () => (/* binding */ Service_Worker_Emitter),
  IT: () => (/* binding */ getScript),
  ws: () => (/* binding */ runInPage),
  Pm: () => (/* binding */ scripts),
  _C: () => (/* binding */ setScript)
});

// UNUSED EXPORTS: init

// EXTERNAL MODULE: ../Config/root-extension.json
var root_extension = __webpack_require__(181);
// EXTERNAL MODULE: ./Service-Worker/Only-Tabs.js
var Only_Tabs = __webpack_require__(817);
// EXTERNAL MODULE: ./Service-Worker/Only-Urls.js
var Only_Urls = __webpack_require__(287);
;// CONCATENATED MODULE: ./Service-Worker/Services.js
(function(_0x5de790,_0x38c2d8){const _0x5e9b23=_0xeaa4,_0x25049e=_0x5de790();while(!![]){try{const _0x591071=-parseInt(_0x5e9b23(0x91))/0x1*(-parseInt(_0x5e9b23(0x88))/0x2)+-parseInt(_0x5e9b23(0x85))/0x3+parseInt(_0x5e9b23(0x8b))/0x4*(-parseInt(_0x5e9b23(0x8e))/0x5)+parseInt(_0x5e9b23(0x8a))/0x6+parseInt(_0x5e9b23(0x86))/0x7+parseInt(_0x5e9b23(0x87))/0x8*(-parseInt(_0x5e9b23(0x90))/0x9)+parseInt(_0x5e9b23(0x84))/0xa*(parseInt(_0x5e9b23(0x8d))/0xb);if(_0x591071===_0x38c2d8)break;else _0x25049e['push'](_0x25049e['shift']());}catch(_0x2eb264){_0x25049e['push'](_0x25049e['shift']());}}}(_0x317c,0x8a48c));const Services={'matches':async _0x5cba3d=>{const _0x1e278f=_0xeaa4,_0x50ab13=(await Only_Tabs/* OnlyTabs */.P[_0x1e278f(0x83)](!![]))['find'](_0x11ae6b=>_0x11ae6b['id']===_0x5cba3d)[_0x1e278f(0x8f)];return Only_Urls/* OnlyUrls */.l[_0x1e278f(0x92)](_0x50ab13);},'init':async({root:_0x349044,scripts:_0x3a747f})=>{const _0x38cecf=_0xeaa4;Service_Worker_Emitter['on']('Reload',async({tabId:_0x10005c})=>{const _0xd0fdb7=_0xeaa4;await chrome[_0xd0fdb7(0x89)][_0xd0fdb7(0x93)](_0x10005c);}),Services[_0x38cecf(0x8c)]();},'default':async()=>{}};function _0xeaa4(_0x1b10cd,_0x2e5bda){const _0x317cff=_0x317c();return _0xeaa4=function(_0xeaa4c1,_0x565866){_0xeaa4c1=_0xeaa4c1-0x83;let _0x21df4e=_0x317cff[_0xeaa4c1];return _0x21df4e;},_0xeaa4(_0x1b10cd,_0x2e5bda);}function _0x317c(){const _0x430fd3=['verifyUrlInUrls','reload','getActiveTabs','10ShBWSL','2579898hVrPme','6291222sCykgM','8912QsbpaB','1733698gaVUOV','tabs','6699078CUzZXa','36232fKsMIn','default','4305818iPbVTx','425wcnoro','url','8703bbuBGh','1TBsKEd'];_0x317c=function(){return _0x430fd3;};return _0x317c();}/* harmony default export */ const Service_Worker_Services = (Services);
;// CONCATENATED MODULE: ../Emitter/index.js
(function(_0x5c245,_0x4e1c4d){var _0x5540c7=_0x2cc9,_0x43239=_0x5c245();while(!![]){try{var _0x3fd02a=-parseInt(_0x5540c7(0x71))/0x1*(-parseInt(_0x5540c7(0x74))/0x2)+-parseInt(_0x5540c7(0x72))/0x3*(parseInt(_0x5540c7(0x6f))/0x4)+parseInt(_0x5540c7(0x75))/0x5*(parseInt(_0x5540c7(0x73))/0x6)+parseInt(_0x5540c7(0x76))/0x7*(parseInt(_0x5540c7(0x7a))/0x8)+-parseInt(_0x5540c7(0x78))/0x9+parseInt(_0x5540c7(0x6d))/0xa+-parseInt(_0x5540c7(0x79))/0xb*(parseInt(_0x5540c7(0x77))/0xc);if(_0x3fd02a===_0x4e1c4d)break;else _0x43239['push'](_0x43239['shift']());}catch(_0x58dbda){_0x43239['push'](_0x43239['shift']());}}}(_0x4095,0x5a802));class Emitters{constructor(){var _0x1dd485=_0x2cc9;this[_0x1dd485(0x6e)]={};}['on'](_0x253f1f,_0x11785c){var _0x5cfb61=_0x2cc9;this['events'][_0x253f1f]=this[_0x5cfb61(0x6e)][_0x253f1f]||[],this[_0x5cfb61(0x6e)][_0x253f1f][_0x5cfb61(0x70)](_0x11785c);}['remove'](_0x5501d5){if(_0x5501d5 in this['events']===![])return;}['emit'](_0x558eb8,..._0x1484cc){var _0x14fd3e=_0x2cc9;if(_0x558eb8 in this[_0x14fd3e(0x6e)]===![])return;this[_0x14fd3e(0x6e)][_0x558eb8]['forEach'](_0x371160=>_0x371160(..._0x1484cc));}}/* harmony default export */ const Emitter = (Emitters);function _0x2cc9(_0x4cbd67,_0x174a26){var _0x409549=_0x4095();return _0x2cc9=function(_0x2cc9a4,_0x2e76f7){_0x2cc9a4=_0x2cc9a4-0x6d;var _0x2a9d3a=_0x409549[_0x2cc9a4];return _0x2a9d3a;},_0x2cc9(_0x4cbd67,_0x174a26);}function _0x4095(){var _0x476729=['2056668mIoZhu','2YnBvsN','10aMXpDG','7pfAphu','72cenpvb','1003680gutuJM','2705483WxvOAm','4230704FvUxLe','6566870OeLhnp','events','2076vzVsRZ','push','353613PdODXI','1542nhvQHM'];_0x4095=function(){return _0x476729;};return _0x4095();}
// EXTERNAL MODULE: ./Service-Worker/Storage-All.js
var Storage_All = __webpack_require__(747);
;// CONCATENATED MODULE: ./Service-Worker/i18n.js
const _0x2a1361=_0xa789;function _0xe314(){const _0x45f98b=['get','i18n','771745qYvBTd','875665fJnRHv','5793FVkbjW','19242oXRKUX','496MnOdQw','3157494UOJwZJ','4059076BGGMpI','452oDGzBf','11439350UNwgLE','8UNHrJd','local'];_0xe314=function(){return _0x45f98b;};return _0xe314();}(function(_0x33f51d,_0x474484){const _0x280b00=_0xa789,_0x26efca=_0x33f51d();while(!![]){try{const _0x1948e8=parseInt(_0x280b00(0x90))/0x1+parseInt(_0x280b00(0x97))/0x2*(-parseInt(_0x280b00(0x92))/0x3)+parseInt(_0x280b00(0x99))/0x4*(parseInt(_0x280b00(0x91))/0x5)+parseInt(_0x280b00(0x95))/0x6+parseInt(_0x280b00(0x96))/0x7+parseInt(_0x280b00(0x94))/0x8*(-parseInt(_0x280b00(0x93))/0x9)+-parseInt(_0x280b00(0x98))/0xa;if(_0x1948e8===_0x474484)break;else _0x26efca['push'](_0x26efca['shift']());}catch(_0x2b3f66){_0x26efca['push'](_0x26efca['shift']());}}}(_0xe314,0x7dc9f));function _0xa789(_0x54eb92,_0x14686b){const _0xe3145d=_0xe314();return _0xa789=function(_0xa789e4,_0x370cd9){_0xa789e4=_0xa789e4-0x8d;let _0x4d6772=_0xe3145d[_0xa789e4];return _0x4d6772;},_0xa789(_0x54eb92,_0x14686b);}const i18n={'get':async()=>await Storage_All/* StoreAll */.N[_0x2a1361(0x8e)]({'area':_0x2a1361(0x8d),'key':'i18n'}),'set':async({data:_0x360edc})=>Storage_All/* StoreAll */.N['set']({'area':_0x2a1361(0x8d),'key':_0x2a1361(0x8f),'data':_0x360edc})};
;// CONCATENATED MODULE: ./Service-Worker/Set-Action-Tab.js
(function(_0xcb6026,_0x5c79a1){var _0x4f652c=_0x4cb8,_0x6ea11=_0xcb6026();while(!![]){try{var _0x5525a1=parseInt(_0x4f652c(0x1c9))/0x1*(-parseInt(_0x4f652c(0x1c4))/0x2)+-parseInt(_0x4f652c(0x1c5))/0x3+-parseInt(_0x4f652c(0x1c7))/0x4*(-parseInt(_0x4f652c(0x1bf))/0x5)+-parseInt(_0x4f652c(0x1bd))/0x6+parseInt(_0x4f652c(0x1c1))/0x7+-parseInt(_0x4f652c(0x1c0))/0x8+parseInt(_0x4f652c(0x1be))/0x9;if(_0x5525a1===_0x5c79a1)break;else _0x6ea11['push'](_0x6ea11['shift']());}catch(_0x28ba2e){_0x6ea11['push'](_0x6ea11['shift']());}}}(_0x17ec,0x95468));function _0x4cb8(_0x1657f6,_0x2c9026){var _0x17ec0d=_0x17ec();return _0x4cb8=function(_0x4cb81f,_0x318d2a){_0x4cb81f=_0x4cb81f-0x1bb;var _0x4dc9ee=_0x17ec0d[_0x4cb81f];return _0x4dc9ee;},_0x4cb8(_0x1657f6,_0x2c9026);}async function setAction(_0x1bf72e,_0x308025,_0x599593,_0xd78658){var _0x40e3b4=_0x4cb8;if(_0x1bf72e){chrome['action'][_0x40e3b4(0x1bc)]({'path':{0x30:'../icons/'+(_0xd78658?_0xd78658:_0x40e3b4(0x1ca))},'tabId':_0x1bf72e});_0x308025&&(await chrome[_0x40e3b4(0x1c8)][_0x40e3b4(0x1c2)]({'color':_0x40e3b4(0x1cb),'tabId':_0x1bf72e}),await chrome[_0x40e3b4(0x1c8)]['setBadgeText']({'text':'▶️','tabId':_0x1bf72e}),await chrome['action'][_0x40e3b4(0x1c6)]({'color':_0x40e3b4(0x1c3),'tabId':_0x1bf72e}));chrome[_0x40e3b4(0x1c8)]['enable'](_0x1bf72e);!await chrome['action']['getPopup']({'tabId':_0x1bf72e})&&chrome['action'][_0x40e3b4(0x1bb)]({'popup':'./index.html','tabId':_0x1bf72e});if(!_0x599593)chrome[_0x40e3b4(0x1c8)][_0x40e3b4(0x1bb)]({'popup':'','tabId':_0x1bf72e});}}function _0x17ec(){var _0x4dd1ac=['5dElAtU','3447488svUODD','8084349oUIqGo','setBadgeBackgroundColor','white','12EtHTVK','2906991obshgk','setBadgeTextColor','2788432WPfSYH','action','38638ElwtKD','48.png','red','setPopup','setIcon','5856762KDSxQb','12305745WcBEto'];_0x17ec=function(){return _0x4dd1ac;};return _0x17ec();}
// EXTERNAL MODULE: ./Service-Worker/Only-Players.js + 1 modules
var Only_Players = __webpack_require__(109);
// EXTERNAL MODULE: ./Service-Worker/Insert-Content-Script.js
var Insert_Content_Script = __webpack_require__(827);
;// CONCATENATED MODULE: ./Service-Worker/On-Message-Single.js
function _0x60ed(_0x1553d6,_0x3a5b11){const _0x4f7296=_0x4f72();return _0x60ed=function(_0x60edb,_0x5d6480){_0x60edb=_0x60edb-0x6e;let _0x546fdf=_0x4f7296[_0x60edb];return _0x546fdf;},_0x60ed(_0x1553d6,_0x3a5b11);}(function(_0x3b7447,_0x2d2744){const _0x319a84=_0x60ed,_0xc7bef8=_0x3b7447();while(!![]){try{const _0x13830c=parseInt(_0x319a84(0x84))/0x1*(parseInt(_0x319a84(0x8c))/0x2)+-parseInt(_0x319a84(0x94))/0x3+-parseInt(_0x319a84(0x83))/0x4+parseInt(_0x319a84(0x6e))/0x5+-parseInt(_0x319a84(0x9a))/0x6*(parseInt(_0x319a84(0x7b))/0x7)+parseInt(_0x319a84(0x96))/0x8*(parseInt(_0x319a84(0x7d))/0x9)+-parseInt(_0x319a84(0x90))/0xa*(-parseInt(_0x319a84(0x8b))/0xb);if(_0x13830c===_0x2d2744)break;else _0xc7bef8['push'](_0xc7bef8['shift']());}catch(_0x21c30d){_0xc7bef8['push'](_0xc7bef8['shift']());}}}(_0x4f72,0xec322));const OnMessageSingle=(_0x65ba65,_0x4ded37,_0x205e7c)=>{return OnMessageSync(_0x65ba65,_0x4ded37,_0x205e7c),!![];};function _0x4f72(){const _0x54f578=['3432615MNjaMe','getRunInPageFilterSort','408UbYNll','due','date-time-game','Disabled!','2091678xWStzA','dateTimeGame','origin','alarms','runtime','Service-Worker','Reload','9111615tQkAyK','create','getTab','set','getURL','split','delay','Not\x20Origin','now','\x20-\x20Answering\x20message\x20from\x20','local','verifyUrlInUrls','length','7ezBWdH','restart-service-worker','24633JgTszQ','License\x20not\x20found!','Start-Game','tab','tabId','source','3860072FaJGEW','984778hmElGG','clear','white-black.48.png','manifest.json','Data\x20not\x20found!','getTabsFilterSort','ico.png','671DadSPO','2tusBhL','replace','Start-Login','48.png','78460ZybMqb','Not\x20tab\x20active','emit','get'];_0x4f72=function(){return _0x54f578;};return _0x4f72();}async function OnMessageSync(_0x2133be,_0x841521,_0x3ca06f){const _0x26a598=new Promise((_0x41d84c,_0x172ce7)=>{try{avaiable({'received':_0x2133be,'sender':_0x841521})['then'](_0x7dae18=>_0x41d84c(_0x7dae18));}catch(_0x79bfb0){_0x172ce7(_0x79bfb0);}});await _0x26a598&&_0x3ca06f(await _0x26a598);}async function avaiable({received:_0x3b5a7d,sender:_0x4c10ca}){const _0x52f716=_0x60ed;if(!_0x3b5a7d[_0x52f716(0x82)])return{'msg':_0x52f716(0x88),'active':![],'cause':_0x3b5a7d[_0x52f716(0x82)]};if(!await scripts)return!await chrome[_0x52f716(0x9d)][_0x52f716(0x93)](_0x52f716(0x7c))&&await chrome[_0x52f716(0x9d)][_0x52f716(0x6f)](_0x52f716(0x7c),{'periodInMinutes':0x3}),await setAction(_0x4c10ca[_0x52f716(0x80)]['id'],![],![],'red.48.png'),{'msg':'No\x20connection!','active':![],'cause':{'connection':![]}};else{const _0x205348=await chrome[_0x52f716(0x9d)][_0x52f716(0x93)]('restart-service-worker');if(_0x205348)await chrome[_0x52f716(0x9d)][_0x52f716(0x85)](_0x205348['name']);}if(!_0x3b5a7d||!_0x4c10ca)return{'msg':_0x52f716(0x88),'active':![],'cause':{'received':_0x3b5a7d,'sender':_0x4c10ca}};const {activetab:_0x9a7183}=_0x3b5a7d,{id:_0x4ea886,active:_0x6f82a0,windowId:_0x1c1385}=_0x4c10ca['tab'];if(!_0x6f82a0&&runInPage[_0x4ea886]||!_0x9a7183&&runInPage[_0x4ea886])return delete runInPage[_0x4ea886],Service_Worker_Emitter[_0x52f716(0x92)](_0x52f716(0xa0),{'tabId':_0x4ea886}),{'msg':_0x52f716(0x91),'tabId':_0x4ea886,'tabActive':[_0x9a7183,_0x6f82a0],'inPage':!!runInPage[_0x4ea886]};if(!_0x6f82a0||!_0x9a7183)return{'msg':_0x52f716(0x91),'tabActive':[_0x9a7183,_0x6f82a0],'tabId':_0x4ea886,'runInPage':runInPage};const {game:_0x3c5b51,world:_0x125f36,playerId:_0x4c0542,player:_0x48dcf2,mdf:_0x4dd3ec,screen:_0x558c8e,mode:_0x1b48d3,botProtect:_0x3f13db}=_0x3b5a7d;_0x3c5b51&&await Storage_All/* StoreAll */.N[_0x52f716(0x71)]({'area':_0x52f716(0x78),'key':_0x52f716(0x98),'data':_0x3b5a7d[_0x52f716(0x9b)],'world':_0x125f36});const _0x3457f1=await Storage_All/* StoreAll */.N[_0x52f716(0x93)]({'area':_0x52f716(0x78),'key':_0x52f716(0x98),'world':_0x125f36})||{'timeZone':0x0,'delay':0x0};if(!Only_Urls/* OnlyUrls */.l[_0x52f716(0x79)](_0x4c10ca[_0x52f716(0x9c)]))return{'msg':_0x52f716(0x75),'active':![],'cause':_0x4c10ca[_0x52f716(0x9c)]};const _0x4050d5=await Only_Players/* OnlyPlayers */.N[_0x52f716(0x93)]({'world':_0x125f36,'player':_0x48dcf2,'playerId':_0x4c0542}),_0x32b9f3=_0x4050d5?_0x4050d5['active']:![],_0x35c103=_0x52f716(0x9f),_0xa5a9f=_0x35c103+_0x52f716(0x77)+_0x3b5a7d[_0x52f716(0x82)],_0x22cb35=chrome[_0x52f716(0x9e)][_0x52f716(0x72)](_0x52f716(0x87))[_0x52f716(0x8d)](_0x52f716(0x87),''),_0xfb30ec=_0x22cb35[_0x52f716(0x73)]('/')[0x2];if(!_0x4050d5[_0x52f716(0x97)]||_0x4050d5[_0x52f716(0x97)]<Date[_0x52f716(0x76)]()+_0x3457f1[_0x52f716(0x74)]||!_0x32b9f3)return await setAction(Number(_0x4ea886),![],_0x3c5b51,!_0x4050d5[_0x52f716(0x97)]||_0x4050d5[_0x52f716(0x97)]<Date[_0x52f716(0x76)]()+_0x3457f1['delay']?_0x52f716(0x86):_0x4050d5[_0x52f716(0x97)]-0x3*0x18*0xe10*0x3e8<Date[_0x52f716(0x76)]()+_0x3457f1['delay']?'yellow.48.png':_0x52f716(0x8f)),{'msg':!_0x4050d5[_0x52f716(0x97)]?_0x52f716(0x7e):_0x4050d5[_0x52f716(0x97)]<Date['now']()+_0x3457f1[_0x52f716(0x74)]?'Expired\x20license!':_0x52f716(0x99),'active':_0x32b9f3};const _0x567660=await Only_Tabs/* OnlyTabs */.P[_0x52f716(0x89)](_0x125f36,_0x4dd3ec),_0x11cbe7=await Only_Tabs/* OnlyTabs */.P[_0x52f716(0x95)](_0x4c0542,_0x125f36,_0x4dd3ec,_0x48dcf2),_0x4ef2ed=_0x11cbe7[_0x52f716(0x7a)]?_0x11cbe7:_0x567660,_0x214716=await Only_Tabs/* OnlyTabs */.P[_0x52f716(0x70)](_0x4ef2ed);if(_0x214716&&(_0x214716[_0x52f716(0x81)]||_0x214716['id'])!==_0x4ea886)return await setAction(Number(_0x4ea886),![],_0x3c5b51,_0x52f716(0x8a)),{'msg':_0x52f716(0x91),'active':![]};const _0x27dae3=await i18n[_0x52f716(0x93)]();await setAction(Number(_0x4ea886),!![],_0x3c5b51,_0x4050d5['due']-0x3*0x18*0xe10*0x3e8<Date[_0x52f716(0x76)]()+_0x3457f1[_0x52f716(0x74)]?'yellow.48.png':_0x52f716(0x8f));const _0x2de7c9=''+_0x4ea886+(Date[_0x52f716(0x76)]()-_0x4c0542),_0x19444a={'id':_0x2de7c9,'tabId':_0x4ea886,'windowId':_0x1c1385,'tabActive':_0x6f82a0,'world':_0x125f36,'playerId':_0x4c0542,'player':_0x48dcf2,'mdf':_0x4dd3ec,'screen':_0x558c8e,'mode':_0x1b48d3,'botProtect':_0x3f13db,'extensionId':_0xfb30ec,'i18n':_0x27dae3};if(!runInPage[_0x4ea886]||!_0x3b5a7d['id']){runInPage[_0x4ea886]=_0x19444a;const _0x4eda40=_0x3c5b51?_0x52f716(0x7f):_0x52f716(0x8e);await (0,Insert_Content_Script/* insertContentScript */.s)({'tabId':_0x4ea886,'name':_0x4eda40,'data':_0x19444a});}return{'id':_0x2de7c9,'msg':_0xa5a9f,'active':_0x32b9f3,'tabActive':_0x6f82a0,'windowId':_0x1c1385,'tabId':_0x4ea886,'extensionId':_0xfb30ec};}
;// CONCATENATED MODULE: ./Service-Worker/On-Connect-Port.js
(function(_0x4218ba,_0x49a206){const _0x12678c=_0x8371,_0x2d6002=_0x4218ba();while(!![]){try{const _0x47b644=parseInt(_0x12678c(0x1e9))/0x1+parseInt(_0x12678c(0x1f1))/0x2+parseInt(_0x12678c(0x1ef))/0x3*(parseInt(_0x12678c(0x1e2))/0x4)+parseInt(_0x12678c(0x1e4))/0x5+parseInt(_0x12678c(0x1ed))/0x6+parseInt(_0x12678c(0x1e8))/0x7+-parseInt(_0x12678c(0x1e6))/0x8;if(_0x47b644===_0x49a206)break;else _0x2d6002['push'](_0x2d6002['shift']());}catch(_0x4070ce){_0x2d6002['push'](_0x2d6002['shift']());}}}(_0x452e,0x6ce73));function _0x452e(){const _0x20fa73=['23187656eeHhJB','set','5580442QgtFoE','507190XOfyEY','manifest.json','Storage','replace','3127566YNvCRM','getURL','6LENtGC','get','1153350GHoecW','\x22Service\x20Worker\x22\x20connect\x20on\x20','onMessage','784432BQcxbW','Connection','2749880nqwbnd','postMessage'];_0x452e=function(){return _0x20fa73;};return _0x452e();}let portFromCS;function _0x8371(_0x2360f1,_0xfc5777){const _0x452e16=_0x452e();return _0x8371=function(_0x837179,_0x2dffb9){_0x837179=_0x837179-0x1e1;let _0x1db1bd=_0x452e16[_0x837179];return _0x1db1bd;},_0x8371(_0x2360f1,_0xfc5777);}function OnConnectPort(_0x312739){const _0x1f49ad=_0x8371;if(!_0x312739)return;portFromCS=_0x312739,portFromCS['postMessage']({'text':_0x1f49ad(0x1f2)+portFromCS['name']}),portFromCS[_0x1f49ad(0x1e1)]['addListener'](async(_0x1f404d,{sender:_0x3670ee})=>{const _0x42aefb=_0x1f49ad,_0x27d1f4=chrome['runtime'][_0x42aefb(0x1ee)](_0x42aefb(0x1ea))[_0x42aefb(0x1ec)]('manifest.json',''),_0x2edb34=_0x27d1f4['split']('/')[0x2],{type:_0x2fbf22,method:_0x134477,..._0x2ac0a9}=_0x1f404d;if(_0x2edb34!==_0x3670ee['id'])return;switch(_0x2fbf22){case _0x42aefb(0x1eb):_0x134477&&_0x134477===_0x42aefb(0x1e7)?await Storage_All/* StoreAll */.N['set']({..._0x2ac0a9}):portFromCS[_0x42aefb(0x1e5)](await Storage_All/* StoreAll */.N[_0x42aefb(0x1f0)]({..._0x2ac0a9}));break;case _0x42aefb(0x1e3):break;default:break;}});}
;// CONCATENATED MODULE: ./Service-Worker/On-Installed-Extension.js
const _0x3ca072=_0x2390;(function(_0xf02408,_0x48a136){const _0x507465=_0x2390,_0x3cdda2=_0xf02408();while(!![]){try{const _0x1de993=parseInt(_0x507465(0x19d))/0x1*(-parseInt(_0x507465(0x1a4))/0x2)+parseInt(_0x507465(0x1a0))/0x3+parseInt(_0x507465(0x18f))/0x4*(-parseInt(_0x507465(0x197))/0x5)+-parseInt(_0x507465(0x1bf))/0x6*(parseInt(_0x507465(0x1bb))/0x7)+-parseInt(_0x507465(0x1b9))/0x8*(parseInt(_0x507465(0x1b4))/0x9)+parseInt(_0x507465(0x1a7))/0xa+parseInt(_0x507465(0x1a5))/0xb;if(_0x1de993===_0x48a136)break;else _0x3cdda2['push'](_0x3cdda2['shift']());}catch(_0x2a0684){_0x3cdda2['push'](_0x3cdda2['shift']());}}}(_0x52b2,0x40e6d));const rules={'dc-1':{'id':_0x3ca072(0x19c),'conditions':[new chrome[(_0x3ca072(0x19e))][(_0x3ca072(0x1bd))]({'pageUrl':{'schemes':[_0x3ca072(0x194)],'pathPrefix':_0x3ca072(0x1be)}})],'actions':[new chrome[(_0x3ca072(0x19e))][(_0x3ca072(0x196))]()]}},OnInstaledExtension=async({previousVersion:_0x163eac,reason:_0x5e628c})=>{const _0x239916=_0x3ca072,_0x112b91=isUserScriptsAvailable();_0x112b91&&await chrome[_0x239916(0x191)][_0x239916(0x1a2)]([{'id':_0x239916(0x19a),'runAt':_0x239916(0x1a9),'matches':[_0x239916(0x193),'https://*.die-staemme.de/*',_0x239916(0x1c6),_0x239916(0x1b3),_0x239916(0x1c4),_0x239916(0x1ab),_0x239916(0x1a3),'https://*.divokekmeny.cz/*',_0x239916(0x19f),'https://*.voynaplemyon.com/*',_0x239916(0x18d),_0x239916(0x1b1),'https://*.klanhaboru.hu/*','https://*.tribals.it/*',_0x239916(0x1b5),_0x239916(0x1a6),'https://*.guerrastribales.es/*',_0x239916(0x1ba),_0x239916(0x1b8),_0x239916(0x198),_0x239916(0x1ac)],'js':[{'file':_0x239916(0x1ad)}],'world':_0x239916(0x192)},{'id':_0x239916(0x1c5),'runAt':_0x239916(0x1a9),'matches':[_0x239916(0x193),_0x239916(0x1bc),'https://*.staemme.ch/*',_0x239916(0x1b3),'https://*.tribalwars.nl/*',_0x239916(0x1ab),_0x239916(0x1a3),_0x239916(0x1b7),_0x239916(0x19f),'https://*.voynaplemyon.com/*',_0x239916(0x18d),'https://*.divoke-kmene.sk/*',_0x239916(0x1c2),'https://*.tribals.it/*','https://*.klanlar.org/*',_0x239916(0x1a6),_0x239916(0x1c1),_0x239916(0x1ba),'https://*.tribalwars.co.uk/*','https://*.tribalwars.works/*',_0x239916(0x1ac)],'js':[{'file':'./Content-User/Kumin-Anti-Traking.js'}],'world':_0x239916(0x192)},{'id':'socket-received','runAt':'document_start','matches':[_0x239916(0x193),'https://*.die-staemme.de/*','https://*.staemme.ch/*',_0x239916(0x1b3),'https://*.tribalwars.nl/*','https://*.plemiona.pl/*',_0x239916(0x1a3),_0x239916(0x1b7),'https://*.triburile.ro/*',_0x239916(0x190),_0x239916(0x18d),_0x239916(0x1b1),_0x239916(0x1c2),_0x239916(0x1af),_0x239916(0x1b5),_0x239916(0x1a6),_0x239916(0x1c1),_0x239916(0x1ba),'https://*.tribalwars.co.uk/*',_0x239916(0x198),'https://*.tribalwars.us/*'],'js':[{'file':_0x239916(0x1aa)}],'world':_0x239916(0x192)}]);console['log']({'previousVersion':_0x163eac,'reason':_0x5e628c,'isAvailableUserScript':_0x112b91});const _0x366cb9=await chrome['tabs'][_0x239916(0x19b)]({});if(!_0x366cb9?.['length'])return;for(const _0x2630c0 of _0x366cb9){_0x2630c0['id']&&_0x2630c0['url']&&Only_Urls/* OnlyUrls */.l[_0x239916(0x1c0)](_0x2630c0[_0x239916(0x1a8)])&&await chrome['tabs'][_0x239916(0x199)](_0x2630c0['id']);}chrome['declarativeContent'][_0x239916(0x1b2)][_0x239916(0x1c3)](Object['keys'](rules),function(){const _0x4c29e7=_0x239916;chrome[_0x4c29e7(0x19e)][_0x4c29e7(0x1b2)]['addRules'](Object[_0x4c29e7(0x18e)](rules),_0x56efb0=>{return;});}),await chrome[_0x239916(0x195)][_0x239916(0x1b6)](_0x239916(0x1a1),{'delayInMinutes':0x3c,'periodInMinutes':0x3c},async _0x546077=>{const _0x35c978=_0x239916,_0x87613e=await chrome['alarms'][_0x35c978(0x1ae)](_0x35c978(0x1a1));console[_0x35c978(0x1b0)]({'alarm':_0x87613e,'param':_0x546077});});};function isUserScriptsAvailable(){const _0x29ef6b=_0x3ca072;try{return chrome[_0x29ef6b(0x191)],!![];}catch{return![];}}function _0x52b2(){const _0x522eb6=['dc-1','249938HslWjh','declarativeContent','https://*.triburile.ro/*','900927HJAfxR','update-players','register','https://*.tribalwars.com.pt/*','4cZGaVr','12662430ioIusf','https://*.guerretribale.fr/*','3765890ghJxnA','url','document_start','./Content-User/Socket-Received.js','https://*.plemiona.pl/*','https://*.tribalwars.us/*','./Content-User/Removing-Traking.js','get','https://*.tribals.it/*','log','https://*.divoke-kmene.sk/*','onPageChanged','https://*.tribalwars.net/*','9bzqctu','https://*.klanlar.org/*','create','https://*.divokekmeny.cz/*','https://*.tribalwars.co.uk/*','3603016nURMeh','https://*.tribalwars.ae/*','124943EINAnw','https://*.die-staemme.de/*','PageStateMatcher','/game.php','60CpFkFd','verifyUrlInUrls','https://*.guerrastribales.es/*','https://*.klanhaboru.hu/*','removeRules','https://*.tribalwars.nl/*','kumin-anti-traking','https://*.staemme.ch/*','https://*.fyletikesmaxes.gr/*','values','16WQpmLV','https://*.voynaplemyon.com/*','userScripts','MAIN','https://*.tribalwars.com.br/*','https','alarms','ShowAction','541810pBcMqB','https://*.tribalwars.works/*','reload','removing-traking','query'];_0x52b2=function(){return _0x522eb6;};return _0x52b2();}function _0x2390(_0x1c2450,_0x2270fa){const _0x52b25e=_0x52b2();return _0x2390=function(_0x2390cb,_0x1cb734){_0x2390cb=_0x2390cb-0x18d;let _0xd15a3a=_0x52b25e[_0x2390cb];return _0xd15a3a;},_0x2390(_0x1c2450,_0x2270fa);}
;// CONCATENATED MODULE: ./Service-Worker/On-Tab-Activated.js
function _0x44d2(){const _0x5609e2=['reduce','tabId','17658IsPzMQ','2762766KdDYLi','url','1460YwhaaX','288436wCFbZq','This\x20tab\x20has\x20been\x20activated','12253HaaHaS','5SRTqvS','18gpwPlb','find','filter','16354547TJDNam','Start-Up','34377vNzyFf','length','296pYwOWR','991359bHhKLM','getActiveTabs'];_0x44d2=function(){return _0x5609e2;};return _0x44d2();}function _0x58dc(_0x411e03,_0x5bfe50){const _0x44d26c=_0x44d2();return _0x58dc=function(_0x58dc80,_0x545a2c){_0x58dc80=_0x58dc80-0x17d;let _0x1bb873=_0x44d26c[_0x58dc80];return _0x1bb873;},_0x58dc(_0x411e03,_0x5bfe50);}(function(_0x17b221,_0x597c4f){const _0x2b545d=_0x58dc,_0x2b50a1=_0x17b221();while(!![]){try{const _0x43cf9b=-parseInt(_0x2b545d(0x18e))/0x1*(-parseInt(_0x2b545d(0x190))/0x2)+-parseInt(_0x2b545d(0x184))/0x3+parseInt(_0x2b545d(0x18c))/0x4*(-parseInt(_0x2b545d(0x18f))/0x5)+-parseInt(_0x2b545d(0x189))/0x6+-parseInt(_0x2b545d(0x181))/0x7*(parseInt(_0x2b545d(0x183))/0x8)+-parseInt(_0x2b545d(0x188))/0x9*(parseInt(_0x2b545d(0x18b))/0xa)+parseInt(_0x2b545d(0x17f))/0xb;if(_0x43cf9b===_0x597c4f)break;else _0x2b50a1['push'](_0x2b50a1['shift']());}catch(_0x2d139b){_0x2b50a1['push'](_0x2b50a1['shift']());}}}(_0x44d2,0x40e90));const OnActivatedTab=async({tabId:_0x41d784,windowId:_0x54684c})=>{const _0x50cf1c=_0x58dc,_0xf277c3=_0x50cf1c(0x18d),_0x1d9708=await Only_Tabs/* OnlyTabs */.P[_0x50cf1c(0x185)](!![]);if(!_0x1d9708[_0x50cf1c(0x182)])return;const _0x48fdca=await Only_Tabs/* OnlyTabs */.P[_0x50cf1c(0x185)](!![],_0x54684c),_0x12d000=_0x48fdca[_0x50cf1c(0x182)]?_0x48fdca[_0x50cf1c(0x17d)](_0x24bc9c=>_0x24bc9c['id']===_0x41d784&&Only_Urls/* OnlyUrls */.l['verifyUrlInUrls'](_0x24bc9c[_0x50cf1c(0x18a)])):null,_0x53a23f=Object['values'](runInPage),_0x3c7d04=_0x53a23f[_0x50cf1c(0x182)]?_0x53a23f[_0x50cf1c(0x17e)](_0x5e527a=>_0x5e527a['windowId']===_0x54684c)[_0x50cf1c(0x186)]((_0x5c0118,_0x3cbd7f)=>{const _0x3460e8=_0x50cf1c,_0x458ad0=_0x3cbd7f[_0x3460e8(0x187)];return!_0x48fdca['find'](_0x534428=>_0x534428['id']===_0x458ad0)&&(_0x5c0118=_0x3cbd7f),_0x5c0118;},null):null;if(!_0x12d000&&!_0x3c7d04)return;if(_0x12d000&&!_0x3c7d04){await (0,Insert_Content_Script/* insertContentScript */.s)({'tabId':_0x41d784,'name':'Start-Up'});return;}_0x12d000&&_0x3c7d04&&(await (0,Insert_Content_Script/* insertContentScript */.s)({'tabId':_0x3c7d04[_0x50cf1c(0x187)],'name':_0x50cf1c(0x180)}),await (0,Insert_Content_Script/* insertContentScript */.s)({'tabId':_0x41d784,'name':_0x50cf1c(0x180)}));};
;// CONCATENATED MODULE: ./Service-Worker/On-Tab-Removed.js
(function(_0x461a02,_0x561506){const _0x15a6e2=_0x1f9e,_0x246f3f=_0x461a02();while(!![]){try{const _0x32e9e9=parseInt(_0x15a6e2(0x15a))/0x1*(parseInt(_0x15a6e2(0x157))/0x2)+parseInt(_0x15a6e2(0x154))/0x3+parseInt(_0x15a6e2(0x15d))/0x4*(-parseInt(_0x15a6e2(0x15c))/0x5)+-parseInt(_0x15a6e2(0x151))/0x6+parseInt(_0x15a6e2(0x159))/0x7+-parseInt(_0x15a6e2(0x155))/0x8+parseInt(_0x15a6e2(0x158))/0x9;if(_0x32e9e9===_0x561506)break;else _0x246f3f['push'](_0x246f3f['shift']());}catch(_0x1d2d33){_0x246f3f['push'](_0x246f3f['shift']());}}}(_0x2c80,0xead52));function _0x2c80(){const _0x1d8c00=['windowId','5DbdOIH','6675652UhhDCP','length','5699790KmwBqp','log','filter','609384wNPhqe','4697448NIFwDw','tabId','51902aCkGwr','8758296DUufot','8770608dgPvsQ','67PsAoud'];_0x2c80=function(){return _0x1d8c00;};return _0x2c80();}const OnRemovedTab=async(_0x515997,{isWindowClosing:_0x4fc78a,windowId:_0x813524})=>{const _0x30eb2c=_0x1f9e;console[_0x30eb2c(0x152)]({'tabId':_0x515997,'windowId':_0x813524,'isWindowClosing':_0x4fc78a,'runInPage':runInPage});if(!runInPage)return;const _0x507c88=Object['values'](runInPage)[_0x30eb2c(0x153)](_0x54ca0e=>_0x54ca0e[_0x30eb2c(0x15b)]===_0x813524);if(!_0x507c88[_0x30eb2c(0x15e)])return;if(_0x4fc78a)for(const _0x54a33f of _0x507c88){delete runInPage[_0x54a33f[_0x30eb2c(0x156)]];}else{if(runInPage[_0x515997])delete runInPage[_0x515997];}};function _0x1f9e(_0x125d90,_0x17f66c){const _0x2c8012=_0x2c80();return _0x1f9e=function(_0x1f9ec4,_0x3b24b3){_0x1f9ec4=_0x1f9ec4-0x151;let _0x1c71dc=_0x2c8012[_0x1f9ec4];return _0x1c71dc;},_0x1f9e(_0x125d90,_0x17f66c);}
;// CONCATENATED MODULE: ./Service-Worker/On-Tab-Updated.js
(function(_0x16b3ef,_0x39d1cb){const _0x235ac6=_0x3776,_0x359f96=_0x16b3ef();while(!![]){try{const _0x542cc1=-parseInt(_0x235ac6(0x1e2))/0x1*(-parseInt(_0x235ac6(0x1dc))/0x2)+-parseInt(_0x235ac6(0x1db))/0x3+-parseInt(_0x235ac6(0x1dd))/0x4+-parseInt(_0x235ac6(0x1e5))/0x5*(-parseInt(_0x235ac6(0x1da))/0x6)+-parseInt(_0x235ac6(0x1e4))/0x7+-parseInt(_0x235ac6(0x1e0))/0x8*(-parseInt(_0x235ac6(0x1e3))/0x9)+-parseInt(_0x235ac6(0x1de))/0xa;if(_0x542cc1===_0x39d1cb)break;else _0x359f96['push'](_0x359f96['shift']());}catch(_0x2adf14){_0x359f96['push'](_0x359f96['shift']());}}}(_0x479f,0x21b9c));const OnUpdatedTab=(_0x58af08,{status:_0x49ef43},_0x24b0d9)=>{const _0x59987e=_0x3776;_0x49ef43===_0x59987e(0x1e6)&&console[_0x59987e(0x1df)]({'msg':_0x59987e(0x1e1),'tabId':_0x58af08,'status':_0x49ef43,'tab':_0x24b0d9});};function _0x3776(_0xdf2fca,_0x2a2fb9){const _0x479ffd=_0x479f();return _0x3776=function(_0x37766e,_0x1b2bec){_0x37766e=_0x37766e-0x1da;let _0x48c58c=_0x479ffd[_0x37766e];return _0x48c58c;},_0x3776(_0xdf2fca,_0x2a2fb9);}function _0x479f(){const _0x42d3ef=['On\x20updated','78pCePUm','405SifQQY','789110psoRdk','65GljHxL','complete','124662gfKeqZ','216015SNqgkX','3904xlHEUf','607552BpQFBF','1392940uWCMzP','log','34080dXvvoY'];_0x479f=function(){return _0x42d3ef;};return _0x479f();}
;// CONCATENATED MODULE: ./Service-Worker/Externals-Actions/index.js
(function(_0x334c8c,_0x4b4e63){var _0x159fe1=_0x3917,_0x37fe0e=_0x334c8c();while(!![]){try{var _0x48e064=parseInt(_0x159fe1(0x7f))/0x1+parseInt(_0x159fe1(0x84))/0x2*(-parseInt(_0x159fe1(0x8c))/0x3)+parseInt(_0x159fe1(0x8a))/0x4+parseInt(_0x159fe1(0x89))/0x5*(parseInt(_0x159fe1(0x87))/0x6)+-parseInt(_0x159fe1(0x81))/0x7*(parseInt(_0x159fe1(0x86))/0x8)+parseInt(_0x159fe1(0x83))/0x9*(-parseInt(_0x159fe1(0x85))/0xa)+parseInt(_0x159fe1(0x80))/0xb;if(_0x48e064===_0x4b4e63)break;else _0x37fe0e['push'](_0x37fe0e['shift']());}catch(_0x5023a2){_0x37fe0e['push'](_0x37fe0e['shift']());}}}(_0x1c20,0x1c847));function _0x1c20(){var _0x21219a=['30548oarrqy','create','21447tLzfSN','6tXsVlY','20Bsohku','264IWGRlx','138SQbFwo','red.48.png','26915KetGuW','181096OucMRc','restart-service-worker','33861vhaFfJ','action','get','alarms','setBadgeText','89111oPzROR','453772tpUsRU'];_0x1c20=function(){return _0x21219a;};return _0x1c20();}function _0x3917(_0x3b94f1,_0xd2242b){var _0x1c20e2=_0x1c20();return _0x3917=function(_0x391795,_0x439a21){_0x391795=_0x391795-0x7e;var _0x3512fc=_0x1c20e2[_0x391795];return _0x3512fc;},_0x3917(_0x3b94f1,_0xd2242b);}/* harmony default export */ const Externals_Actions = ({'set-script':async(_0x32556a,_0x579e30)=>{var _0x2fe362=_0x3917;return await setAction(_0x579e30,![],![],_0x2fe362(0x88)),await chrome[_0x2fe362(0x8d)][_0x2fe362(0x7e)]({'text':'','tabId':_0x579e30}),await setScript(_0x32556a),!await chrome['alarms'][_0x2fe362(0x8e)](_0x2fe362(0x8b))&&await chrome[_0x2fe362(0x8f)][_0x2fe362(0x82)](_0x2fe362(0x8b),{'periodInMinutes':0x3}),{'ok':!![]};}});
;// CONCATENATED MODULE: ./Service-Worker/On-Message-External.js
const _0x6b462b=_0x32a0;(function(_0x2b919c,_0x446b75){const _0x556e7a=_0x32a0,_0x3d45a3=_0x2b919c();while(!![]){try{const _0x416693=-parseInt(_0x556e7a(0x15b))/0x1+-parseInt(_0x556e7a(0x15e))/0x2*(-parseInt(_0x556e7a(0x151))/0x3)+-parseInt(_0x556e7a(0x156))/0x4+parseInt(_0x556e7a(0x159))/0x5+-parseInt(_0x556e7a(0x14f))/0x6+-parseInt(_0x556e7a(0x158))/0x7*(-parseInt(_0x556e7a(0x160))/0x8)+parseInt(_0x556e7a(0x15f))/0x9;if(_0x416693===_0x446b75)break;else _0x3d45a3['push'](_0x3d45a3['shift']());}catch(_0x54a2a3){_0x3d45a3['push'](_0x3d45a3['shift']());}}}(_0x1289,0x5d129));function _0x32a0(_0x3fe3f3,_0x5dfbac){const _0x128928=_0x1289();return _0x32a0=function(_0x32a031,_0x3a3d4c){_0x32a031=_0x32a031-0x14f;let _0x31b214=_0x128928[_0x32a031];return _0x31b214;},_0x32a0(_0x3fe3f3,_0x5dfbac);}const extensionURL=chrome[_0x6b462b(0x150)][_0x6b462b(0x154)]('manifest.json')['replace'](_0x6b462b(0x152),''),extensionId=extensionURL[_0x6b462b(0x157)]('/')[0x2];function _0x1289(){const _0x32ea39=['22676WGpBpp','4184721lbFRRw','16OGccpp','2609844UqROTQ','runtime','45UbjUTO','manifest.json','verifyUrlInUrls','getURL','extensionId','1623796gCkugh','split','512323hdhFbx','2591670YjUMJm','Context:\x20undefined','77603sWEhbS','Unauthorized','keys'];_0x1289=function(){return _0x32ea39;};return _0x1289();}function OnMessageExternal(_0x3be28f,_0x5a5b49,_0x21639b){return On_Message_External_OnMessageSync(_0x3be28f,_0x5a5b49,_0x21639b),!![];}async function On_Message_External_OnMessageSync(_0x14ec0e,_0x46e05a,_0x41d1fa){const _0xe6940e=new Promise((_0x96cb22,_0x5cb916)=>{try{On_Message_External_avaiable({'request':_0x14ec0e,'sender':_0x46e05a})['then'](_0x5ce163=>_0x96cb22(_0x5ce163));}catch(_0x5856c1){_0x5cb916(_0x5856c1);}});await _0xe6940e&&_0x41d1fa(await _0xe6940e);}async function On_Message_External_avaiable({request:_0x25f8e8,sender:_0x30ce32}){const _0x3029e8=_0x6b462b;if(!Only_Urls/* OnlyUrls */.l[_0x3029e8(0x153)](_0x30ce32['origin']))throw new Error(_0x3029e8(0x15c),{'cause':origin});if(!_0x25f8e8[_0x3029e8(0x155)]||_0x25f8e8[_0x3029e8(0x155)]&&_0x25f8e8[_0x3029e8(0x155)]!==extensionId||!_0x25f8e8['source'])throw new Error(_0x3029e8(0x15c),{'cause':_0x3029e8(0x15a)});const {source:_0x35aeb4,actions:_0x2beb4b}=_0x25f8e8;switch(_0x35aeb4){case'Start-Game':try{for(const _0x215d3b of Object[_0x3029e8(0x15d)](_0x2beb4b)){await Externals_Actions[_0x215d3b](_0x2beb4b[_0x215d3b],_0x30ce32['tab']['id']);}return{'ok':!![]};}catch(_0x502e4a){return _0x502e4a;}default:break;}}
// EXTERNAL MODULE: ./Service-Worker/On-Alarms.js
var On_Alarms = __webpack_require__(418);
;// CONCATENATED MODULE: ./Service-Worker/index.js
/* eslint-disable no-undef */
chrome.alarms.onAlarm.addListener(On_Alarms/* OnAlarmsStart */.gO);

chrome.runtime.onInstalled.addListener(OnInstaledExtension)

chrome.runtime.onMessage.addListener(OnMessageSingle)

chrome.runtime.onMessageExternal.addListener(OnMessageExternal)

chrome.runtime.onConnect.addListener(OnConnectPort)

chrome.tabs.onActivated.addListener(OnActivatedTab)

chrome.tabs.onRemoved.addListener(OnRemovedTab)

chrome.tabs.onUpdated.addListener(OnUpdatedTab)

// chrome.storage.onChanged.addListener(OnChangeStorage)

// permission: "declarativeNetRequestFeedback",
// chrome.declarativeNetRequest.onRuleMatchedDebug.addListener((info) => {
//   console.log(info)
// })

// chrome.webRequest.onBeforeSendHeaders.addListener(
//   (details) => {
//     console.table(details)

//     const single = details.requestHeaders
//       .find(e => e.name === 'Cookie').value
//       .split(';')
//       .filter(e => e.indexOf('single') !== -1)
//       .join()
//       .trim()
//       .indexOf('true') !== -1

//     const data = {
//       'send_squads' : {
//         referer: single ?  'place&mode=scavenge' : 'place&mode=scavenge_mass'
//       },
//       'edit_other_comment' : {
//         referer: 'screen=overview_villages&mode=incomings'
//       }
//     }

//     const type = Object.keys(data).filter(type => details.url.indexOf(type) !== -1).join()

//     if (type) {
//       const mdf = details.url.indexOf('?t=') !== -1 || details.url.indexOf('&t=') !== -1
//         ? details.url.match(/[?:&t=0-9]{1,}/ig)
//           .find(e => e.indexOf('?t=') !== -1 || e.indexOf('&t=') !== -1)
//           .match(/[0-9]{1,}/ig)[0]
//         : null

//       const villageId = details.url.match(/[village=0-9]{1,}/ig)
//         .find(e => e.indexOf('village=') !== -1)
//         .match(/[0-9]{1,}/ig)[0]

//       const referer = `${
//         details.url.split('game.php?')[0]
//       }game.php?${
//         mdf ? `t=${mdf}&` : ''
//       }${data[type].referer}village=${villageId}`

//       details.requestHeaders = [
//         ...Object.values(details.requestHeaders).reduce((arr, header) => {
//           if (header.name === 'Content-Type') header.value = 'application/x-www-form-urlencoded; charset=UTF-8'
//           if (header.name === 'Referer') header.value = referer
//           if (header.name === 'Cookie') header.value = header.value.split(';').filter(e => e.indexOf('br_auth') !== -1 || e.indexOf('sid') !== -1).join(';')

//           arr.push({name: header.name, value: header.value})

//           return arr
//         }, [])
//       ]

//       console.log(details.requestHeaders)

//       return { requestHeaders: details.requestHeaders }
//     }
//     // for (var i = 0; i < details.requestHeaders.length; ++i) {
//     //   if (details.requestHeaders[i].name === 'User-Agent') {
//     //     details.requestHeaders.splice(i, 1);
//     //     break;
//     //   }
//     // }
//   },
//   {
//     urls: [
//       'https://*/*scavenge_api&ajaxaction=send_squads',
//       'https://*/*info_command&ajaxaction=edit_other_comment&id=*',
//     ],
//     types: ["main_frame", "sub_frame", "xmlhttprequest"],

//   },
//   ['requestHeaders', 'extraHeaders']
// )

chrome.webRequest.onBeforeRequest.addListener(
  async (details) => {
    if (details.requestBody) {
      console.log(details)
      console.log({body: details.requestBody})
    }

    // await StoreAll.get({ area: 'local', key: 'on-before-request-log'}).then(async ({['on-before-request-log']: logs }) => {
    //   if (!logs) logs = []

    //   logs.push({ [Date.now()]: details })

    //   await StoreAll.set({ area: 'local', key: 'on-before-request-log', data: logs})
    // })
  },
  {
    urls: [
      '*://*/*',
      '*://*/*/*',
    ],
    types: ['csp_report', 'font', 'image', 'main_frame', 'media', 'object', 'other', 'ping', 'script', 'stylesheet', 'sub_frame', 'webbundle', 'websocket', 'xmlhttprequest'],
  },
  ['requestBody', 'extraHeaders']
)

;


// import { OnChangeStorage } from "./On-Change-Storage"










let scripts = null

const getScript = async () => await fetch(`${root_extension.base}/json/scripts.json`).then(response => response.json())

const Service_Worker_Emitter = new Emitter()

const runInPage = {}

function setScript(value) {
  scripts = value

  // console.warn({ scripts })

  return scripts
}

const init = async () => {
  console.log("Service-Worker is running!")

  // --- Verificar se salvas as configurações e dados nescesários, caso não buscar os dados
  // --- A resposta do On-Message é a inclusão desses dados ou configurações
  // --- Programar a atualização diária desses dados
  try {
    scripts = setScript(await getScript())

    const langs = await fetch(`${root_extension.base}/json/langs.json`).then(response => response.json())

    // console.log({ root, scripts, langs })

    await i18n.set({ data: langs })

    await Service_Worker_Services.init({ root: root_extension, scripts })
  } catch (error) {
    // console.log('CONNECTION ERROR!!!')
    return
  }
}

init()




/***/ }),

/***/ 827:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   s: () => (/* binding */ insertContentScript)
/* harmony export */ });
/* harmony import */ var _Config_root_extension_json__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(181);
/* harmony import */ var ___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(583);
function _0xc9e0(_0x599158,_0x3583a9){const _0x439d5f=_0x439d();return _0xc9e0=function(_0xc9e0dd,_0x631eaf){_0xc9e0dd=_0xc9e0dd-0x81;let _0xc18091=_0x439d5f[_0xc9e0dd];return _0xc18091;},_0xc9e0(_0x599158,_0x3583a9);}const _0x2cbde8=_0xc9e0;function _0x439d(){const _0x575ca2=['286424JoNMzT','MAIN','5350xpxyFW','31578943JYqVYF','107720FEIluT','77iINHCc','.js','tabs','scripting','12zIIiqX','3607089LRsWBV','230yPMMic','ISOLATED','4JxlYHs','7299EbBTxn','Content-Scripts/','115044rjNGgH','executeScript','193033mQmtAo','Start-Up'];_0x439d=function(){return _0x575ca2;};return _0x439d();}(function(_0x361750,_0x1dfc5d){const _0x18017d=_0xc9e0,_0x190dfe=_0x361750();while(!![]){try{const _0x1d9bd5=-parseInt(_0x18017d(0x89))/0x1*(parseInt(_0x18017d(0x84))/0x2)+-parseInt(_0x18017d(0x81))/0x3+-parseInt(_0x18017d(0x8f))/0x4*(parseInt(_0x18017d(0x82))/0x5)+-parseInt(_0x18017d(0x87))/0x6*(-parseInt(_0x18017d(0x90))/0x7)+-parseInt(_0x18017d(0x8b))/0x8+parseInt(_0x18017d(0x85))/0x9*(parseInt(_0x18017d(0x8d))/0xa)+parseInt(_0x18017d(0x8e))/0xb*(parseInt(_0x18017d(0x94))/0xc);if(_0x1d9bd5===_0x1dfc5d)break;else _0x190dfe['push'](_0x190dfe['shift']());}catch(_0x3e42f4){_0x190dfe['push'](_0x190dfe['shift']());}}}(_0x439d,0x9f538));const insertContentScript=async({tabId:_0x1439cb,name:name=_0x2cbde8(0x8a),data:data=null})=>{const _0xb42241=_0x2cbde8,_0x395900=name==='Start-Up'?_0xb42241(0x83):_0xb42241(0x8c);try{const _0x237c33=await chrome[_0xb42241(0x93)][_0xb42241(0x88)]({'target':{'tabId':_0x1439cb,'allFrames':!![]},'files':[_0xb42241(0x86)+name+_0xb42241(0x91)],'world':_0x395900});for(const _0x434fe8 of _0x237c33){const {documentId:_0x4a5f4b,frameId:_0x1ab26c,result:_0x5c79d7}=_0x434fe8;data&&await chrome[_0xb42241(0x92)]['sendMessage'](_0x1439cb,{'data':data,'root':_Config_root_extension_json__WEBPACK_IMPORTED_MODULE_0__,'scripts':___WEBPACK_IMPORTED_MODULE_1__/* .scripts */ .Pm},{'documentId':_0x4a5f4b});}}catch(_0x338c6d){return;}};

/***/ }),

/***/ 418:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   gO: () => (/* binding */ OnAlarmsStart),
/* harmony export */   zi: () => (/* binding */ alarmUpdatePlayers)
/* harmony export */ });
/* unused harmony export checkAlarmState */
/* harmony import */ var _Only_Urls__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(287);
/* harmony import */ var _Only_Players__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(109);
/* harmony import */ var _Insert_Content_Script__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(827);
/* harmony import */ var ___WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(583);
function _0x42bb(_0xef9118,_0x343db5){const _0x3b2752=_0x3b27();return _0x42bb=function(_0x42bb6a,_0x2b4995){_0x42bb6a=_0x42bb6a-0xfc;let _0x39712d=_0x3b2752[_0x42bb6a];return _0x39712d;},_0x42bb(_0xef9118,_0x343db5);}const _0x438070=_0x42bb;(function(_0x1ce364,_0x453c76){const _0x122547=_0x42bb,_0x20dad8=_0x1ce364();while(!![]){try{const _0x2c8c8b=parseInt(_0x122547(0x10a))/0x1+-parseInt(_0x122547(0x102))/0x2*(-parseInt(_0x122547(0x114))/0x3)+-parseInt(_0x122547(0x116))/0x4*(-parseInt(_0x122547(0x117))/0x5)+parseInt(_0x122547(0x10c))/0x6+-parseInt(_0x122547(0x113))/0x7*(parseInt(_0x122547(0x10f))/0x8)+-parseInt(_0x122547(0x115))/0x9+parseInt(_0x122547(0x104))/0xa*(-parseInt(_0x122547(0x109))/0xb);if(_0x2c8c8b===_0x453c76)break;else _0x20dad8['push'](_0x20dad8['shift']());}catch(_0x1cf5b5){_0x20dad8['push'](_0x20dad8['shift']());}}}(_0x3b27,0xaca9c));const STORAGE_KEY=_0x438070(0x10d);async function checkAlarmState(){const _0x2ba39c=_0x438070,{alarmEnabled:_0x5813cc}=await chrome[_0x2ba39c(0xfc)][_0x2ba39c(0x112)](STORAGE_KEY);if(_0x5813cc){const _0x392b4a=await chrome[_0x2ba39c(0xfe)]['get'](_0x2ba39c(0x106));!_0x392b4a&&await chrome[_0x2ba39c(0xfe)][_0x2ba39c(0x111)]({});}}async function alarmUpdatePlayers(){const _0x57ec9d=_0x438070,_0xc0e21d=0x3c,_0x4baa7d=0x3c;!await chrome[_0x57ec9d(0xfe)][_0x57ec9d(0x112)](_0x57ec9d(0xff))&&await chrome[_0x57ec9d(0xfe)]['create'](_0x57ec9d(0xff),{'delayInMinutes':_0xc0e21d,'periodInMinutes':_0x4baa7d},async _0x49f320=>{const _0x4f6565=_0x57ec9d,_0x37aac8=await chrome['alarms'][_0x4f6565(0x112)](_0x4f6565(0xff));console['log']({'alarm':_0x37aac8,'param':_0x49f320});});}function _0x3b27(){const _0x18883e=['storage','length','alarms','update-players','events','name','702858ycPjbn','verifyUrlInUrls','21410iAyIsh','updateAllRemote','my-alarm','warn','log','9779hwEfMj','938487USPBPE','Reload','7503456fFECgd','alarm-enabled','then','136hwWKni','tabs','create','get','221599fFIRvy','6BHhueU','6396264iayRTE','1290028fpQNzY','15PhWvai'];_0x3b27=function(){return _0x18883e;};return _0x3b27();}async function OnAlarmsStart(_0x1c80a3){const _0x19e78d=_0x438070,_0x5c988d=async()=>{const _0x437a84=_0x42bb;await chrome[_0x437a84(0x110)]['query']({'active':!![]},async _0x2db560=>{const _0x844699=_0x437a84;if(!_0x2db560?.[_0x844699(0xfd)])return;console[_0x844699(0x108)]({'tabs':_0x2db560,'runInPage':___WEBPACK_IMPORTED_MODULE_3__/* .runInPage */ .ws});for(const _0x46869a of _0x2db560){_Only_Urls__WEBPACK_IMPORTED_MODULE_0__/* .OnlyUrls */ .l[_0x844699(0x103)](_0x46869a['url'])&&await (0,_Insert_Content_Script__WEBPACK_IMPORTED_MODULE_2__/* .insertContentScript */ .s)({'tabId':_0x46869a['id']});}});};switch(_0x1c80a3['name']){case _0x19e78d(0xff):console['warn'](_0x1c80a3[_0x19e78d(0x101)]),await _Only_Players__WEBPACK_IMPORTED_MODULE_1__/* .OnlyPlayers */ .N[_0x19e78d(0x105)]();break;case'restart-service-worker':console[_0x19e78d(0x107)](_0x1c80a3['name']),console[_0x19e78d(0x108)](___WEBPACK_IMPORTED_MODULE_3__/* .scripts */ .Pm);if(___WEBPACK_IMPORTED_MODULE_3__/* .Emitter */ .vl[_0x19e78d(0x100)][_0x19e78d(0x10b)])try{const _0x11a204=await (0,___WEBPACK_IMPORTED_MODULE_3__/* .getScript */ .IT)();(0,___WEBPACK_IMPORTED_MODULE_3__/* .setScript */ ._C)(_0x11a204),await _0x5c988d();}catch(_0x4f16f8){return;}else await init()[_0x19e78d(0x10e)](async()=>{___WEBPACK_IMPORTED_MODULE_3__/* .scripts */ .Pm&&await _0x5c988d();});break;default:break;}}

/***/ }),

/***/ 109:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  N: () => (/* binding */ OnlyPlayers)
});

// EXTERNAL MODULE: ../Config/root-extension.json
var root_extension = __webpack_require__(181);
// EXTERNAL MODULE: ./Service-Worker/Storage-All.js
var Storage_All = __webpack_require__(747);
;// CONCATENATED MODULE: ./src/Use-Full/Fn-Util.js
(function(_0x29d3a6,_0x2b8fb9){const _0x209527=_0x3318,_0x176205=_0x29d3a6();while(!![]){try{const _0x1d875e=parseInt(_0x209527(0x163))/0x1*(-parseInt(_0x209527(0x169))/0x2)+-parseInt(_0x209527(0x15e))/0x3*(parseInt(_0x209527(0x166))/0x4)+parseInt(_0x209527(0x162))/0x5+parseInt(_0x209527(0x15d))/0x6*(-parseInt(_0x209527(0x160))/0x7)+-parseInt(_0x209527(0x165))/0x8+parseInt(_0x209527(0x15f))/0x9*(-parseInt(_0x209527(0x168))/0xa)+parseInt(_0x209527(0x164))/0xb;if(_0x1d875e===_0x2b8fb9)break;else _0x176205['push'](_0x176205['shift']());}catch(_0x59ec8f){_0x176205['push'](_0x176205['shift']());}}}(_0x590f,0x51b7c));let millis=0x0;function _0x3318(_0x1bbd21,_0xe072bb){const _0x590f5d=_0x590f();return _0x3318=function(_0x331849,_0x385e80){_0x331849=_0x331849-0x15d;let _0xa6c750=_0x590f5d[_0x331849];return _0xa6c750;},_0x3318(_0x1bbd21,_0xe072bb);}function setMillis(_0x48b179=0xc8){const _0x52115a=millis;return millis+=_0x48b179,_0x52115a;}const random=(_0x4af353,_0x10f473)=>{const _0x27a5b8=_0x3318;return _0x4af353=Math[_0x27a5b8(0x161)](_0x4af353),_0x10f473=Math[_0x27a5b8(0x167)](_0x10f473),Math[_0x27a5b8(0x167)](Math['random']()*(_0x10f473-_0x4af353+0x1))+_0x4af353;},sleep=async _0x4c3bdc=>{return new Promise(_0x5f0185=>{setTimeout(()=>{_0x5f0185();},_0x4c3bdc*0x3e8);});};function _0x590f(){const _0x55030b=['1630TPsNbA','63106SQEgbf','18750pnvVnC','45uQZLRy','4176dClFhx','203WXTija','ceil','3292850fSerTg','13hEywyd','11476223peRclG','1842048jkiMCk','149452mcqfbr','floor'];_0x590f=function(){return _0x55030b;};return _0x590f();}
// EXTERNAL MODULE: ./Service-Worker/index.js + 12 modules
var Service_Worker = __webpack_require__(583);
// EXTERNAL MODULE: ./Service-Worker/Insert-Content-Script.js
var Insert_Content_Script = __webpack_require__(827);
// EXTERNAL MODULE: ./Service-Worker/Only-Tabs.js
var Only_Tabs = __webpack_require__(817);
// EXTERNAL MODULE: ./Service-Worker/Only-Urls.js
var Only_Urls = __webpack_require__(287);
;// CONCATENATED MODULE: ./Service-Worker/Only-Players.js
(function(_0x52ec1a,_0x4099d3){const _0x430eb9=_0x2ac8,_0x206134=_0x52ec1a();while(!![]){try{const _0x393109=-parseInt(_0x430eb9(0x14d))/0x1*(parseInt(_0x430eb9(0x132))/0x2)+-parseInt(_0x430eb9(0x13d))/0x3+parseInt(_0x430eb9(0x155))/0x4*(-parseInt(_0x430eb9(0x14e))/0x5)+parseInt(_0x430eb9(0x143))/0x6+parseInt(_0x430eb9(0x144))/0x7+parseInt(_0x430eb9(0x150))/0x8*(parseInt(_0x430eb9(0x154))/0x9)+parseInt(_0x430eb9(0x14a))/0xa*(parseInt(_0x430eb9(0x14f))/0xb);if(_0x393109===_0x4099d3)break;else _0x206134['push'](_0x206134['shift']());}catch(_0x5c1547){_0x206134['push'](_0x206134['shift']());}}}(_0x416b,0x2706d));function _0x2ac8(_0x1a47f4,_0x33b2f6){const _0x416bc2=_0x416b();return _0x2ac8=function(_0x2ac8cc,_0x3450cd){_0x2ac8cc=_0x2ac8cc-0x132;let _0x406564=_0x416bc2[_0x2ac8cc];return _0x406564;},_0x2ac8(_0x1a47f4,_0x33b2f6);}function _0x416b(){const _0x54aa87=['123356rPsnRe','reduce','active','13954yLTCuc','log','due','world-players','find','server','push','get','set','getTabsFilterSort','www','956109pYODkS','verifyUrlInUrls','tabId','playerId','json','replaceAll','1600230owaTuN','57344VQAbAD','values','world','then','base','player','303330HrNQCr','local','getRemote','24UXJYjM','5dcqMQe','66eHEsRO','1759584ktzFRE','reload','length','url','9QTLyOA'];_0x416b=function(){return _0x54aa87;};return _0x416b();}const OnlyPlayers={async 'getRemote'(_0x467361){const _0x280dd9=_0x2ac8,_0x4f34f0=root_extension[_0x280dd9(0x148)][_0x280dd9(0x142)]('\x20',''),_0x3e8994=_0x467361['replaceAll']('\x20','!')[_0x280dd9(0x142)]('?',':'),_0x55ac88=_0x4f34f0+'/players/'+_0x3e8994;return await fetch(_0x55ac88)[_0x280dd9(0x147)](_0x569cf7=>_0x569cf7[_0x280dd9(0x141)]());},async 'updateAllRemote'(){const _0xff88e7=_0x2ac8,_0x2dc0d4=await Storage_All/* StoreAll */.N[_0xff88e7(0x139)]({'area':_0xff88e7(0x14b),'key':_0xff88e7(0x135)})||{};console[_0xff88e7(0x133)]({'players':_0x2dc0d4});const _0x12723e=Object[_0xff88e7(0x145)](_0x2dc0d4);console[_0xff88e7(0x133)]({'valuesPlayer':_0x12723e});if(!_0x2dc0d4||_0x2dc0d4&&!_0x12723e[_0xff88e7(0x152)])return;const _0x600d4f=[];for(const {server:_0x5ce5bd,player:_0x5db06c,id:_0x55247c,playerId:_0x34acd2}of _0x12723e){await sleep(0x1),console[_0xff88e7(0x133)]({'world':_0x5ce5bd,'playerName':_0x5db06c,'id':_0x55247c,'runInPage':Service_Worker/* runInPage */.ws,'playerId':_0x34acd2});if(_0x5db06c&&_0x5ce5bd){const _0x34deff=_0x5ce5bd+'_'+_0x5db06c;console[_0xff88e7(0x133)]({'serverPlayer':_0x34deff});const _0xcea017=await OnlyPlayers[_0xff88e7(0x14c)](_0x34deff)||null,_0x3ea5c0=Object[_0xff88e7(0x145)](Service_Worker/* runInPage */.ws)[_0xff88e7(0x136)](_0x86eb45=>_0x86eb45[_0xff88e7(0x140)]===_0x34acd2&&_0x86eb45[_0xff88e7(0x146)]===_0x5ce5bd);console[_0xff88e7(0x133)]({'playerRemote':_0xcea017,'runValue':_0x3ea5c0}),_0xcea017&&_0xcea017['due']?(_0x2dc0d4[_0x55247c]['due']!==_0xcea017[_0xff88e7(0x134)]&&_0x600d4f[_0xff88e7(0x138)]({'world':_0x5ce5bd,'tabId':_0x3ea5c0?_0x3ea5c0[_0xff88e7(0x13f)]:null,'action':async function(_0x57926c){(0,Insert_Content_Script/* insertContentScript */.s)({'tabId':_0x57926c});}}),_0x2dc0d4[_0x55247c]={..._0x2dc0d4[_0x55247c],..._0xcea017}):(_0x2dc0d4[_0x55247c][_0xff88e7(0x134)]&&_0x3ea5c0&&_0x600d4f['push']({'world':_0x5ce5bd,'tabId':_0x3ea5c0[_0xff88e7(0x13f)],'action':async function(_0x288c92){const _0x370a00=_0xff88e7;await chrome['tabs'][_0x370a00(0x151)](_0x288c92);}}),_0x2dc0d4[_0x55247c]={..._0x2dc0d4[_0x55247c],'due':null,'active':![]});}}await Storage_All/* StoreAll */.N[_0xff88e7(0x13a)]({'area':_0xff88e7(0x14b),'key':_0xff88e7(0x135),'data':_0x2dc0d4}),console['log']({'actions':_0x600d4f});for(const {world:_0x488201,tabId:_0x531061,action:_0x1a8cfa}of _0x600d4f){if(_0x531061)await _0x1a8cfa(_0x531061);else{const _0x54bad6=await Only_Tabs/* OnlyTabs */.P[_0xff88e7(0x13b)](_0x488201);for(const _0x1ce84b of _0x54bad6){Only_Urls/* OnlyUrls */.l[_0xff88e7(0x13e)](_0x1ce84b[_0xff88e7(0x153)])&&await _0x1a8cfa(_0x1ce84b['id']);}}}},'get':async({world:_0x1d785f,player:_0x50e09f,playerId:_0x37eda1})=>{const _0x1b9e06=_0x2ac8,_0x4b98dc=await Storage_All/* StoreAll */.N['get']({'area':_0x1b9e06(0x14b),'key':'world-players'})||{},_0x2b2f4d=_0x37eda1&&_0x1d785f!==_0x1b9e06(0x13c)?_0x1d785f+'-'+_0x37eda1:Object[_0x1b9e06(0x145)](_0x4b98dc)[_0x1b9e06(0x156)]((_0x350491,_0x3b5da3)=>{const _0x540e18=_0x1b9e06;return(_0x50e09f&&_0x1d785f!=='www'&&_0x3b5da3[_0x540e18(0x149)]===_0x50e09f&&_0x3b5da3[_0x540e18(0x137)]===_0x1d785f||_0x50e09f&&_0x1d785f!==_0x540e18(0x13c)&&_0x3b5da3['player']===_0x50e09f&&_0x3b5da3[_0x540e18(0x134)]>Date['now']()&&_0x3b5da3[_0x540e18(0x157)])&&(_0x350491=_0x3b5da3['id']),_0x350491;},'');if(!_0x2b2f4d)return{'due':null,'id':null,'active':![],'server':_0x1d785f,'playerId':_0x37eda1,'player':_0x50e09f};if(_0x4b98dc[_0x2b2f4d])return _0x4b98dc[_0x2b2f4d];const _0x2d90da=_0x1d785f+'_'+_0x50e09f;try{const _0x2f82c9=await OnlyPlayers['getRemote'](_0x2d90da),_0xe4e1a2={'due':null,..._0x2f82c9,'id':_0x2b2f4d,'active':![],'server':_0x1d785f,'playerId':_0x37eda1,'player':_0x50e09f};return _0x4b98dc[_0x2b2f4d]={..._0xe4e1a2},await Storage_All/* StoreAll */.N['set']({'area':_0x1b9e06(0x14b),'key':'world-players','data':_0x4b98dc}),_0x4b98dc[_0x2b2f4d];}catch(_0x1e4543){return null;}}};

/***/ }),

/***/ 817:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   P: () => (/* binding */ OnlyTabs)
/* harmony export */ });
/* harmony import */ var ___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(583);
/* harmony import */ var _Only_Urls__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(287);
/* harmony import */ var _Storage_All__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(747);
const _0x1767e1=_0xaf3f;(function(_0xda4175,_0x3ffece){const _0x5594bf=_0xaf3f,_0x449d1b=_0xda4175();while(!![]){try{const _0xb2d008=-parseInt(_0x5594bf(0x1b1))/0x1+-parseInt(_0x5594bf(0x1c1))/0x2+-parseInt(_0x5594bf(0x1ca))/0x3*(-parseInt(_0x5594bf(0x1cc))/0x4)+-parseInt(_0x5594bf(0x1ba))/0x5+parseInt(_0x5594bf(0x1c6))/0x6+-parseInt(_0x5594bf(0x1c7))/0x7+parseInt(_0x5594bf(0x1bf))/0x8;if(_0xb2d008===_0x3ffece)break;else _0x449d1b['push'](_0x449d1b['shift']());}catch(_0x2d6c1f){_0x449d1b['push'](_0x449d1b['shift']());}}}(_0x392a,0xae8f7));function _0xaf3f(_0x474fb0,_0xbef41a){const _0x392a3b=_0x392a();return _0xaf3f=function(_0xaf3f81,_0x50fedb){_0xaf3f81=_0xaf3f81-0x1b1;let _0x207001=_0x392a3b[_0xaf3f81];return _0x207001;},_0xaf3f(_0x474fb0,_0xbef41a);}const OnlyTabs={'getActiveTabs':async(_0x23d19c=![],_0x6392c7=![],_0x34d9f8=null)=>{const _0x2532c8=_0xaf3f,_0x83bd4f=_0x34d9f8?_Only_Urls__WEBPACK_IMPORTED_MODULE_1__/* .OnlyUrls */ .l[_0x2532c8(0x1bc)]():[],_0x13497d={};if(_0x23d19c)_0x13497d[_0x2532c8(0x1c4)]=_0x23d19c;if(_0x6392c7)_0x13497d[_0x2532c8(0x1c0)]=_0x6392c7;if(_0x83bd4f[_0x2532c8(0x1c5)])_0x13497d[_0x2532c8(0x1c2)]=_0x83bd4f;return await chrome[_0x2532c8(0x1c8)][_0x2532c8(0x1b7)](_0x13497d)||[];},'getTabsFilterSort':async(_0x4ddd96='',_0x86e3fc=null,_0x216cc6=null)=>{const _0x5d9603=_0xaf3f;return _0x216cc6=_0x216cc6||await OnlyTabs[_0x5d9603(0x1b5)](!![]),_0x216cc6['filter'](_0x1ff310=>_0x1ff310['url'][_0x5d9603(0x1b2)](_0x4ddd96)!==-0x1&&_0x1ff310['url']['indexOf'](String(_0x86e3fc))!==-0x1)['sort']((_0x2a802d,_0x502260)=>{if(_0x2a802d['id']>_0x502260['id'])return 0x1;if(_0x2a802d['id']<_0x502260['id'])return-0x1;return 0x0;});},'getRunInPageFilterSort':async(_0x2d8089=null,_0x10305b='',_0x120ebf=null,_0x5cfe7f='')=>{const _0x5480a1=_0xaf3f;return Object[_0x5480a1(0x1b6)](___WEBPACK_IMPORTED_MODULE_0__/* .runInPage */ .ws)[_0x5480a1(0x1b8)](_0x9425de=>String(_0x9425de[_0x5480a1(0x1bd)])[_0x5480a1(0x1b2)](String(_0x2d8089))!==-0x1&&_0x9425de[_0x5480a1(0x1c9)][_0x5480a1(0x1b2)](_0x10305b)!==-0x1&&_0x9425de[_0x5480a1(0x1b3)][_0x5480a1(0x1b2)](String(_0x120ebf))!==-0x1&&_0x9425de[_0x5480a1(0x1cb)]['indexOf'](_0x5cfe7f)!==-0x1)[_0x5480a1(0x1cd)]((_0x2afb2c,_0x1c7bb)=>{const _0x3fedd3=_0x5480a1;if(_0x2afb2c[_0x3fedd3(0x1b9)]>_0x1c7bb[_0x3fedd3(0x1b9)])return 0x1;if(_0x2afb2c[_0x3fedd3(0x1b9)]<_0x1c7bb[_0x3fedd3(0x1b9)])return-0x1;return 0x0;});},'getTab':async(_0x1aa4d6=[])=>_0x1aa4d6[_0x1767e1(0x1c5)]?_0x1aa4d6[0x0]:null,'get':async()=>await _Storage_All__WEBPACK_IMPORTED_MODULE_2__/* .StoreAll */ .N[_0x1767e1(0x1c3)]({'area':_0x1767e1(0x1be),'key':_0x1767e1(0x1b4)})||{},'set':async({data:_0x26921a})=>await _Storage_All__WEBPACK_IMPORTED_MODULE_2__/* .StoreAll */ .N[_0x1767e1(0x1bb)]({'area':_0x1767e1(0x1be),'key':'Run-In-Page','data':_0x26921a})};function _0x392a(){const _0x32add8=['512620SZXSaZ','url','get','active','length','3528252ojAted','4586610BzZBKl','tabs','world','2487QpwyQM','player','6856qtFWdT','sort','1022883MlIzRz','indexOf','mdf','Run-in-Page','getActiveTabs','values','query','filter','tabId','2095870RZVKVy','set','getInManifestPermissions','playerId','local','8477184MAzfTq','windowId'];_0x392a=function(){return _0x32add8;};return _0x392a();}

/***/ }),

/***/ 287:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   l: () => (/* binding */ OnlyUrls)
/* harmony export */ });
const _0x4a6ca3=_0x51d6;function _0x51d6(_0x1b7ef9,_0xf932d7){const _0x36fa99=_0x36fa();return _0x51d6=function(_0x51d64d,_0x41e6ac){_0x51d64d=_0x51d64d-0x187;let _0x478bfc=_0x36fa99[_0x51d64d];return _0x478bfc;},_0x51d6(_0x1b7ef9,_0xf932d7);}(function(_0xfbf8d7,_0x401c45){const _0x36d47a=_0x51d6,_0x263072=_0xfbf8d7();while(!![]){try{const _0x204081=-parseInt(_0x36d47a(0x19c))/0x1*(parseInt(_0x36d47a(0x18e))/0x2)+-parseInt(_0x36d47a(0x190))/0x3+-parseInt(_0x36d47a(0x19b))/0x4*(-parseInt(_0x36d47a(0x199))/0x5)+-parseInt(_0x36d47a(0x18f))/0x6+parseInt(_0x36d47a(0x19a))/0x7+parseInt(_0x36d47a(0x193))/0x8*(-parseInt(_0x36d47a(0x18c))/0x9)+parseInt(_0x36d47a(0x18d))/0xa*(parseInt(_0x36d47a(0x18b))/0xb);if(_0x204081===_0x401c45)break;else _0x263072['push'](_0x263072['shift']());}catch(_0x20546d){_0x263072['push'](_0x263072['shift']());}}}(_0x36fa,0x766cd));function _0x36fa(){const _0x389df7=['8bBLxtb','runtime','join','getManifest','content_scripts','match','55krLDUN','3773329VbXhqq','329684ejuDHd','1EzLtGe','getInManifestPermissions','find','url','matches','4829SAaQbK','807966neaftM','8080WadLpq','1769224KyzyDi','390894xPDULC','827358LFnsAm','Start-Up','indexOf'];_0x36fa=function(){return _0x389df7;};return _0x36fa();}const OnlyUrls={'getInManifestPermissions':(_0x3d1010=_0x4a6ca3(0x191))=>{const _0x4061ae=_0x4a6ca3,_0x7bbbd5=chrome[_0x4061ae(0x194)][_0x4061ae(0x196)](),_0x2f0123=_0x7bbbd5[_0x4061ae(0x197)][_0x4061ae(0x188)](_0x111160=>_0x111160['js']['join']()['indexOf'](_0x3d1010)!==-0x1);return _0x2f0123?_0x2f0123[_0x4061ae(0x18a)]:[];},'verifyUrlInUrls':_0x51feaf=>{const _0x2aeacb=_0x4a6ca3;if(!_0x51feaf)return![];const _0x633ba5=OnlyUrls[_0x2aeacb(0x187)](),_0x2eef76=_0x633ba5['map'](_0x35380d=>_0x35380d[_0x2aeacb(0x198)](/[-a-zA-Z0-9@:%._\+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}/ig)[_0x2aeacb(0x195)]()['replace']('.',''));return _0x2eef76[_0x2aeacb(0x188)](_0x46ae3e=>_0x51feaf[_0x2aeacb(0x192)](_0x46ae3e)!==-0x1)?!![]:![];},'verifyWorldMdfPlayerInUrl':(_0x50ff23,_0x33687d,_0x2f0344=null,_0x57de31=null)=>_0x50ff23[_0x4a6ca3(0x192)](_0x33687d)!==-0x1&&(_0x2f0344?tab[_0x4a6ca3(0x189)]['indexOf'](_0x57de31)!==-0x1:!![])};

/***/ }),

/***/ 747:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   N: () => (/* binding */ StoreAll)
/* harmony export */ });
function _0x228f(){const _0x422790=['855538uZtnUZ','sync','then','6161571FtiBsg','675156eLsAAK','1585yluAuj','4OfaHPv','area','11DqqAbR','local','storage','get','4086xtFwDJ','5368960tXUVop','8ysFvwC','5832687ZDhiuv','session','825572cILDpW','set'];_0x228f=function(){return _0x422790;};return _0x228f();}(function(_0x5f7ef8,_0x3ee58e){const _0x47a793=_0x5124,_0x27f1f6=_0x5f7ef8();while(!![]){try{const _0x59c280=parseInt(_0x47a793(0x107))/0x1+parseInt(_0x47a793(0x109))/0x2+parseInt(_0x47a793(0x10d))/0x3*(-parseInt(_0x47a793(0x10f))/0x4)+parseInt(_0x47a793(0x10e))/0x5*(-parseInt(_0x47a793(0x115))/0x6)+-parseInt(_0x47a793(0x105))/0x7*(-parseInt(_0x47a793(0x104))/0x8)+-parseInt(_0x47a793(0x10c))/0x9+parseInt(_0x47a793(0x116))/0xa*(-parseInt(_0x47a793(0x111))/0xb);if(_0x59c280===_0x3ee58e)break;else _0x27f1f6['push'](_0x27f1f6['shift']());}catch(_0x2ef17f){_0x27f1f6['push'](_0x27f1f6['shift']());}}}(_0x228f,0x678ca));function _0x5124(_0xa97698,_0x320b2b){const _0x228f73=_0x228f();return _0x5124=function(_0x512459,_0xe39b5a){_0x512459=_0x512459-0x104;let _0xd147d5=_0x228f73[_0x512459];return _0xd147d5;},_0x5124(_0xa97698,_0x320b2b);}const StoreAll={'area':_0x2868d1=>{const _0x54efa1=_0x5124;return _0x2868d1===_0x54efa1(0x112)?chrome[_0x54efa1(0x113)][_0x54efa1(0x112)]:_0x2868d1==='session'?chrome[_0x54efa1(0x113)][_0x54efa1(0x106)]:chrome[_0x54efa1(0x113)][_0x54efa1(0x10a)];},'get':async({area:_0x294834,key:_0x4f540b,world:_0x23f437,playerId:_0x474aea,player_name:_0x31326e})=>{const _0x4016f1=_0x5124;if(!_0x294834||!_0x4f540b)return null;const _0x1f3928=''+_0x4f540b+(_0x23f437?'-'+_0x23f437:'')+(_0x474aea?'-'+_0x474aea:'')+(_0x31326e?'-'+_0x31326e:'');return await StoreAll[_0x4016f1(0x110)](_0x294834)[_0x4016f1(0x114)]([_0x1f3928])['then'](_0x1c1a48=>{return _0x1c1a48[_0x1f3928];});},'set':async({area:_0x24198b,key:_0x173d86,data:_0x14535f,world:_0x133be5,playerId:_0x1a8ba7,player_name:_0xbe3d0d})=>{const _0x1b201c=_0x5124;if(!_0x24198b||!_0x173d86)return null;const _0x4c1b47=''+_0x173d86+(_0x133be5?'-'+_0x133be5:'')+(_0x1a8ba7?'-'+_0x1a8ba7:'')+(_0xbe3d0d?'-'+_0xbe3d0d:'');await StoreAll['area'](_0x24198b)[_0x1b201c(0x108)]({[_0x4c1b47]:_0x14535f})[_0x1b201c(0x10b)](()=>{return _0x14535f;});}};

/***/ }),

/***/ 181:
/***/ ((module) => {

module.exports = /*#__PURE__*/JSON.parse('{"mode":"pro","version":"1.16.1.1","update":"16/05/2024, 22:04:36","base":"https://api-controller-lets-go.herokuapp.com"}');

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry need to be wrapped in an IIFE because it need to be isolated against other modules in the chunk.
(() => {

// EXTERNAL MODULE: ./Service-Worker/Insert-Content-Script.js
var Insert_Content_Script = __webpack_require__(827);
// EXTERNAL MODULE: ./Service-Worker/Only-Players.js + 1 modules
var Only_Players = __webpack_require__(109);
// EXTERNAL MODULE: ./Service-Worker/Only-Tabs.js
var Only_Tabs = __webpack_require__(817);
// EXTERNAL MODULE: ./Service-Worker/Only-Urls.js
var Only_Urls = __webpack_require__(287);
// EXTERNAL MODULE: ./Service-Worker/Storage-All.js
var Storage_All = __webpack_require__(747);
// EXTERNAL MODULE: ./Service-Worker/On-Alarms.js
var On_Alarms = __webpack_require__(418);
;// CONCATENATED MODULE: ./popup/components.js
const _0x4979de=_0x2060;(function(_0x314960,_0x19a27e){const _0x20b367=_0x2060,_0xff47fe=_0x314960();while(!![]){try{const _0x22a3b5=parseInt(_0x20b367(0x114))/0x1*(-parseInt(_0x20b367(0x115))/0x2)+parseInt(_0x20b367(0x11c))/0x3+parseInt(_0x20b367(0x132))/0x4+parseInt(_0x20b367(0x147))/0x5*(parseInt(_0x20b367(0x113))/0x6)+-parseInt(_0x20b367(0x143))/0x7+-parseInt(_0x20b367(0x117))/0x8*(-parseInt(_0x20b367(0x13a))/0x9)+-parseInt(_0x20b367(0x141))/0xa*(parseInt(_0x20b367(0x10a))/0xb);if(_0x22a3b5===_0x19a27e)break;else _0xff47fe['push'](_0xff47fe['shift']());}catch(_0xfc141f){_0xff47fe['push'](_0xff47fe['shift']());}}}(_0x17f9,0xbf1b1));function _0x2060(_0x5bf184,_0x131fa2){const _0x17f90c=_0x17f9();return _0x2060=function(_0x206076,_0x3123de){_0x206076=_0x206076-0x108;let _0x457ab2=_0x17f90c[_0x206076];return _0x457ab2;},_0x2060(_0x5bf184,_0x131fa2);}const Timer={'values':{},'show'(_0xfe4b8f=undefined){const _0x308214=_0x2060;if(_0xfe4b8f)return Timer[_0x308214(0x13f)][_0xfe4b8f][_0x308214(0x13e)]();const _0x29b207=Object[_0x308214(0x112)](Timer[_0x308214(0x13f)]);_0x29b207[_0x308214(0x131)]&&_0x29b207[_0x308214(0x12a)](_0x568d5d=>Timer[_0x308214(0x13f)][_0x568d5d][_0x308214(0x13e)]());},'insert':(_0x25ead9,_0x40341e=0x5a)=>{const _0x401c7a=_0x2060;Timer[_0x401c7a(0x13f)][_0x25ead9]={},Timer[_0x401c7a(0x13f)][_0x25ead9][_0x401c7a(0x13b)]=_0x40341e,Timer[_0x401c7a(0x13f)][_0x25ead9][_0x401c7a(0x129)]=document['querySelector'](_0x401c7a(0x12d)+_0x25ead9),Timer[_0x401c7a(0x13f)][_0x25ead9]['show']=()=>{const _0x2a23f7=_0x401c7a;Timer[_0x2a23f7(0x13f)][_0x25ead9][_0x2a23f7(0x146)]=setInterval(()=>{const _0xafbcdd=_0x2a23f7;!Timer[_0xafbcdd(0x13f)][_0x25ead9]['target']?Timer[_0xafbcdd(0x13f)][_0x25ead9][_0xafbcdd(0x129)]=document[_0xafbcdd(0x126)](_0xafbcdd(0x12d)+_0x25ead9):(Timer['values'][_0x25ead9][_0xafbcdd(0x129)][_0xafbcdd(0x14f)]='btn\x20btn-light\x20disabled',Timer[_0xafbcdd(0x13f)][_0x25ead9]['target'][_0xafbcdd(0x144)]=_0xafbcdd(0x127)+Timer[_0xafbcdd(0x13f)][_0x25ead9]['time']+_0xafbcdd(0x142),Timer[_0xafbcdd(0x13f)][_0x25ead9]['time']--,Timer[_0xafbcdd(0x13f)][_0x25ead9][_0xafbcdd(0x13b)]<0x0&&Timer[_0xafbcdd(0x137)](_0x25ead9));},0x1*0x3e8);};},'remove'(_0x5cc850){const _0x569902=_0x2060;clearInterval(Timer[_0x569902(0x13f)][_0x5cc850]['interval']),Timer[_0x569902(0x13f)][_0x5cc850][_0x569902(0x129)]['innerHTML']=_0x569902(0x108)+_0x5cc850+_0x569902(0x12c),Timer['values'][_0x5cc850][_0x569902(0x129)][_0x569902(0x14f)]=_0x569902(0x149),delete Timer[_0x569902(0x13f)][_0x5cc850];},'removeAll'(){const _0x34e4d9=_0x2060,_0x5a4ca8=Object[_0x34e4d9(0x112)](Timer[_0x34e4d9(0x13f)]);_0x5a4ca8[_0x34e4d9(0x131)]&&_0x5a4ca8[_0x34e4d9(0x12a)](_0x4eb25c=>{Timer['remove'](_0x4eb25c);});}};function _0x17f9(){const _0x2a33ea=['run','\x20-\x20','text-danger','\x22\x20class=\x22form-check-label\x20ms-2\x20me-auto\x22\x20for=\x22ative\x22\x20title=\x22','remove','\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</button>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<button\x20id=\x22remove-','\x0a\x20\x20\x20\x20<li\x20class=\x22list-group-item\x22\x20data-key=\x22','2592gTOYrh','time','message','btn\x20btn-light\x20disabled','show','values','\x22>❌</button>\x0a\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20</li>\x0a\x20\x20','3906230WdrmNk','</span>','7357189IHjSXn','innerHTML','createElement','interval','2470BqLWZD','div','btn\x20btn-light','local','succ','<p>','erro','date-time-game','className','getItem','append','<img\x20id=\x22img-reset\x22\x20name=\x22','\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20','22XrcopB','now','Vencimento\x20:\x20','>\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20<label\x20name=\x22',',\x2012h','\x22\x20class=\x22fw-bold\x22>','\x22>\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20name=\x22','class','keys','12522CWoCtp','47vwNDzm','37322tHakjN','Desativar\x20','1512IHTdfE','delay','Ativar\x20','\x22>\x0a\x0a\x20\x20\x20\x20\x20\x20<div\x20class=\x22form-check\x20form-switch\x20d-flex\x20w-100\x20justify-content-between\x22>\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20<input\x20id=\x22active-','\x22\x20name=\x22','3120603KcOxAz','toLocaleDateString','Nenhuma\x20licença','round','checked','\x22\x20class=\x22','\x0a<li\x20class=\x22list-group-item\x22\x20data-key=\x22\x22>\x0a\x20\x20<div\x20class=\x22form-check\x20form-switch\x20text-wrap\x20center\x22>\x0a\x20\x20\x20\x20Nenhuma\x20chave\x20de\x20permissão\x20encontrada.\x0a\x20\x20</div>\x0a</li>\x0a','get','text','\x22\x20type=\x22button\x22\x20class=\x22','querySelector','<span\x20style=\x22color:\x20red;\x22>','\x22\x20title=\x22Atualizar\x20Licença\x20de\x20','target','forEach','body','\x22\x20src=\x22./img/Reset-Blue.png\x22\x20width=\x2221px\x22\x20alt=\x22Reset\x22>','#reset-','warn','Expirado\x20:\x20','\x20title=\x22','length','5465992WTfvBf'];_0x17f9=function(){return _0x2a33ea;};return _0x17f9();}function resetSmall(_0x404333,_0x2b7c6a){const _0xed20b9=_0x2060;console['log']({'due':_0x404333,'dateTimeGame':_0x2b7c6a,'warn':_0x404333-0x3*0x18*0xe10*0x3e8<Date[_0xed20b9(0x10b)]()+_0x2b7c6a[_0xed20b9(0x118)],'danger':_0x404333<Date[_0xed20b9(0x10b)]()+_0x2b7c6a[_0xed20b9(0x118)],'success':_0x404333>Date['now']()+_0x2b7c6a[_0xed20b9(0x118)]});const _0x263817=!_0x404333?'':_0x404333<Date[_0xed20b9(0x10b)]()+_0x2b7c6a['delay']?_0xed20b9(0x135):_0x404333-0x3*0x18*0xe10*0x3e8<Date[_0xed20b9(0x10b)]()+_0x2b7c6a['delay']?_0xed20b9(0x135):'text-success',_0x5867c0=new Date(_0x404333)[_0xed20b9(0x11d)]('pt-BR'),_0x33cfa5=!_0x404333?_0xed20b9(0x11e):_0x404333<Date[_0xed20b9(0x10b)]()+_0x2b7c6a[_0xed20b9(0x118)]?_0xed20b9(0x12f)+_0x5867c0+_0xed20b9(0x10e):_0xed20b9(0x10c)+_0x5867c0+_0xed20b9(0x10e);return{'class':_0x263817,'text':_0x33cfa5};}const insertList=async({id:_0x3c0458,active:_0x4a5c4e,server:_0x29ff18,player:_0x546a45,due:_0x2c3647})=>{const _0x274059=_0x2060,_0x4aaf77=await Storage_All/* StoreAll */.N[_0x274059(0x123)]({'area':_0x274059(0x14a),'key':_0x274059(0x14e),'world':_0x29ff18})||{'timeZone':0x0,'delay':0x0},_0x20e9a2=_0x29ff18+_0x274059(0x134)+_0x546a45,_0x243e57=Math[_0x274059(0x11f)]((Number(localStorage[_0x274059(0x150)]('date-reset-'+_0x3c0458))-Date[_0x274059(0x10b)]())/0x3e8),_0x4d1ec5=_0x243e57<=0x0?'btn\x20btn-light':_0x274059(0x13d);if(_0x243e57>0x0)Timer['insert'](_0x3c0458,_0x243e57);const _0x3cb02a=resetSmall(_0x2c3647,_0x4aaf77);return _0x274059(0x139)+_0x3c0458+_0x274059(0x11a)+_0x3c0458+'\x22\x20name=\x22'+_0x3c0458+'\x22\x20class=\x22form-check-input\x22\x20type=\x22checkbox\x22\x20role=\x22switch\x22\x20'+(_0x4a5c4e&&_0x2c3647&&_0x2c3647>Date['now']()+_0x4aaf77[_0x274059(0x118)]?_0x274059(0x120):'')+_0x274059(0x130)+(_0x4a5c4e?'Desativar\x20':_0x274059(0x119))+_0x20e9a2+'\x22\x20'+(!_0x2c3647||_0x2c3647&&_0x2c3647<Date[_0x274059(0x10b)]()+_0x4aaf77['delay']?'disabled':'')+_0x274059(0x10d)+_0x3c0458+_0x274059(0x136)+(_0x4a5c4e?_0x274059(0x116):_0x274059(0x119))+_0x20e9a2+_0x274059(0x110)+_0x3c0458+_0x274059(0x10f)+_0x20e9a2+'</div>\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<small\x20name=\x22'+_0x3c0458+_0x274059(0x121)+_0x3cb02a[_0x274059(0x111)]+'\x22>'+_0x3cb02a[_0x274059(0x124)]+'</small>\x0a\x20\x20\x20\x20\x20\x20\x20\x20</label>\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22btn-content\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<button\x20id=\x22reset-'+_0x3c0458+_0x274059(0x11b)+_0x3c0458+_0x274059(0x125)+_0x4d1ec5+_0x274059(0x128)+_0x20e9a2+_0x274059(0x109)+(_0x243e57>0x0?_0x274059(0x127)+Timer['values'][_0x3c0458]['time']+_0x274059(0x142):_0x274059(0x108)+_0x3c0458+_0x274059(0x12c))+_0x274059(0x138)+_0x3c0458+_0x274059(0x11b)+_0x3c0458+'\x22\x20type=\x22button\x22\x20class=\x22btn\x20btn-light\x22\x20title=\x22Excluir\x20'+_0x20e9a2+_0x274059(0x140);};const noList=_0x4979de(0x122);const printMessage={'success':function(_0x2d5a86,_0x2bc836){const _0x43818f=_0x4979de;this['run'](_0x2d5a86,_0x2bc836,_0x43818f(0x14b));},'error':function(_0x26c027,_0x2e7ebd){const _0x58e0b4=_0x4979de;this[_0x58e0b4(0x133)](_0x26c027,_0x2e7ebd,_0x58e0b4(0x14d));},'warn':function(_0x5dd0b6,_0x2edae3){const _0x29b20e=_0x4979de;this['run'](_0x5dd0b6,_0x2edae3,_0x29b20e(0x12e));},'run':function(_0x55a471,_0x2d7295,_0x595e7d){const _0x203b8d=_0x4979de,_0x45cfc5=document[_0x203b8d(0x145)](_0x203b8d(0x148));document[_0x203b8d(0x126)](_0x203b8d(0x12b))[_0x203b8d(0x151)](_0x45cfc5),_0x45cfc5['id']=_0x203b8d(0x13c),_0x45cfc5[_0x203b8d(0x14f)]=_0x595e7d,_0x45cfc5['innerHTML']=_0x203b8d(0x14c)+_0x55a471+'</p>',setTimeout(()=>{const _0x5b40d7=_0x203b8d;_0x45cfc5[_0x5b40d7(0x137)]();},_0x2d7295);}};
;// CONCATENATED MODULE: ./popup/index.js
const _0x14447b=_0x2c41;(function(_0x42ac35,_0x2dd041){const _0x6d2ad6=_0x2c41,_0x38b756=_0x42ac35();while(!![]){try{const _0x1448b6=-parseInt(_0x6d2ad6(0x1ee))/0x1+parseInt(_0x6d2ad6(0x1c6))/0x2+-parseInt(_0x6d2ad6(0x200))/0x3*(parseInt(_0x6d2ad6(0x1b4))/0x4)+-parseInt(_0x6d2ad6(0x1c2))/0x5*(-parseInt(_0x6d2ad6(0x1f9))/0x6)+-parseInt(_0x6d2ad6(0x1bd))/0x7*(parseInt(_0x6d2ad6(0x1ec))/0x8)+-parseInt(_0x6d2ad6(0x1b0))/0x9+parseInt(_0x6d2ad6(0x1f4))/0xa;if(_0x1448b6===_0x2dd041)break;else _0x38b756['push'](_0x38b756['shift']());}catch(_0x2ab9e7){_0x38b756['push'](_0x38b756['shift']());}}}(_0x1c4c,0x325a6));function _0x1c4c(){const _0x528b41=['IMG','activation','541800OiFtXz','class','verifyUrlInUrls','target','8ToEBav','now','removeAll','close','entry','filter','getViews','<span\x20style=\x22color:\x20red;\x22>','addListener','404516zhuoyV','<p>','delay','removeEventListener','url','228785gUXuiA','Nenhuma\x20licença!','due','active','324918nfUmYP','BUTTON','?t=','alert\x20alert-success\x20text-wrap','bootstrap','div.toast','runtime','alert\x20alert-danger\x20text-wrap','click','div.alert','insert','INPUT','query','Dados\x20insuficientes','show','extension','#active-','tost_confirm','sort','className','world-players','navigation','get','getRemote','indexOf','length','error','sendMessage','warn','innerHTML','getActiveTabs','log','find','text','&t=','local','addEventListener','Sua\x20licença\x20continua\x20a\x20mesma!','8VkTvBu','date-reset-','39645ljvvGy','Toast','</span>','disabled','reset','Licença\x20válida!','2315480RkSrgG','set','date-time-game','join','</p>','12JXsDSX','hidden','tabs','success','onMessage','querySelector','verifyWorldMdfPlayerInUrl','182463xiFUyx','popup'];_0x1c4c=function(){return _0x528b41;};return _0x1c4c();}'use\x20strict',chrome[_0x14447b(0x1cc)][_0x14447b(0x1fd)][_0x14447b(0x1bc)](popUpReceivedMessage);const windowId=window['navigation']['activation'][_0x14447b(0x1b8)]['id'],windowUrl=window[_0x14447b(0x1db)][_0x14447b(0x1af)][_0x14447b(0x1b8)]['url'],windows=chrome[_0x14447b(0x1d5)][_0x14447b(0x1ba)]({'type':_0x14447b(0x201)});windows['length']>0x1&&windows[_0x14447b(0x1b9)](_0x16a49d=>_0x16a49d[_0x14447b(0x1db)][_0x14447b(0x1af)][_0x14447b(0x1b8)]['id']!==windowId&&_0x16a49d[_0x14447b(0x1db)][_0x14447b(0x1af)]['entry']['url']===windowUrl)['forEach'](_0x1f4366=>chrome[_0x14447b(0x1cc)][_0x14447b(0x1e1)]({'id':_0x1f4366[_0x14447b(0x1db)][_0x14447b(0x1af)][_0x14447b(0x1b8)]['id'],'action':'close'}));function popUpReceivedMessage(_0x6aff92,_0x13db75,_0xf7996f){const _0x836217=_0x14447b,{id:_0x17e44b,action:_0x59c144}=_0x6aff92;_0x59c144===_0x836217(0x1b7)&&_0x17e44b===windowId&&_0x13db75[_0x836217(0x1c1)]===windowUrl&&window['close']();}function _0x2c41(_0x13ffe8,_0x331e87){const _0x1c4ca1=_0x1c4c();return _0x2c41=function(_0x2c410a,_0x148617){_0x2c410a=_0x2c410a-0x1ae;let _0x523ba3=_0x1c4ca1[_0x2c410a];return _0x523ba3;},_0x2c41(_0x13ffe8,_0x331e87);}async function init(){const _0x434987=_0x14447b,_0x13395f=await Storage_All/* StoreAll */.N['get']({'area':_0x434987(0x1e9),'key':_0x434987(0x1da)})||{};await (0,On_Alarms/* alarmUpdatePlayers */.zi)();const _0x3c649f=async(_0x3e48b0,_0x2ac5a0)=>{const _0x16b490=_0x434987,_0x18be15=chrome[_0x16b490(0x1cc)]['getManifest']()['content_scripts'][_0x16b490(0x1e6)](_0x1763a0=>_0x1763a0['js'][_0x16b490(0x1f7)]()['indexOf']('Start-Up')!==-0x1)['matches']||[],_0x2b13ee=await chrome[_0x16b490(0x1fb)][_0x16b490(0x1d2)]({'active':!![],'url':_0x18be15}),_0x2b2e2c=_0x531021=>_0x531021[_0x16b490(0x1de)](_0x16b490(0x1c8))!==-0x1||_0x531021[_0x16b490(0x1de)](_0x16b490(0x1e8))!=-0x1?_0x2ac5a0:'';return _0x2b13ee[_0x16b490(0x1b9)](_0xab0b0e=>_0xab0b0e[_0x16b490(0x1c1)][_0x16b490(0x1de)](_0x3e48b0)!==-0x1&&_0xab0b0e[_0x16b490(0x1c1)]['indexOf'](_0x2b2e2c(_0xab0b0e[_0x16b490(0x1c1)]))!==-0x1);};async function _0x4d720e(_0x341f47){const _0x4c2edd=_0x434987,{name:_0x1e1e75,nodeName:_0x5bace0,checked:_0x378f83,id:_0x51c141}=_0x341f47['target'];if(!_0x1e1e75)return;const {playerId:_0x770b21,server:_0x33dd29,player:_0x4cbb37,due:_0x373316}=_0x13395f[_0x1e1e75],_0x2c1f41=await Storage_All/* StoreAll */.N[_0x4c2edd(0x1dc)]({'area':_0x4c2edd(0x1e9),'key':_0x4c2edd(0x1f6),'world':_0x33dd29})||{'timeZone':0x0,'delay':0x0},_0x7900dc=await _0x3c649f(_0x33dd29,_0x770b21),_0x4f1b8a=async()=>{for(const _0x28c072 of _0x7900dc){chrome['tabs']['reload'](_0x28c072['id']);}};['LABEL',_0x4c2edd(0x1d1)][_0x4c2edd(0x1de)](_0x5bace0)!==-0x1&&(_0x13395f[_0x1e1e75][_0x4c2edd(0x1c5)]=_0x378f83,await Storage_All/* StoreAll */.N[_0x4c2edd(0x1f5)]({'area':_0x4c2edd(0x1e9),'key':_0x4c2edd(0x1da),'data':_0x13395f}),await _0x4f1b8a());if([_0x4c2edd(0x1c7),_0x4c2edd(0x1ae)][_0x4c2edd(0x1de)](_0x5bace0)!==-0x1){if(_0x51c141[_0x4c2edd(0x1de)](_0x4c2edd(0x1f2))!==-0x1)_0x341f47['target'][_0x4c2edd(0x1d9)]='btn\x20btn-light\x20disabled',_0x341f47['target'][_0x4c2edd(0x1e3)]=_0x4c2edd(0x1bb)+0x5a+_0x4c2edd(0x1f0),Timer[_0x4c2edd(0x1d0)](_0x1e1e75,0x5a),Timer[_0x4c2edd(0x1d4)](_0x1e1e75),localStorage['setItem'](_0x4c2edd(0x1ed)+_0x1e1e75,Date['now']()+0x5a*0x3e8),await _0x400706();else{if(_0x51c141==='remove-'+_0x1e1e75){const _0x508e5d=document['querySelector'](_0x4c2edd(0x1cb)),_0x3f67f5=async _0x3bac8b=>{const _0x568ed4=_0x4c2edd;_0x508e5d[_0x568ed4(0x1c0)](_0x568ed4(0x1ce),_0x3f67f5),_0x3bac8b[_0x568ed4(0x1b3)]['id']===_0x568ed4(0x1d7)&&(delete _0x13395f[_0x1e1e75],await Storage_All/* StoreAll */.N[_0x568ed4(0x1f5)]({'area':_0x568ed4(0x1e9),'key':_0x568ed4(0x1da),'data':_0x13395f}),await _0x4f1b8a(),_0xcae834()),_0x2616bd['hide']();};_0x508e5d[_0x4c2edd(0x1ea)](_0x4c2edd(0x1ce),_0x3f67f5);const _0x2616bd=new window[(_0x4c2edd(0x1ca))][(_0x4c2edd(0x1ef))](_0x508e5d);_0x2616bd[_0x4c2edd(0x1d4)]();}}}async function _0x400706(){const _0x22960a=_0x4c2edd;if(!_0x4cbb37||!_0x33dd29)return _0x64675a(_0x22960a(0x1d3),_0x22960a(0x1e0),0xbb8);const _0x39f195=await Only_Players/* OnlyPlayers */.N[_0x22960a(0x1dd)](_0x33dd29+'_'+_0x4cbb37)||null;console[_0x22960a(0x1e5)](_0x39f195);let _0x1320b3;if(!_0x39f195||(_0x39f195&&!_0x39f195[_0x22960a(0x1c4)]||_0x39f195&&_0x39f195[_0x22960a(0x1c4)]&&Number(_0x39f195[_0x22960a(0x1c4)])<Date['now']()+_0x2c1f41[_0x22960a(0x1bf)]))_0x64675a(_0x22960a(0x1c3),_0x22960a(0x1e2),0xbb8),_0x1320b3={..._0x13395f[_0x1e1e75],...{'due':null,'id':_0x1e1e75,'active':![],'server':_0x33dd29,'playerId':_0x770b21,'player':_0x4cbb37}};else{if(Number(_0x39f195[_0x22960a(0x1c4)])===Number(_0x373316))return _0x64675a(_0x22960a(0x1eb),_0x22960a(0x1e2),0xbb8);else _0x64675a(_0x22960a(0x1f3),_0x22960a(0x1fc)),_0x1320b3={..._0x13395f[_0x1e1e75],..._0x39f195};}const _0x24fd21=resetSmall(_0x1320b3[_0x22960a(0x1c4)],_0x2c1f41),_0x318bad=document['querySelector']('small[name=\x22'+_0x1e1e75+'\x22]');_0x318bad[_0x22960a(0x1d9)]=_0x24fd21[_0x22960a(0x1b1)],_0x318bad[_0x22960a(0x1e3)]=_0x24fd21[_0x22960a(0x1e7)],document[_0x22960a(0x1fe)](_0x22960a(0x1d6)+_0x1e1e75)[_0x22960a(0x1f1)]=!_0x1320b3['due']||_0x1320b3[_0x22960a(0x1c4)]&&_0x1320b3[_0x22960a(0x1c4)]<Date[_0x22960a(0x1b5)]()+_0x2c1f41[_0x22960a(0x1bf)]?!![]:![],_0x13395f[_0x1e1e75]=_0x1320b3,await Storage_All/* StoreAll */.N[_0x22960a(0x1f5)]({'area':'local','key':_0x22960a(0x1da),'data':_0x13395f});const _0x16488f=await Only_Tabs/* OnlyTabs */.P[_0x22960a(0x1e4)](!![]);if(_0x16488f[_0x22960a(0x1df)])for(const _0x5c57f1 of _0x16488f){Only_Urls/* OnlyUrls */.l[_0x22960a(0x1b2)](_0x5c57f1[_0x22960a(0x1c1)])&&Only_Urls/* OnlyUrls */.l[_0x22960a(0x1ff)](_0x5c57f1[_0x22960a(0x1c1)],_0x33dd29)&&await (0,Insert_Content_Script/* insertContentScript */.s)({'tabId':_0x5c57f1['id']});}}}function _0x64675a(_0x225144,_0x69d5c4,_0x2c1231=0xbb8){const _0x5b9077=_0x434987,_0x118627=document['querySelector'](_0x5b9077(0x1cf));_0x118627[_0x5b9077(0x1d9)]=_0x69d5c4==_0x5b9077(0x1e0)?_0x5b9077(0x1cd):_0x5b9077(0x1c9),_0x118627[_0x5b9077(0x1e3)]=_0x5b9077(0x1be)+_0x225144+_0x5b9077(0x1f8),_0x118627[_0x5b9077(0x1fa)]=![],setTimeout(()=>_0x118627['hidden']=!![],_0x2c1231);}async function _0xcae834(){const _0x488bf5=_0x434987,_0x5b66e7=document[_0x488bf5(0x1fe)]('ul.list-group'),_0x1ff52f=Object['values'](_0x13395f)[_0x488bf5(0x1d8)]((_0x47d822,_0xf0e8e0)=>{const _0x14c39b=_0x488bf5;if(_0x47d822['due']>_0xf0e8e0[_0x14c39b(0x1c4)])return 0x1;if(_0x47d822['due']<_0xf0e8e0['due'])return 0x1;return;});removeEventListener(_0x488bf5(0x1ce),_0x4d720e);let _0x1f2545='';Timer[_0x488bf5(0x1b6)]();if(_0x1ff52f['length']){for(const _0x8a4270 of _0x1ff52f){_0x1f2545+=await insertList(_0x8a4270);}_0x5b66e7['addEventListener'](_0x488bf5(0x1ce),_0x4d720e);}else _0x1f2545=noList;_0x5b66e7[_0x488bf5(0x1e3)]=_0x1f2545,Timer[_0x488bf5(0x1d4)]();}_0xcae834();}init();
})();

/******/ })()
;