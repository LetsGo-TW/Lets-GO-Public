/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	// The require scope
/******/ 	var __webpack_require__ = {};
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  F: () => (/* binding */ objKeys)
});

;// CONCATENATED MODULE: ../UserFull/Fn-Date.js
const setInputDateTime = ( cDate, cTime, cMs ) => `${cDate.split("/")[2]}-${cDate.split("/")[1].length == 1 ? "0" : ""}${cDate.split("/")[1]}-${cDate.split("/")[0]}T${cTime.length == 7 ? "0" : ""}${cTime}.${cMs ? cMs : "000"}`

const nDateTime = ( date, time = "00:00:00", ms ) => {
    const arrDate = date.split("/").map(e => Number(e))
    const arrTime = time.split(":").map(e => Number(e))
    const n_ms = ms ? Number(ms) : arrTime.length > 3 ? arrTime[3] : 0
    if (arrTime.length === 2) {
        arrTime.unshift(0)
    }
    return Date.parse( new Date( arrDate[2], arrDate[1] -1, arrDate[0], arrTime[0], arrTime[1], arrTime[2] ) ) + n_ms
}
const nSecStrTime = ( s ) => {
    let h = parseInt( s / 3600 )
    let m = parseInt( ( s - ( h * 3600 ) ) / 60 )
    s = parseInt( s - ( h * 3600 ) - ( m * 60 ) )
    if ( h < 10 ) h = '0' + h
    if ( m < 10 ) m = '0' + m
    if ( s < 10 ) s = '0' + s
    return `${h}:${m}:${s}`
}
const cTimeToSeg = ( c_hora ) => {
    let l = c_hora.length
    let n_hh = Number( c_hora.substring( 0, l - 6 ) )
    let n_mm = Number( c_hora.substring( l - 5, l - 3 ) )
    let n_ss = Number( c_hora.substring( l - 2, l ) )
    
    return Number(( n_hh * 3600 ) + ( n_mm * 60 ) + n_ss)
}
const strTimeToSec = string => {
    const arrTime = string.match(/[0-9]{1,}[:][0-9]{2}[:][0-9]{2}/ig)
    if (!arrTime) return null
    const time = arrTime[arrTime.length - 1].split(":")
    return (time[0] * 3600) + (time[1] * 60) + (time[2] * 1)
}


;// CONCATENATED MODULE: ./popup/components.js



'use strict'

const insert_li = key => {
    return `<li class="list-group-item" data-key="${key}">
    <div class="form-check form-switch d-flex w-100 justify-content-between">
        <input class="form-check-input" type="checkbox" role="switch" id="${key}" ${ objKeys[key].active == true ? "checked" : ""} title="${ objKeys[key].active == true ? "Desativar " : "Ativar " }${ objKeys[key].server } - ${ objKeys[key].player }">
        <label class="form-check-label ms-2 me-auto" for="${key}" title="${ objKeys[key].active == true ? "Desativar " : "Ativar " }${ objKeys[key].server } - ${ objKeys[key].player }">
        <div class="fw-bold">${ objKeys[key].server } - ${ objKeys[key].player }</div>
        <small class=${ new Date().getTime() > nDateTime( objKeys[key].due ) - 3*24*3600*1000 ? "text-danger" : "text-success" }>${new Date().getTime() > nDateTime( objKeys[key].due ) ? "expirado" : "expira" }: ${ objKeys[key].due }</small> 
        </label>
        <button type="button" class="btn btn-light" title="Excluir ${ objKeys[key].server } - ${ objKeys[key].player }" >❌</button>
    </div>
    </li>`
}

const no_li = `<li class="list-group-item" data-key=""><div class="form-check form-switch text-wrap" style="max-width: fit-content;">Nenhuma chave de permissão encontrada.</div></li>`

const printMessage = {
    success : function(message, time) {
        this.run(message, time, "succ")
    },
    error : function(message, time) {
        this.run(message, time, "erro")
    },
    warn : function(message, time) {
        this.run(message, time, "warn")
    },
    run : function(message, time, type) {
        const divMessage = document.createElement("div")
        document.querySelector("body").append(divMessage)
        divMessage.id = "message"
        divMessage.className = type
        divMessage.innerHTML = `<p>${message}</p>`
        setTimeout(() => {
            divMessage.remove()
        }, time);
    }
}

;// CONCATENATED MODULE: ./src/Useful/Useful-Extension.js
const Useful_Extension_nDateTime = ( date, time = "00:00:00", ms ) => {
    const arrDate = date.split("/").map(e => Number(e))
    const arrTime = time.split(":").map(e => Number(e))
    const n_ms = ms ? Number(ms) : arrTime.length > 3 ? arrTime[3] : 0
    if (arrTime.length === 2) {
        arrTime.unshift(0)
    }
    return Date.parse( new Date( arrDate[2], arrDate[1] -1, arrDate[0], arrTime[0], arrTime[1], arrTime[2] ) ) + n_ms
}
function responseOnlyTab( key, tabId, type ) {
    console.log( "responseOnlyTab..." )
    const server = key.server
    chrome.tabs.query({}, tabs => {
        let arr = []
        console.log(tabs)
        for ( const tab of tabs ) {
            if ( server.trim() === tab.url.split(".")[0].replace("https://", "").trim() ) {
                arr.push({ tabId: tab.id, tabActive: tab.active })
            }
        }
        console.log(arr)
        if ( arr.length > 0 ) {
            const activeTab = arr.filter((e) => e.tabActive)
            tabId = activeTab.length > 0 ? activeTab[0].tabId : arr[0].tabId
            for (const e of arr) {
                if (e.tabId != tabId) {
                    key.type = "disabled"
                } else {
                    key.type = type
                }
                console.warn(e.tabId)
                console.table(key)
                chrome.tabs.sendMessage(e.tabId, key)
            }
        } else {
            // --- disconnect com player
            console.warn(tabId)
            console.table(key)
            chrome.tabs.sendMessage( tabId, key )
        }
    })
}
const fixKeyNickChar = (key, arr = []) => {
    const partialKey = key.split("=")
    const len = partialKey.length
    arr.push( 
        key.replace("=" + partialKey[ len -1 ], "")
            .replace("=" + partialKey[ len - 2 ], ""),
        partialKey[len - 2], 
        partialKey[len - 1]
    )
    return arr
}
const fixKeyNickChar1 = (key1, arr = []) => {
    const partialKey = key1.split("_")
    arr.push(
        partialKey[0],
        key1.replace(partialKey[0] + "_", "")
    )
    return arr
}
async function sleep(seg) {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            resolve()
        }, seg * 1000);
    });
}
const random = ( min, max ) => {
    min = Math.ceil( min );
    max = Math.floor( max );
    return Math.floor( Math.random() * ( max - min + 1 ) ) + min;
}


;// CONCATENATED MODULE: ./popup/index.js




const URL_KEYS = "https://api-controller-lets-go.herokuapp.com"

'use strict'

if (!localStorage.getItem( "objKeys" )) localStorage.setItem("objKeys", JSON.stringify({}))

const objKeys = JSON.parse( localStorage.getItem( "objKeys" ))

console.table(objKeys)

async function verifyKey(k) {
    const keyFix = k.split("=").length == 3 ? k.split("=") : fixKeyNickChar(k)
    const serverUser = keyFix[0].replaceAll(" ", "!").replaceAll("?", ":")
    const url = URL_KEYS.replaceAll(" ", "") + "/players/" + serverUser
    console.log(url)
    try {
        const response = await fetch(url, { 
            method : "GET"
        })
        const { key , due } = await response.json()
        console.log(key, due)

        if (!key || !due ) throw new Error('Not key or due!')
        if ( key != k) throw new Error("Invalid Key!")
        if ( Date.now() > due ) throw new Error("Key Expires!")

        return true
    } catch (error) {
        console.error(error.message)
        return false
    }
}
async function init() {

    insert_ul_list()

}
function alertKey( text, type, time = 3000 ) {
    const alert_ = document.querySelector("div.alert")
    alert_.className = type == "error" ? "alert alert-danger text-wrap" : "alert alert-success text-wrap"
    alert_.innerHTML = `<p>${text}</p>`
    alert_.hidden = false
    setTimeout(() => alert_.hidden = true , time )
}
const btn = document.querySelector("#confirmar")
btn.addEventListener( "click", click_confirm )

async function click_confirm(e) {

    e.stopImmediatePropagation()

    const inp_key = document.querySelector("#key")
    const key = inp_key.value

    if ( key == "" ) return alertKey("Cole a chave de licença antes de confirmar!", "error")

    console.log(`key: ${key}`)

    if (!await verifyKey(key)) return alertKey("Chave incorreta! Procure seu revendedor.", "error", 8000)

    const fixKey = key.split("=").length == 3 ? key.split("=") : fixKeyNickChar(key)
    const fixServerPlayer = fixKeyNickChar1(fixKey[0])

    objKeys[ fixKey[0] ] = {
        active: true,
        server: fixServerPlayer[0],
        player: fixServerPlayer[1],
        due: new Date( Number( String( ( Number( fixKey[1] ) + 3333 ) / 3 ) + "00000" ) ).toLocaleDateString("pt-BR"),
        key: key
    }

    localStorage.setItem( "objKeys", JSON.stringify( objKeys ) )

    insert_ul_list()

    setTimeout(() => inp_key.value = "" , 0 )

    responseOnlyTab(objKeys[fixKey[0]], "", "insert")

    return alertKey("Obrigado pela preferência! Bom jogo.", "success")
}

async function click_ul_list(e) {
    if ( ["LABEL", "INPUT"].indexOf( e.target.nodeName ) != -1 ) {
        const elem = e.target.nodeName == "LABEL" ? e.target.offsetParent.dataset.key : e.target.id
        console.log(elem)
        console.log(e.target.nodeName)

        if (!elem) return console.error("Not identify key")

        objKeys[elem].active = objKeys[elem].active ? false : true
        console.log(objKeys[elem].active)

        localStorage.setItem( "objKeys", JSON.stringify( objKeys ) )

        responseOnlyTab( objKeys[elem], "", "edit" )

        insert_ul_list()
    }
    if ( e.target.nodeName == "BUTTON") {
        const elem = e.target.offsetParent.dataset.key
        console.log(elem)
        console.log(e.target.nodeName)

        if (!elem) return console.error("Not identify key")

        const toastLive = document.querySelector("div.toast")

        toastLive.addEventListener("click", async(t) => {

            console.log(t.target.id)

            if (t.target.id === "tost_confirm") {

                responseOnlyTab( objKeys[elem], "", "delete" )

                delete objKeys[elem]

                localStorage.setItem( "objKeys", JSON.stringify( objKeys ) )

                insert_ul_list()

            }

            toast.hide()

        })

        document.querySelector("div.toast > div > strong").textContent = `Excluir a chave: "${ objKeys[elem].server } - ${ objKeys[elem].player }" ?`

        const toast = new bootstrap.Toast(toastLive)
        toast.show()
    }
}

async function insert_ul_list() {
    const ul_list = document.querySelector("ul.list-group")
    const arrKeys = Object.keys( objKeys ).sort()

    removeEventListener("click", click_ul_list)

    let html = ""

    if ( arrKeys.length > 0 ) {

        for (const key of arrKeys) {
            if ( Useful_Extension_nDateTime( objKeys[key].due, "12:00:00" ) + ( 12 * 60 * 60 * 1000 ) < Date.now() ) {
                responseOnlyTab( objKeys[key], "", "delete" )
                delete objKeys[key]
            } else {
                html += insert_li( key )
                if (objKeys[key].type) delete objKeys[key].type
            }
        }
        localStorage.setItem("objKeys", JSON.stringify( objKeys ))

        ul_list.addEventListener("click", click_ul_list )

    } else { html = no_li }

    ul_list.innerHTML = html

}

init()
/******/ })()
;
//# sourceMappingURL=index.js.map